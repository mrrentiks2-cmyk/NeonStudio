package com.neondrift.studio;

/** Звук в памяти: стерео или моно (r == l), уже в частоте движка. */
final class Sample {
    final String id;
    String name;
    final float[] l, r;
    final int rate;
    String category = "";
    int root = 60;
    private float[] peaks;

    Sample(String id, String name, float[] l, float[] r, int rate) {
        this.id = id;
        this.name = name;
        this.l = l;
        this.r = r == null ? l : r;
        this.rate = rate;
    }

    int frames() {
        return l.length;
    }

    float seconds() {
        return l.length / (float) rate;
    }

    boolean stereo() {
        return r != l;
    }

    /** Пики для рисования формы волны (n столбиков), кэшируются. */
    synchronized float[] peaks(int n) {
        if (peaks != null && peaks.length == n) return peaks;
        float[] p = new float[n];
        int len = l.length;
        for (int i = 0; i < n; i++) {
            int a = (int) ((long) i * len / n), b = (int) ((long) (i + 1) * len / n);
            float m = 0;
            for (int j = a; j < b && j < len; j++) {
                float v = Math.max(Math.abs(l[j]), Math.abs(r[j]));
                if (v > m) m = v;
            }
            p[i] = m;
        }
        peaks = p;
        return p;
    }

    /** Нормализовать пик к уровню (для импортированных тихих звуков). */
    void normalize(float target) {
        float m = 0;
        for (int i = 0; i < l.length; i++) m = Math.max(m, Math.max(Math.abs(l[i]), Math.abs(r[i])));
        if (m < 1e-6f) return;
        float g = target / m;
        for (int i = 0; i < l.length; i++) l[i] *= g;
        if (r != l) for (int i = 0; i < r.length; i++) r[i] *= g;
        peaks = null;
    }

    /**
     * Нарезка по ударам: места резкого роста громкости. Возвращает доли длины (первая — 0).
     * sensitivity 0…1, minGap — минимальное расстояние между срезами в секундах.
     */
    float[] transients(float sensitivity, float minGap, int max) {
        int win = Math.max(64, rate / 200); // окна по ~5 мс
        int n = l.length / win;
        if (n < 4) return new float[]{0f};
        float[] e = new float[n];
        for (int i = 0; i < n; i++) {
            float s = 0;
            for (int j = i * win; j < (i + 1) * win; j++) s += Math.abs(l[j]) + Math.abs(r[j]);
            e[i] = s / win;
        }
        float mean = 0;
        for (float v : e) mean += v;
        mean /= n;
        float ratio = 1.5f + (1 - sensitivity) * 3f;
        int gap = Math.max(1, (int) (minGap * rate / win));
        java.util.ArrayList<Float> out = new java.util.ArrayList<>();
        out.add(0f);
        int last = 0;
        for (int i = 2; i < n && out.size() < max; i++) {
            float before = (e[i - 1] + e[i - 2]) * 0.5f + 1e-5f;
            if (e[i] > before * ratio && e[i] > mean * 0.6f && i - last >= gap) {
                out.add(i * win / (float) l.length);
                last = i;
            }
        }
        float[] r2 = new float[out.size()];
        for (int i = 0; i < r2.length; i++) r2[i] = out.get(i);
        return r2;
    }
}
