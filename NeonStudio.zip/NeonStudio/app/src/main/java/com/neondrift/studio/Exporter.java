package com.neondrift.studio;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCodecInfo;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Экспорт: трек WAV/M4A, стемы по каналам, MIDI, пакет «бит + звуки» и обратный импорт. */
final class Exporter {
    private Exporter() {}

    static String fileName(String s) {
        String n = s == null ? "" : s.replaceAll("[\\\\/:*?\"<>|\\n\\r\\t]+", " ").trim();
        if (n.isEmpty()) n = "Бит";
        return n.length() > 60 ? n.substring(0, 60).trim() : n;
    }

    private static File fresh(Context c, String name) {
        File f = new File(Files.exports(c), name);
        if (f.exists()) f.delete();
        return f;
    }

    // ================================================================== трек

    static File track(Context c, Project p, Render.Spec spec, int format, int rate, int bits, Render.Progress pr) throws IOException {
        String base = fileName(p.name) + (spec.song ? "" : " (паттерн)");
        if (format == 1) {
            File out = fresh(c, base + ".m4a");
            try (Aac aac = new Aac(out, rate)) {
                Render.render(p, Sounds.blocking(c, rate), rate, spec, aac, pr);
            } catch (IOException e) {
                out.delete();
                throw e;
            }
            return out;
        }
        File out = fresh(c, base + ".wav");
        try (Wav.Writer w = new Wav.Writer(out, rate, bits)) {
            Render.render(p, Sounds.blocking(c, rate), rate, spec, w::write, pr);
        } catch (IOException e) {
            out.delete();
            throw e;
        }
        return out;
    }

    /**
     * Стемы: каждый канал с нотами — отдельный WAV, всё в одном ZIP. Без мастер-лимитера,
     * поэтому пишем 32-битные с плавающей точкой: громкие пики не обрезаются.
     */
    static File stems(Context c, Project p, boolean song, int rate, Render.Progress pr) throws IOException {
        int bits = 32;
        Engine probe = new Engine(rate, 64);
        Engine.Compiled cc = probe.compile(p, null);
        boolean[] has = new boolean[cc.ch.length];
        int[] chs = song && cc.sTicks > 0 ? cc.sCh : cc.pCh;
        int nEv = song && cc.sTicks > 0 ? cc.sN : cc.pN;
        for (int i = 0; i < nEv; i++) has[chs[i]] = true;
        ArrayList<Integer> list = new ArrayList<>();
        for (int i = 0; i < has.length; i++) if (has[i]) list.add(i);
        if (list.isEmpty()) throw new IOException("нет нот для экспорта");
        File out = fresh(c, fileName(p.name) + " — стемы.zip");
        File tmp = new File(c.getCacheDir(), "stem.wav");
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out))) {
            zos.setLevel(1);
            for (int k = 0; k < list.size(); k++) {
                final int idx = k;
                int ci = list.get(k);
                Render.Spec s = new Render.Spec();
                s.song = song;
                s.only = ci;
                s.raw = true;
                try (Wav.Writer w = new Wav.Writer(tmp, rate, bits)) {
                    Render.render(p, Sounds.blocking(c, rate), rate, s, w::write,
                            f -> pr == null || pr.step((idx + f) / list.size()));
                }
                String name = String.format(Locale.ROOT, "%02d %s.wav", k + 1, fileName(cc.ch[ci].name));
                zos.putNextEntry(new ZipEntry(name));
                try (InputStream in = new FileInputStream(tmp)) {
                    ProjectStore.copyStream(in, zos);
                }
                zos.closeEntry();
            }
        } catch (IOException e) {
            out.delete();
            throw e;
        } finally {
            tmp.delete();
        }
        return out;
    }

    // ================================================================== MIDI

    /** Все каналы паттерна (или всей песни), по дорожке на канал. */
    static File midi(Context c, Project p, boolean song) throws IOException {
        ArrayList<String> names = new ArrayList<>();
        ArrayList<List<Project.Note>> tracks = new ArrayList<>();
        for (Project.Channel ch : p.channels) {
            ArrayList<Project.Note> notes = new ArrayList<>();
            if (song && !p.clips.isEmpty()) {
                for (Project.Clip cl : p.clips) {
                    Project.Pattern pt = p.pattern(cl.pattern);
                    if (pt == null || cl.mute) continue;
                    int plen = Math.max(Project.STEP, pt.ticks()), start = cl.start * Project.STEP, len = cl.len * Project.STEP;
                    List<Project.Note> src = pt.notes.get(ch.id);
                    if (src == null) continue;
                    for (int off = 0; off < len; off += plen) {
                        for (Project.Note n : src) {
                            if (n.start >= plen || off + n.start >= len) continue;
                            Project.Note m = n.copy();
                            m.start = start + off + n.start;
                            m.len = Math.min(n.len, len - off - n.start);
                            notes.add(m);
                        }
                    }
                }
            } else {
                List<Project.Note> src = p.current().notes.get(ch.id);
                if (src != null) for (Project.Note n : src) notes.add(n.copy());
            }
            if (notes.isEmpty()) continue;
            names.add(ch.name);
            tracks.add(notes);
        }
        if (tracks.isEmpty()) throw new IOException("нет нот");
        File out = fresh(c, fileName(p.name) + (song ? "" : " (паттерн)") + ".mid");
        try (OutputStream os = new FileOutputStream(out)) {
            os.write(Midi.writeTracks(names, tracks, p.bpm));
        }
        return out;
    }

    // ================================================================== пакет «бит + звуки»

    /** ZIP: project.json и все пользовательские звуки, которые в нём используются. */
    static File bundle(Context c, Project p) throws IOException {
        File out = fresh(c, fileName(p.name) + ".neonbeat.zip");
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(out))) {
            zos.putNextEntry(new ZipEntry("project.json"));
            zos.write(p.toJson().getBytes(StandardCharsets.UTF_8));
            zos.closeEntry();
            for (String ref : Sounds.used(p)) {
                if (!Sounds.library(ref)) continue;
                File f = Library.file(c, ref);
                if (f == null || !f.isFile()) continue;
                zos.putNextEntry(new ZipEntry("sounds/" + ref.substring(Library.PREFIX.length())));
                try (InputStream in = new FileInputStream(f)) {
                    ProjectStore.copyStream(in, zos);
                }
                zos.closeEntry();
            }
        }
        return out;
    }

    /** Проект из файла: пакет .zip с project.json и звуками или просто JSON. */
    static Project importProject(Context c, Uri uri) throws IOException {
        ContentResolver cr = c.getContentResolver();
        byte[] head = new byte[4];
        try (InputStream in = cr.openInputStream(uri)) {
            if (in == null || in.read(head) < 2) throw new IOException("файл пуст");
        }
        if (head[0] == 'P' && head[1] == 'K') return importBundle(c, uri);
        try (InputStream in = cr.openInputStream(uri)) {
            if (in == null) throw new IOException("файл не открылся");
            Project p = Project.fromJson(new String(Wav.readAll(in, 64 * 1024 * 1024), StandardCharsets.UTF_8));
            p.id = Project.uid();
            return p;
        } catch (IllegalArgumentException e) {
            throw new IOException("это не проект Neon Studio");
        }
    }

    private static Project importBundle(Context c, Uri uri) throws IOException {
        String json = null;
        File pack = null;
        int files = 0;
        try (ZipInputStream zin = new ZipInputStream(c.getContentResolver().openInputStream(uri))) {
            ZipEntry e;
            while ((e = zin.getNextEntry()) != null) {
                if (e.isDirectory()) continue;
                String n = e.getName().replace('\\', '/');
                if (n.equals("project.json")) {
                    json = new String(Wav.readAll(zin, 64 * 1024 * 1024), StandardCharsets.UTF_8);
                } else if (n.startsWith("sounds/")) {
                    if (pack == null) pack = Library.newPack(c, "Звуки проекта");
                    File f = Library.safe(pack, n.substring(7));
                    if (f == null) continue;
                    f.getParentFile().mkdirs();
                    try (OutputStream os = new FileOutputStream(f)) {
                        ProjectStore.copyStream(zin, os);
                    }
                    files++;
                }
            }
        } catch (IllegalArgumentException ex) {
            throw new IOException("архив повреждён");
        }
        if (json == null) throw new IOException("в архиве нет project.json — для звуков используйте «Импорт архива» в библиотеке");
        Project p;
        try {
            p = Project.fromJson(json);
        } catch (IllegalArgumentException ex) {
            throw new IOException("project.json не от Neon Studio");
        }
        p.id = Project.uid();
        if (pack != null) {
            // ссылки на звуки — в новую папку библиотеки
            String newPack = pack.getName();
            File renamed = new File(pack.getParentFile(), Exporter.fileName("Звуки — " + p.name));
            if (!renamed.exists() && pack.renameTo(renamed)) newPack = renamed.getName();
            for (Project.Channel ch : p.channels) {
                if (Sounds.library(ch.sample)) ch.sample = Library.PREFIX + newPack + "/" + ch.sample.substring(Library.PREFIX.length());
            }
            Library.invalidate();
        }
        return p;
    }

    // ================================================================== сохранить в «Музыку»

    /** Android 10+: сразу в Music/Neon Studio без разрешений. Иначе null — тогда «Сохранить как…». */
    static Uri saveToMusic(Context c, File f) throws IOException {
        if (Build.VERSION.SDK_INT < 29) return null;
        ContentResolver cr = c.getContentResolver();
        String name = f.getName(), mime = Files.type(name);
        boolean audio = mime.startsWith("audio/") && !name.endsWith(".mid");
        Uri collection = audio ? MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                : MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        v.put(MediaStore.MediaColumns.MIME_TYPE, mime);
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, (audio ? Environment.DIRECTORY_MUSIC : Environment.DIRECTORY_DOWNLOADS) + "/Neon Studio");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri u = cr.insert(collection, v);
        if (u == null) throw new IOException("не удалось создать файл");
        try (OutputStream os = cr.openOutputStream(u); InputStream in = new FileInputStream(f)) {
            if (os == null) throw new IOException("нет доступа к памяти");
            ProjectStore.copyStream(in, os);
        } catch (IOException e) {
            cr.delete(u, null, null);
            throw e;
        }
        v.clear();
        v.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(u, v, null, null);
        return u;
    }

    static void copyTo(Context c, File f, Uri target) throws IOException {
        try (OutputStream os = c.getContentResolver().openOutputStream(target, "w"); InputStream in = new FileInputStream(f)) {
            if (os == null) throw new IOException("нет доступа к файлу");
            ProjectStore.copyStream(in, os);
        }
    }

    static List<File> recent(Context c) {
        ArrayList<File> out = new ArrayList<>();
        File[] fs = Files.exports(c).listFiles();
        if (fs != null) for (File f : fs) if (f.isFile()) out.add(f);
        out.sort((a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        return out;
    }

    // ================================================================== AAC

    /** Кодирование в AAC (M4A) встроенным кодеком, кусками по мере сведения. */
    static final class Aac implements Render.Sink, AutoCloseable {
        private final MediaCodec enc;
        private final MediaMuxer mux;
        private final MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        private final int rate;
        private int track = -1;
        private boolean started;
        private long frames;
        private byte[] pcm = new byte[0];

        Aac(File out, int rate) throws IOException {
            this.rate = rate;
            MediaFormat f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 2);
            f.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC);
            f.setInteger(MediaFormat.KEY_BIT_RATE, 256_000);
            f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384);
            enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC);
            try {
                enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE);
                enc.start();
            } catch (RuntimeException e) {
                enc.release();
                throw new IOException("кодек AAC недоступен: " + e.getMessage());
            }
            mux = new MediaMuxer(out.getPath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        }

        @Override
        public void write(float[] buf, int n) throws IOException {
            int bytes = n * 4;
            if (pcm.length < bytes) pcm = new byte[bytes];
            for (int i = 0; i < n * 2; i++) {
                float v = Math.max(-1f, Math.min(1f, buf[i]));
                int s = Math.round(v * 32767f);
                pcm[2 * i] = (byte) s;
                pcm[2 * i + 1] = (byte) (s >> 8);
            }
            int off = 0, guard = 0;
            while (off < bytes) {
                int ii = enc.dequeueInputBuffer(10_000);
                if (ii < 0) {
                    drain(false);
                    if (++guard > 500) throw new IOException("кодек не отвечает");
                    continue;
                }
                ByteBuffer ib = enc.getInputBuffer(ii);
                if (ib == null) throw new IOException("кодек не отвечает");
                ib.clear();
                int len = Math.min(ib.remaining(), bytes - off);
                len -= len % 4;
                ib.put(pcm, off, len);
                enc.queueInputBuffer(ii, 0, len, frames * 1_000_000L / rate, 0);
                frames += len / 4;
                off += len;
                drain(false);
            }
        }

        private void drain(boolean eos) throws IOException {
            int idle = 0;
            while (true) {
                int oi = enc.dequeueOutputBuffer(info, eos ? 10_000 : 0);
                if (oi == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (!eos || ++idle > 300) return;
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (!started) {
                        track = mux.addTrack(enc.getOutputFormat());
                        mux.start();
                        started = true;
                    }
                } else if (oi >= 0) {
                    ByteBuffer ob = enc.getOutputBuffer(oi);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0;
                    if (ob != null && info.size > 0 && started) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        mux.writeSampleData(track, ob, info);
                    }
                    enc.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return;
                }
            }
        }

        @Override
        public void close() throws IOException {
            try {
                for (int guard = 0; guard < 300; guard++) {
                    int ii = enc.dequeueInputBuffer(10_000);
                    if (ii >= 0) {
                        enc.queueInputBuffer(ii, 0, 0, frames * 1_000_000L / rate, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        break;
                    }
                    drain(false);
                }
                drain(true);
            } finally {
                try {
                    enc.stop();
                } catch (RuntimeException ignored) {
                }
                enc.release();
                try {
                    if (started) mux.stop();
                } catch (RuntimeException ignored) {
                }
                mux.release();
            }
            if (!started) throw new IOException("кодек AAC ничего не записал");
        }
    }

    /** Карта «канал → ноты» для подсказок (сколько нот в каналах). */
    static Map<String, Integer> noteCounts(Project p) {
        HashMap<String, Integer> m = new HashMap<>();
        for (Project.Pattern pt : p.patterns) {
            for (Map.Entry<String, List<Project.Note>> e : pt.notes.entrySet()) {
                m.merge(e.getKey(), e.getValue().size(), Integer::sum);
            }
        }
        return m;
    }
}
