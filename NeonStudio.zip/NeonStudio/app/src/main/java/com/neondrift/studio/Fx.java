package com.neondrift.studio;

/** Эффекты: перегруз, биткрашер, компрессор, задержка, реверберация, лимитер, эквалайзер. */
final class Fx {
    private Fx() {}

    // ================================================================== перегруз

    static final String[] DRIVES = {"Мягкий", "Жёсткий", "Фузз", "Складка"};

    /** Перегруз: amount 0…1, тип по DRIVES. Громкость примерно выравнивается. */
    static float drive(float x, float amount, int type) {
        if (amount <= 0.001f) return x;
        float g = 1f + amount * amount * 30f;
        float y;
        switch (type) {
            case 1: // жёсткое ограничение
                y = Dsp.clamp(x * g, -1f, 1f);
                break;
            case 2: { // асимметричный фузз — злой 808
                float v = x * g;
                y = v > 0 ? Dsp.soft(v) : Dsp.soft(v * 0.6f) * 1.2f;
                y = Dsp.clamp(y, -1f, 1f);
                break;
            }
            case 3: { // волновая складка
                float v = x * g * 0.5f;
                y = (float) Math.sin(v * Math.PI * 0.5);
                break;
            }
            default:
                y = Dsp.soft(x * g);
        }
        float comp = 1f / (0.6f + 0.4f * Math.min(1f, g / 4f));
        return y * comp;
    }

    // ================================================================== биткрашер

    static final class Crusher {
        private float holdL, holdR;
        private int count;

        /** bits 1…16 (16 — выключено), rate 1…32 (во сколько раз реже отсчёты). */
        void process(float[] l, float[] r, int n, int bits, int rate) {
            if (bits >= 16 && rate <= 1) return;
            float q = bits >= 16 ? 0 : (float) Math.pow(2, bits - 1);
            for (int i = 0; i < n; i++) {
                if (count <= 0) {
                    holdL = l[i];
                    holdR = r[i];
                    if (q > 0) {
                        holdL = Math.round(holdL * q) / q;
                        holdR = Math.round(holdR * q) / q;
                    }
                    count = rate;
                }
                count--;
                l[i] = holdL;
                r[i] = holdR;
            }
        }
    }

    // ================================================================== эквалайзер

    static final class Eq3 {
        private final Dsp.Biquad[] lo = {new Dsp.Biquad(), new Dsp.Biquad()}, mid = {new Dsp.Biquad(), new Dsp.Biquad()}, hi = {new Dsp.Biquad(), new Dsp.Biquad()};
        private float gl = 0, gm = 0, gh = 0;
        private boolean set;

        void process(float[] l, float[] r, int n, float low, float mi, float high, float sr) {
            if (Math.abs(low) < 0.05f && Math.abs(mi) < 0.05f && Math.abs(high) < 0.05f) return;
            if (!set || low != gl || mi != gm || high != gh) {
                for (int c = 0; c < 2; c++) {
                    lo[c].shelf(true, 110f, low, sr);
                    mid[c].peak(1000f, 0.8f, mi, sr);
                    hi[c].shelf(false, 7000f, high, sr);
                }
                gl = low;
                gm = mi;
                gh = high;
                set = true;
            }
            for (int i = 0; i < n; i++) {
                l[i] = hi[0].process(mid[0].process(lo[0].process(l[i])));
                r[i] = hi[1].process(mid[1].process(lo[1].process(r[i])));
            }
        }
    }

    // ================================================================== компрессор

    static final class Comp {
        private float env, gain = 1f;
        private int counter;

        /** amount 0…1: порог от 0 до −30 дБ, 4:1, автоматическое выравнивание громкости. */
        void process(float[] l, float[] r, int n, float amount, float sr, float attackMs, float releaseMs) {
            if (amount <= 0.001f) return;
            float thr = -30f * amount, ratio = 4f;
            float atk = (float) Math.exp(-1.0 / (attackMs * 0.001 * sr)), rel = (float) Math.exp(-1.0 / (releaseMs * 0.001 * sr));
            float makeup = Dsp.dbToGain(-thr * (1 - 1 / ratio) * 0.5f);
            for (int i = 0; i < n; i++) {
                float a = Math.max(Math.abs(l[i]), Math.abs(r[i]));
                env = a > env ? a + (env - a) * atk : a + (env - a) * rel;
                if (--counter <= 0) {
                    counter = 8;
                    float db = Dsp.gainToDb(env), over = db - thr;
                    gain = over > 0 ? Dsp.dbToGain(-over * (1 - 1 / ratio)) : 1f;
                }
                float g = gain * makeup;
                l[i] *= g;
                r[i] *= g;
            }
        }

        float reduction() {
            return gain;
        }
    }

    // ================================================================== задержка «пинг-понг»

    static final class Delay {
        private final float[] bl, br;
        private int w;
        private float lpL, lpR;

        Delay(float sr) {
            int len = (int) (sr * 2.5f);
            bl = new float[len];
            br = new float[len];
        }

        /** inL/inR — посыл, результат добавляется в outL/outR. time — в сэмплах. */
        void process(float[] inL, float[] inR, float[] outL, float[] outR, int n, int time, float feedback, float damp, float level) {
            int len = bl.length;
            time = Math.max(1, Math.min(len - 1, time));
            float d = Dsp.clamp(damp, 0f, 0.95f);
            for (int i = 0; i < n; i++) {
                int rd = w - time;
                if (rd < 0) rd += len;
                float yl = bl[rd], yr = br[rd];
                lpL = yl + (lpL - yl) * d;
                lpR = yr + (lpR - yr) * d;
                float mono = (inL[i] + inR[i]) * 0.5f;
                // пинг-понг: вход в левый канал, повторы перекрёстно
                bl[w] = mono + lpR * feedback;
                br[w] = lpL * feedback;
                outL[i] += yl * level;
                outR[i] += yr * level;
                if (++w >= len) w = 0;
            }
        }

        void clear() {
            java.util.Arrays.fill(bl, 0);
            java.util.Arrays.fill(br, 0);
        }
    }

    // ================================================================== реверберация (Freeverb)

    static final class Reverb {
        private static final int[] COMB = {1116, 1188, 1277, 1356, 1422, 1491, 1557, 1617};
        private static final int[] AP = {556, 441, 341, 225};
        private final float[][] cl = new float[8][], cr = new float[8][], al = new float[4][], ar = new float[4][];
        private final int[] ci = new int[8], cri = new int[8], ai = new int[4], ari = new int[4];
        private final float[] fl = new float[8], fr = new float[8];

        Reverb(float sr) {
            float k = sr / 44100f;
            for (int i = 0; i < 8; i++) {
                cl[i] = new float[Math.max(1, (int) (COMB[i] * k))];
                cr[i] = new float[Math.max(1, (int) ((COMB[i] + 23) * k))];
            }
            for (int i = 0; i < 4; i++) {
                al[i] = new float[Math.max(1, (int) (AP[i] * k))];
                ar[i] = new float[Math.max(1, (int) ((AP[i] + 23) * k))];
            }
        }

        void process(float[] inL, float[] inR, float[] outL, float[] outR, int n, float size, float damp, float level) {
            float fb = 0.7f + Dsp.clamp(size, 0f, 1f) * 0.28f, dmp = Dsp.clamp(damp, 0f, 1f) * 0.4f, dmp1 = 1 - dmp;
            for (int s = 0; s < n; s++) {
                float in = (inL[s] + inR[s]) * 0.015f;
                float yl = 0, yr = 0;
                for (int i = 0; i < 8; i++) {
                    float[] b = cl[i];
                    float o = b[ci[i]];
                    fl[i] = o * dmp1 + fl[i] * dmp;
                    b[ci[i]] = in + fl[i] * fb;
                    if (++ci[i] >= b.length) ci[i] = 0;
                    yl += o;
                    float[] b2 = cr[i];
                    float o2 = b2[cri[i]];
                    fr[i] = o2 * dmp1 + fr[i] * dmp;
                    b2[cri[i]] = in + fr[i] * fb;
                    if (++cri[i] >= b2.length) cri[i] = 0;
                    yr += o2;
                }
                for (int i = 0; i < 4; i++) {
                    float[] b = al[i];
                    float bo = b[ai[i]];
                    b[ai[i]] = yl + bo * 0.5f;
                    yl = bo - yl;
                    if (++ai[i] >= b.length) ai[i] = 0;
                    float[] b2 = ar[i];
                    float bo2 = b2[ari[i]];
                    b2[ari[i]] = yr + bo2 * 0.5f;
                    yr = bo2 - yr;
                    if (++ari[i] >= b2.length) ari[i] = 0;
                }
                outL[s] += yl * 3f * level;
                outR[s] += yr * 3f * level;
            }
        }

        void clear() {
            for (float[] b : cl) java.util.Arrays.fill(b, 0);
            for (float[] b : cr) java.util.Arrays.fill(b, 0);
            for (float[] b : al) java.util.Arrays.fill(b, 0);
            for (float[] b : ar) java.util.Arrays.fill(b, 0);
            java.util.Arrays.fill(fl, 0);
            java.util.Arrays.fill(fr, 0);
        }
    }

    // ================================================================== лимитер мастера

    static final class Limiter {
        private final float[] dl, dr;
        private int w;
        private float env, gain = 1f;
        private final float atk, rel;
        private final int look;

        Limiter(float sr) {
            look = Math.max(16, (int) (sr * 0.0015f));
            dl = new float[look];
            dr = new float[look];
            atk = 1f - (float) Math.exp(-4.0 / look);
            rel = (float) Math.exp(-1.0 / (0.08 * sr));
        }

        /** Пики не выше ceiling (линейно), затем мягкое ограничение на всякий случай. */
        void process(float[] l, float[] r, int n, float ceiling) {
            for (int i = 0; i < n; i++) {
                float a = Math.max(Math.abs(l[i]), Math.abs(r[i]));
                env = a > env ? a : env * rel + a * (1 - rel);
                float target = env > ceiling ? ceiling / env : 1f;
                gain += (target - gain) * (target < gain ? atk : 1 - rel);
                float ol = dl[w], or = dr[w];
                dl[w] = l[i];
                dr[w] = r[i];
                if (++w >= look) w = 0;
                l[i] = ol * gain;
                r[i] = or * gain;
                if (l[i] > ceiling) l[i] = ceiling;
                if (l[i] < -ceiling) l[i] = -ceiling;
                if (r[i] > ceiling) r[i] = ceiling;
                if (r[i] < -ceiling) r[i] = -ceiling;
            }
        }

        float reduction() {
            return gain;
        }
    }
}
