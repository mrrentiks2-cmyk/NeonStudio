package com.neondrift.studio;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/** Чтение и запись MIDI-файлов (ноты и темп). Без Android. */
final class Midi {
    private Midi() {}

    static final class Result {
        final List<Project.Note> notes = new ArrayList<>();
        float bpm;
        int lengthTicks;
    }

    private static int pos;

    private static int vlq(byte[] b) throws IOException {
        int v = 0;
        for (int i = 0; i < 4; i++) {
            if (pos >= b.length) throw new IOException("обрыв файла");
            int c = b[pos++] & 255;
            v = (v << 7) | (c & 127);
            if ((c & 128) == 0) return v;
        }
        return v;
    }

    private static int be(byte[] b, int o, int n) {
        int v = 0;
        for (int i = 0; i < n; i++) v = (v << 8) | (b[o + i] & 255);
        return v;
    }

    static boolean isMidi(byte[] b) {
        return b.length > 14 && b[0] == 'M' && b[1] == 'T' && b[2] == 'h' && b[3] == 'd';
    }

    /** Все ноты всех дорожек, приведённые к 96 тикам на четверть. */
    static synchronized Result read(byte[] b) throws IOException {
        try {
            return parse(b);
        } catch (RuntimeException e) {
            throw new IOException("MIDI-файл повреждён");
        }
    }

    private static Result parse(byte[] b) throws IOException {
        if (!isMidi(b)) throw new IOException("не MIDI");
        int hlen = be(b, 4, 4);
        int division = be(b, 12, 2);
        int ppq = (division & 0x8000) != 0 ? 96 : Math.max(1, division);
        Result res = new Result();
        int p = 8 + hlen;
        while (p + 8 <= b.length) {
            int len = be(b, p + 4, 4);
            boolean track = b[p] == 'M' && b[p + 1] == 'T' && b[p + 2] == 'r' && b[p + 3] == 'k';
            int end = Math.min(b.length, p + 8 + Math.max(0, len));
            if (track) {
                pos = p + 8;
                long t = 0;
                int status = 0;
                HashMap<Integer, ArrayList<long[]>> open = new HashMap<>();
                while (pos < end) {
                    t += vlq(b);
                    int c = b[pos] & 255;
                    if (c >= 0x80) {
                        status = c;
                        pos++;
                    }
                    int type = status & 0xF0, chn = status & 0x0F;
                    if (status == 0xFF) {
                        int meta = b[pos++] & 255;
                        int ml = vlq(b);
                        if (meta == 0x51 && ml == 3 && res.bpm == 0) res.bpm = Math.round(60_000_000f / be(b, pos, 3) * 10) / 10f;
                        pos += ml;
                        if (meta == 0x2F) break;
                    } else if (status == 0xF0 || status == 0xF7) {
                        pos += vlq(b);
                    } else if (type == 0x80 || type == 0x90) {
                        int key = b[pos++] & 127, vel = b[pos++] & 127;
                        int id = chn << 8 | key;
                        if (type == 0x90 && vel > 0) {
                            open.computeIfAbsent(id, x -> new ArrayList<>()).add(new long[]{t, vel});
                        } else {
                            ArrayList<long[]> st = open.get(id);
                            if (st != null && !st.isEmpty()) {
                                long[] on = st.remove(0);
                                add(res, on[0], t, key, (int) on[1], ppq);
                            }
                        }
                    } else if (type == 0xC0 || type == 0xD0) {
                        pos += 1;
                    } else {
                        pos += 2;
                    }
                }
                // незакрытые ноты — длиной в шестнадцатую
                for (java.util.Map.Entry<Integer, ArrayList<long[]>> e : open.entrySet()) {
                    for (long[] on : e.getValue()) add(res, on[0], on[0] + ppq / 4, e.getKey() & 127, (int) on[1], ppq);
                }
            }
            p = end;
        }
        res.notes.sort((x, y) -> x.start != y.start ? Integer.compare(x.start, y.start) : Integer.compare(x.key, y.key));
        for (Project.Note n : res.notes) res.lengthTicks = Math.max(res.lengthTicks, n.end());
        return res;
    }

    private static void add(Result r, long on, long off, int key, int vel, int ppq) {
        int s = (int) Math.round(on * (double) Project.PPQ / ppq), e = (int) Math.round(off * (double) Project.PPQ / ppq);
        r.notes.add(new Project.Note(s, Math.max(1, e - s), key, Math.max(1, vel) / 127f));
    }

    /** MIDI-файл формата 0 из нот (96 тиков на четверть). */
    static byte[] write(List<Project.Note> notes, float bpm) {
        ArrayList<int[]> ev = new ArrayList<>(); // tick, on(1)/off(0), key, vel
        for (Project.Note n : notes) {
            ev.add(new int[]{n.start, 1, n.key, Math.max(1, Math.min(127, Math.round(n.vel * 127)))});
            ev.add(new int[]{n.end(), 0, n.key, 0});
        }
        ev.sort((a, b) -> a[0] != b[0] ? Integer.compare(a[0], b[0]) : Integer.compare(a[1], b[1]));
        ByteArrayOutputStream tr = new ByteArrayOutputStream();
        int us = Math.round(60_000_000f / Math.max(20f, bpm));
        writeVlq(tr, 0);
        tr.write(0xFF); tr.write(0x51); tr.write(3);
        tr.write(us >> 16); tr.write(us >> 8); tr.write(us);
        int last = 0;
        for (int[] e : ev) {
            writeVlq(tr, e[0] - last);
            last = e[0];
            tr.write(e[1] == 1 ? 0x90 : 0x80);
            tr.write(e[2] & 127);
            tr.write(e[1] == 1 ? e[3] : 64);
        }
        writeVlq(tr, 0);
        tr.write(0xFF); tr.write(0x2F); tr.write(0);
        byte[] t = tr.toByteArray();
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        out.write('M'); out.write('T'); out.write('h'); out.write('d');
        out.write(0); out.write(0); out.write(0); out.write(6);
        out.write(0); out.write(0); out.write(0); out.write(1);
        out.write(0); out.write(Project.PPQ);
        out.write('M'); out.write('T'); out.write('r'); out.write('k');
        out.write(t.length >> 24); out.write(t.length >> 16); out.write(t.length >> 8); out.write(t.length);
        out.write(t, 0, t.length);
        return out.toByteArray();
    }

    /** MIDI-файл формата 1: дорожка темпа и по дорожке на канал с названием. */
    static byte[] writeTracks(List<String> names, List<List<Project.Note>> tracks, float bpm) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int nt = tracks.size() + 1;
        out.write('M'); out.write('T'); out.write('h'); out.write('d');
        out.write(0); out.write(0); out.write(0); out.write(6);
        out.write(0); out.write(1); out.write(nt >> 8); out.write(nt);
        out.write(0); out.write(Project.PPQ);
        ByteArrayOutputStream t0 = new ByteArrayOutputStream();
        int us = Math.round(60_000_000f / Math.max(20f, bpm));
        writeVlq(t0, 0);
        t0.write(0xFF); t0.write(0x51); t0.write(3);
        t0.write(us >> 16); t0.write(us >> 8); t0.write(us);
        writeVlq(t0, 0);
        t0.write(0xFF); t0.write(0x2F); t0.write(0);
        chunk(out, t0.toByteArray());
        for (int k = 0; k < tracks.size(); k++) {
            ByteArrayOutputStream tr = new ByteArrayOutputStream();
            byte[] name = names.get(k).getBytes(java.nio.charset.StandardCharsets.UTF_8);
            writeVlq(tr, 0);
            tr.write(0xFF); tr.write(0x03);
            writeVlq(tr, name.length);
            tr.write(name, 0, name.length);
            int chan = k % 16;
            ArrayList<int[]> ev = new ArrayList<>();
            for (Project.Note n : tracks.get(k)) {
                ev.add(new int[]{n.start, 1, n.key, Math.max(1, Math.min(127, Math.round(n.vel * 127)))});
                ev.add(new int[]{n.end(), 0, n.key, 0});
            }
            ev.sort((a, b) -> a[0] != b[0] ? Integer.compare(a[0], b[0]) : Integer.compare(a[1], b[1]));
            int last = 0;
            for (int[] e : ev) {
                writeVlq(tr, e[0] - last);
                last = e[0];
                tr.write((e[1] == 1 ? 0x90 : 0x80) | chan);
                tr.write(e[2] & 127);
                tr.write(e[1] == 1 ? e[3] : 64);
            }
            writeVlq(tr, 0);
            tr.write(0xFF); tr.write(0x2F); tr.write(0);
            chunk(out, tr.toByteArray());
        }
        return out.toByteArray();
    }

    private static void chunk(ByteArrayOutputStream out, byte[] t) {
        out.write('M'); out.write('T'); out.write('r'); out.write('k');
        out.write(t.length >> 24); out.write(t.length >> 16); out.write(t.length >> 8); out.write(t.length);
        out.write(t, 0, t.length);
    }

    private static void writeVlq(ByteArrayOutputStream o, int v) {
        int buf = v & 0x7F;
        while ((v >>= 7) > 0) {
            buf <<= 8;
            buf |= ((v & 0x7F) | 0x80);
        }
        while (true) {
            o.write(buf & 0xFF);
            if ((buf & 0x80) != 0) buf >>= 8;
            else break;
        }
    }
}
