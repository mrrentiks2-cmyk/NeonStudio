package com.neondrift.studio;

import android.content.Context;
import android.content.res.ColorStateList;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/** Выезжающие панели студии: канал, эффекты, проект, генератор, паттерны, экспорт, настройки. */
final class Panels {
    interface Nav {
        void refresh();

        void showTab(int tab);

        void pickSoundFor(Project.Channel ch);

        void openPiano(Project.Channel ch);

        void toast(String s);

        void share(File f);

        void saveAs(File f);

        void projectReplaced();
    }

    static final int[] COLORS = {0xFFFF2D95, 0xFFFF8A3D, 0xFFFFD447, 0xFF8CFF5A, 0xFF3DFFB0, 0xFF00E5FF, 0xFF5C8DFF,
            0xFF9D6BFF, 0xFFB57BFF, 0xFFFF4F9A, 0xFF8FD8FF, 0xFF9A91B8};

    private final Context c;
    private final Studio s;
    private final Ui ui;
    private final SidePanel panel;
    private final Nav nav;

    Panels(Context c, Studio s, Ui ui, SidePanel panel, Nav nav) {
        this.c = c;
        this.s = s;
        this.ui = ui;
        this.panel = panel;
        this.nav = nav;
    }

    // ================================================================== элементы управления

    interface Get {
        float get();
    }

    interface Put {
        void put(float v);
    }

    interface Fmt {
        String f(float v);
    }

    static final int LIN = 0, LOG = 1, SQR = 2;

    static String hz(float v) {
        return v < 1000 ? String.format(Locale.ROOT, "%.0f Гц", v) : String.format(Locale.ROOT, "%.1f кГц", v / 1000);
    }

    static String sec(float v) {
        return v < 1 ? String.format(Locale.ROOT, "%.0f мс", v * 1000) : String.format(Locale.ROOT, "%.2f с", v);
    }

    static String pct(float v) {
        return String.format(Locale.ROOT, "%.0f%%", v * 100);
    }

    static String db(float v) {
        return String.format(Locale.ROOT, "%+.1f дБ", v);
    }

    static String semis(float v) {
        return String.format(Locale.ROOT, "%+.2f пт", v).replace(".00", "");
    }

    private static float toUnit(float v, float min, float max, int curve) {
        if (curve == LOG) return (float) (Math.log(Math.max(v, min) / min) / Math.log(max / min));
        float u = (v - min) / (max - min);
        return curve == SQR ? (float) Math.sqrt(Math.max(0, u)) : u;
    }

    private static float fromUnit(float u, float min, float max, int curve) {
        if (curve == LOG) return (float) (min * Math.pow(max / min, u));
        if (curve == SQR) u = u * u;
        return min + (max - min) * u;
    }

    /** Ползунок с подписью и значением; касание значения — сброс. rebuild — нужна пересборка песни. */
    TextView slider(LinearLayout parent, String label, float min, float max, int curve, float def, Fmt fmt, Get g, Put p, boolean rebuild) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(4), ui.dp(8), ui.dp(4), 0);
        row.addView(ui.text(label, 14, Theme.TEXT, false), Ui.lp(0, Ui.WRAP, 1f));
        TextView val = ui.text(fmt.f(g.get()), 13, Theme.ACCENT, true);
        val.setPadding(ui.dp(10), ui.dp(2), 0, ui.dp(2));
        row.addView(val);
        parent.addView(row);
        SeekBar sb = panel.slider(parent, 1000, Math.round(1000 * toUnit(g.get(), min, max, curve)), Theme.ACCENT);
        sb.setPadding(ui.dp(10), ui.dp(6), ui.dp(10), ui.dp(6));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar b, int prog, boolean fromUser) {
                if (!fromUser) return;
                float v = fromUnit(prog / 1000f, min, max, curve);
                p.put(v);
                val.setText(fmt.f(g.get()));
                if (rebuild) s.rebuild();
            }

            @Override
            public void onStartTrackingTouch(SeekBar b) {
                s.checkpoint();
            }

            @Override
            public void onStopTrackingTouch(SeekBar b) {
                if (rebuild) s.edited();
                else s.tweaked();
                nav.refresh();
            }
        });
        val.setOnClickListener(v -> {
            s.checkpoint();
            p.put(def);
            val.setText(fmt.f(g.get()));
            sb.setProgress(Math.round(1000 * toUnit(g.get(), min, max, curve)));
            if (rebuild) s.edited();
            else s.tweaked();
        });
        return val;
    }

    interface Pick {
        void pick(int i);
    }

    /** Ряд чипов-вариантов. */
    void choice(LinearLayout parent, String label, String[] names, int sel, Pick on) {
        if (label != null) panel.section(parent, label);
        LinearLayout row = panel.chipRow(parent);
        ArrayList<TextView> chips = new ArrayList<>();
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            TextView t = panel.chip(row, names[i], i == sel, () -> {
                for (int j = 0; j < chips.size(); j++) ui.styleChip(chips.get(j), j == k);
                on.pick(k);
            });
            chips.add(t);
        }
    }

    interface Flag {
        void set(boolean on);
    }

    TextView toggle(LinearLayout row, String label, boolean on, Flag f) {
        final boolean[] st = {on};
        TextView[] ref = new TextView[1];
        ref[0] = panel.chip(row, label, on, () -> {
            st[0] = !st[0];
            ui.styleChip(ref[0], st[0]);
            f.set(st[0]);
        });
        return ref[0];
    }

    TextView button(LinearLayout parent, String text, boolean primary, Runnable r) {
        TextView b = ui.button(text, primary, v -> r.run());
        parent.addView(b, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, 0));
        return b;
    }

    /** Поле ввода прямо в панели; «Готово» на клавиатуре — сохранить. */
    EditText field(LinearLayout parent, String value, String hint, java.util.function.Consumer<String> done) {
        EditText e = new EditText(c);
        e.setText(value);
        e.setHint(hint);
        e.setHintTextColor(Theme.MUTED);
        e.setTextColor(Theme.TEXT);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        e.setImeOptions(EditorInfo.IME_ACTION_DONE);
        e.setBackground(Ui.stroke(Theme.SURFACE, Theme.LINE, ui.dp(1), ui.dp(12)));
        e.setPadding(ui.dp(14), ui.dp(11), ui.dp(14), ui.dp(11));
        e.setOnEditorActionListener((v, id, ev) -> {
            done.accept(e.getText().toString().trim());
            hideKeyboard(e);
            return true;
        });
        e.setOnFocusChangeListener((v, has) -> {
            if (!has) done.accept(e.getText().toString().trim());
        });
        parent.addView(e, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(4), 0, 0));
        return e;
    }

    void hideKeyboard(View v) {
        InputMethodManager im = c.getSystemService(InputMethodManager.class);
        if (im != null) im.hideSoftInputFromWindow(v.getWindowToken(), 0);
        v.clearFocus();
    }

    void colors(LinearLayout parent, int current, Pick on) {
        LinearLayout row = panel.chipRow(parent);
        for (int i = 0; i < COLORS.length; i++) {
            final int k = i;
            View dot = new View(c);
            boolean sel = COLORS[i] == current;
            dot.setBackground(Ui.ripple(sel ? Ui.stroke(COLORS[i], 0xFFFFFFFF, ui.dp(3), ui.dp(100)) : Ui.oval(COLORS[i]), Ui.oval(0xFFFFFFFF)));
            dot.setOnClickListener(v -> on.pick(COLORS[k]));
            LinearLayout.LayoutParams lp = Ui.lp(ui.dp(32), ui.dp(32));
            lp.rightMargin = ui.dp(10);
            row.addView(dot, lp);
        }
    }

    // ================================================================== канал

    void channel(Project.Channel ch) {
        s.select(ch);
        LinearLayout p = panel.open(ch.name);
        // тип
        choice(p, "ИНСТРУМЕНТ", Project.TYPES, ch.type, i -> {
            if (ch.type == i) return;
            s.checkpoint();
            if (i == Project.SYNTH) Presets.synth(ch, 0);
            else if (i == Project.BASS) Presets.bass(ch, 0);
            else {
                ch.type = Project.SAMPLER;
                if (ch.sample == null || ch.sample.isEmpty()) ch.sample = Kits.PREFIX + "kick_memphis";
            }
            s.edited();
            channel(ch);
            nav.refresh();
        });
        if (ch.type == Project.SAMPLER) sampler(p, ch);
        else if (ch.type == Project.SYNTH) synth(p, ch);
        else bass808(p, ch);

        panel.section(p, "КАНАЛ");
        LinearLayout row = panel.chipRow(p);
        panel.chip(row, "Пиано-ролл", false, () -> {
            panel.close();
            nav.openPiano(ch);
        });
        panel.chip(row, "Эффекты", false, () -> fx(ch));
        panel.chip(row, "Переименовать", false, () -> rename(ch));
        panel.section(p, "ЦВЕТ");
        colors(p, ch.color, col -> {
            s.checkpoint();
            ch.color = col;
            s.tweaked();
            nav.refresh();
            channel(ch);
        });
    }

    private void sampler(LinearLayout p, Project.Channel ch) {
        panel.section(p, "ЗВУК");
        WaveView wave = new WaveView(c, s, ui);
        p.addView(wave, Ui.margins(Ui.MATCH, ui.dp(112), 0, ui.dp(2), 0, ui.dp(4)));
        WaveView.Listener wl = new WaveView.Listener() {
            @Override
            public void onRangeChanging() {
                s.checkpoint();
            }

            @Override
            public void onRangeChanged() {
                s.tweaked();
            }
        };
        wave.bind(ch, null, wl);
        s.loadSound(ch.sample, smp -> wave.bind(ch, smp, wl));
        LinearLayout row = ui.row();
        TextView name = ui.oneLine(Sounds.title(ch.sample), 15, Theme.TEXT, true);
        row.addView(name, Ui.lp(0, Ui.WRAP, 1f));
        row.addView(ui.iconButton("play", Theme.TEXT, 40, 10, v -> s.preview(ch.sample)));
        TextView change = ui.text("Сменить", 14, Theme.ACCENT, true);
        change.setPadding(ui.dp(12), ui.dp(10), ui.dp(4), ui.dp(10));
        change.setOnClickListener(v -> {
            panel.close();
            nav.pickSoundFor(ch);
        });
        row.addView(change);
        p.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(2), 0, 0));

        choice(p, "КАК ИГРАТЬ", Project.MODES, ch.mode, i -> {
            s.checkpoint();
            ch.mode = i;
            s.tweaked();
        });
        LinearLayout tg = panel.chipRow(p);
        toggle(tg, "Задом наперёд", ch.reverse, on -> {
            s.checkpoint();
            ch.reverse = on;
            s.tweaked();
            wave.invalidate();
        });

        panel.section(p, "НАРЕЗКА");
        panel.note(p, "Срезы раскладываются по нотам от «ноты звука» вверх — играйте ими на клавишах и в пиано-ролле.");
        String[] sl = {"Нет", "4", "8", "16", "По ударам"};
        int cur = ch.sliceMarks != null && !ch.sliceMarks.isEmpty() ? 4 : ch.slices == 4 ? 1 : ch.slices == 8 ? 2 : ch.slices == 16 ? 3 : 0;
        choice(p, null, sl, cur, i -> {
            s.checkpoint();
            ch.sliceMarks = "";
            ch.slices = i == 1 ? 4 : i == 2 ? 8 : i == 3 ? 16 : 0;
            if (i == 4) {
                s.loadSound(ch.sample, smp -> {
                    if (smp == null) return;
                    float[] m = smp.transients(0.6f, 0.08f, 32);
                    // доли от всего звука → доли от выбранного участка
                    StringBuilder sb = new StringBuilder();
                    float a = ch.start, b = Math.max(ch.end, a + 0.01f);
                    for (float v : m) {
                        if (v < a || v >= b) continue;
                        if (sb.length() > 0) sb.append(',');
                        sb.append(String.format(Locale.ROOT, "%.5f", (v - a) / (b - a)));
                    }
                    if (sb.length() == 0) sb.append("0");
                    ch.sliceMarks = sb.toString();
                    s.edited();
                    wave.invalidate();
                    nav.toast("Срезов: " + ch.sliceMarks.split(",").length);
                });
            } else {
                s.edited();
                wave.invalidate();
            }
        });

        panel.section(p, "ПОД ТЕМП (ПЕТЛИ)");
        String[] fit = {"Выкл", "1 доля", "2", "4 (такт)", "8", "16", "32"};
        float[] fv = {0, 1, 2, 4, 8, 16, 32};
        int fsel = 0;
        for (int i = 0; i < fv.length; i++) if (Math.abs(ch.fitBeats - fv[i]) < 0.01f) fsel = i;
        choice(p, null, fit, fsel, i -> {
            s.checkpoint();
            ch.fitBeats = fv[i];
            s.tweaked();
        });

        panel.section(p, "ВЫСОТА");
        panel.stepper(p, "Нота звука", Theory.name(ch.root), () -> {
            s.checkpoint();
            ch.root = Math.max(0, ch.root - 1);
            s.tweaked();
            channel(ch);
        }, () -> {
            s.checkpoint();
            ch.root = Math.min(127, ch.root + 1);
            s.tweaked();
            channel(ch);
        }, () -> {
        });
        slider(p, "Подстройка", -24, 24, LIN, 0, Panels::semis, () -> ch.tune, v -> ch.tune = Math.round(v * 4) / 4f, false);

        panel.section(p, "ОГИБАЮЩАЯ");
        slider(p, "Атака", 0, 1, SQR, 0, Panels::sec, () -> ch.attack, v -> ch.attack = v, false);
        slider(p, "Спад", 0.01f, 4, LOG, 0.3f, Panels::sec, () -> ch.decay, v -> ch.decay = v, false);
        slider(p, "Уровень", 0, 1, LIN, 1, Panels::pct, () -> ch.sustain, v -> ch.sustain = v, false);
        slider(p, "Затухание", 0.005f, 4, LOG, 0.04f, Panels::sec, () -> ch.release, v -> ch.release = v, false);
        panel.section(p, "ГРУППА ЗАГЛУШЕНИЯ");
        panel.note(p, "Звуки одной группы обрывают друг друга — закрытый хэт глушит открытый.");
        choice(p, null, new String[]{"Нет", "1", "2", "3", "4"}, ch.choke, i -> {
            s.checkpoint();
            ch.choke = i;
            s.tweaked();
        });
    }

    private void synth(LinearLayout p, Project.Channel ch) {
        choice(p, "ПРЕСЕТ", Presets.SYNTH, -1, i -> {
            s.checkpoint();
            Presets.synth(ch, i);
            s.edited();
            channel(ch);
        });
        String[] waves = Dsp.WAVES;
        choice(p, "ГЕНЕРАТОР 1", waves, ch.osc1, i -> {
            s.checkpoint();
            ch.osc1 = i;
            s.tweaked();
        });
        choice(p, "ГЕНЕРАТОР 2", waves, ch.osc2, i -> {
            s.checkpoint();
            ch.osc2 = i;
            s.tweaked();
        });
        slider(p, "Смесь 1 ↔ 2", 0, 1, LIN, 0.5f, Panels::pct, () -> ch.mix, v -> ch.mix = v, false);
        slider(p, "Строй ген. 2", -24, 24, LIN, 0, Panels::semis, () -> ch.osc2Semi, v -> ch.osc2Semi = Math.round(v), false);
        slider(p, "Расстройка", 0, 50, LIN, 8, v -> String.format(Locale.ROOT, "%.0f цент", v), () -> ch.detune, v -> ch.detune = v, false);
        slider(p, "Суб-октава", 0, 1, LIN, 0, Panels::pct, () -> ch.sub, v -> ch.sub = v, false);
        slider(p, "Шум", 0, 1, SQR, 0, Panels::pct, () -> ch.noise, v -> ch.noise = v, false);
        panel.section(p, "FM (КОЛОКОЛА, ЭЛЕКТРОПИАНО)");
        slider(p, "Глубина FM", 0, 1, SQR, 0, Panels::pct, () -> ch.fm, v -> ch.fm = v, false);
        slider(p, "Отношение", 0.5f, 12, LIN, 2, v -> String.format(Locale.ROOT, "×%.2f", v), () -> ch.fmRatio, v -> ch.fmRatio = Math.round(v * 4) / 4f, false);
        slider(p, "Спад FM", 0.02f, 4, LOG, 0.6f, Panels::sec, () -> ch.fmDecay, v -> ch.fmDecay = v, false);
        choice(p, "ФИЛЬТР", Dsp.FILTERS, ch.ftype, i -> {
            s.checkpoint();
            ch.ftype = i;
            s.tweaked();
        });
        slider(p, "Срез", 40, 18000, LOG, 3500, Panels::hz, () -> ch.cutoff, v -> ch.cutoff = v, false);
        slider(p, "Резонанс", 0, 0.95f, LIN, 0.15f, Panels::pct, () -> ch.res, v -> ch.res = v, false);
        slider(p, "Огибающая → фильтр", 0, 5, LIN, 0, v -> String.format(Locale.ROOT, "%.1f окт", v), () -> ch.envAmt, v -> ch.envAmt = v, false);
        slider(p, "Атака фильтра", 0.001f, 2, LOG, 0.002f, Panels::sec, () -> ch.fAttack, v -> ch.fAttack = v, false);
        slider(p, "Спад фильтра", 0.01f, 4, LOG, 0.3f, Panels::sec, () -> ch.fDecay, v -> ch.fDecay = v, false);
        slider(p, "Уровень фильтра", 0, 1, LIN, 0, Panels::pct, () -> ch.fSustain, v -> ch.fSustain = v, false);
        panel.section(p, "ГРОМКОСТЬ");
        slider(p, "Атака", 0.001f, 3, LOG, 0.003f, Panels::sec, () -> ch.attack, v -> ch.attack = v, false);
        slider(p, "Спад", 0.01f, 6, LOG, 0.3f, Panels::sec, () -> ch.decay, v -> ch.decay = v, false);
        slider(p, "Уровень", 0, 1, LIN, 0.7f, Panels::pct, () -> ch.sustain, v -> ch.sustain = v, false);
        slider(p, "Затухание", 0.005f, 5, LOG, 0.15f, Panels::sec, () -> ch.release, v -> ch.release = v, false);
        panel.section(p, "ИГРА");
        LinearLayout tg = panel.chipRow(p);
        toggle(tg, "Моно", ch.mono, on -> {
            s.checkpoint();
            ch.mono = on;
            s.tweaked();
        });
        slider(p, "Скольжение (глайд)", 0, 0.5f, SQR, 0, Panels::sec, () -> ch.glide, v -> ch.glide = v, false);
        slider(p, "Перегруз", 0, 1, LIN, 0, Panels::pct, () -> ch.vdrive, v -> ch.vdrive = v, false);
    }

    private void bass808(LinearLayout p, Project.Channel ch) {
        choice(p, "ПРЕСЕТ", Presets.BASS, -1, i -> {
            s.checkpoint();
            Presets.bass(ch, i);
            s.edited();
            channel(ch);
        });
        panel.note(p, "808 играет одним голосом: следующая нота обрывает предыдущую. Ноты с пометкой «слайд» в пиано-ролле плавно съезжают — фирменный звук фонка.");
        panel.section(p, "ЗВУК 808");
        slider(p, "Удар (высота)", 0, 24, LIN, 12, v -> String.format(Locale.ROOT, "%.0f пт", v), () -> ch.punch, v -> ch.punch = v, false);
        slider(p, "Длина удара", 0.005f, 0.2f, LOG, 0.035f, Panels::sec, () -> ch.punchTime, v -> ch.punchTime = v, false);
        slider(p, "Перегруз", 0, 1, LIN, 0.35f, Panels::pct, () -> ch.drive808, v -> ch.drive808 = v, false);
        slider(p, "Хвост", 0.1f, 5, LOG, 1.4f, Panels::sec, () -> ch.decay808, v -> ch.decay808 = v, false);
        slider(p, "Щелчок", 0, 1, LIN, 0.25f, Panels::pct, () -> ch.click, v -> ch.click = v, false);
        slider(p, "Скорость слайда", 0.01f, 0.5f, LOG, 0.07f, Panels::sec, () -> ch.glide, v -> ch.glide = v, false);
        slider(p, "Затухание", 0.005f, 2, LOG, 0.04f, Panels::sec, () -> ch.release, v -> ch.release = v, false);
    }

    void rename(Project.Channel ch) {
        LinearLayout p = panel.open("Название канала");
        EditText e = field(p, ch.name, "Название", v -> {
            if (v.isEmpty() || v.equals(ch.name)) return;
            s.checkpoint();
            ch.name = v.length() > 24 ? v.substring(0, 24) : v;
            s.tweaked();
            nav.refresh();
        });
        button(p, "Готово", true, () -> {
            hideKeyboard(e);
            channel(ch);
        });
        e.requestFocus();
        e.selectAll();
        e.post(() -> {
            InputMethodManager im = c.getSystemService(InputMethodManager.class);
            if (im != null) im.showSoftInput(e, 0);
        });
    }

    // ================================================================== эффекты канала

    void fx(Project.Channel ch) {
        s.select(ch);
        LinearLayout p = panel.open("Эффекты · " + ch.name);
        panel.section(p, "ПЕРЕГРУЗ");
        choice(p, null, Fx.DRIVES, ch.driveType, i -> {
            s.checkpoint();
            ch.driveType = i;
            s.tweaked();
        });
        slider(p, "Сила", 0, 1, LIN, 0, Panels::pct, () -> ch.fxDrive, v -> ch.fxDrive = v, false);
        panel.section(p, "ЛО-ФАЙ");
        slider(p, "Разрядность", 2, 16, LIN, 16, v -> Math.round(v) >= 16 ? "выкл" : Math.round(v) + " бит", () -> ch.bits, v -> ch.bits = Math.round(v), false);
        slider(p, "Понижение частоты", 1, 16, LIN, 1, v -> Math.round(v) <= 1 ? "выкл" : "÷" + Math.round(v), () -> ch.downsample, v -> ch.downsample = Math.round(v), false);
        panel.section(p, "ФИЛЬТР");
        choice(p, null, Dsp.FILTERS, ch.fType, i -> {
            s.checkpoint();
            ch.fType = i;
            if (i == Dsp.HP && ch.fCut > 19000) ch.fCut = 20;
            if (i == Dsp.LP && ch.fCut < 30) ch.fCut = 20000;
            s.tweaked();
            fx(ch);
        });
        slider(p, "Срез", 20, 20000, LOG, ch.fType == Dsp.HP ? 20 : 20000, Panels::hz, () -> ch.fCut, v -> ch.fCut = v, false);
        slider(p, "Резонанс", 0, 0.95f, LIN, 0.1f, Panels::pct, () -> ch.fRes, v -> ch.fRes = v, false);
        panel.section(p, "ЭКВАЛАЙЗЕР");
        slider(p, "Низ (100 Гц)", -15, 15, LIN, 0, Panels::db, () -> ch.eqLow, v -> ch.eqLow = v, false);
        slider(p, "Середина (1 кГц)", -15, 15, LIN, 0, Panels::db, () -> ch.eqMid, v -> ch.eqMid = v, false);
        slider(p, "Верх (8 кГц)", -15, 15, LIN, 0, Panels::db, () -> ch.eqHigh, v -> ch.eqHigh = v, false);
        panel.section(p, "КОМПРЕССОР");
        slider(p, "Сжатие", 0, 1, LIN, 0, Panels::pct, () -> ch.comp, v -> ch.comp = v, false);
        panel.section(p, "САЙДЧЕЙН (ПРОСЕДАНИЕ ПОД БОЧКУ)");
        LinearLayout tg = panel.chipRow(p);
        toggle(tg, "Этот канал — источник", ch.sideSource, on -> {
            s.checkpoint();
            ch.sideSource = on;
            s.tweaked();
        });
        slider(p, "Глубина", 0, 1, LIN, 0, Panels::pct, () -> ch.duck, v -> ch.duck = v, false);
        slider(p, "Возврат", 0.03f, 1, LOG, 0.22f, Panels::sec, () -> ch.duckRelease, v -> ch.duckRelease = v, false);
        panel.section(p, "ПОСЫЛЫ");
        slider(p, "Реверберация", 0, 1, SQR, 0, Panels::pct, () -> ch.sendRev, v -> ch.sendRev = v, false);
        slider(p, "Задержка (эхо)", 0, 1, SQR, 0, Panels::pct, () -> ch.sendDelay, v -> ch.sendDelay = v, false);
        panel.section(p, "МИКШЕР");
        slider(p, "Громкость", 0, MixerView.VOL_MAX, LIN, 0.8f, v -> {
            float d = MixerView.gainDb(v);
            return d <= -60 ? "−∞" : db(d);
        }, () -> ch.vol, v -> ch.vol = v, false);
        slider(p, "Панорама", -1, 1, LIN, 0, v -> Math.abs(v) < 0.02f ? "центр" : (v < 0 ? "Л " : "П ") + Math.round(Math.abs(v) * 100), () -> ch.pan, v -> ch.pan = v, false);
        button(p, "Сбросить эффекты", false, () -> {
            s.checkpoint();
            Project.Channel d = new Project.Channel();
            ch.fxDrive = d.fxDrive;
            ch.bits = d.bits;
            ch.downsample = d.downsample;
            ch.fType = d.fType;
            ch.fCut = d.fCut;
            ch.fRes = d.fRes;
            ch.eqLow = ch.eqMid = ch.eqHigh = 0;
            ch.comp = 0;
            ch.duck = 0;
            ch.sendRev = 0;
            ch.sendDelay = 0;
            s.tweaked();
            fx(ch);
            nav.refresh();
        });
    }

    // ================================================================== проект и мастер

    private final ArrayList<Long> taps = new ArrayList<>();

    void project() {
        Project pr = s.p;
        LinearLayout p = panel.open("Проект");
        field(p, pr.name, "Название бита", v -> {
            if (v.isEmpty() || v.equals(pr.name)) return;
            pr.name = v.length() > 40 ? v.substring(0, 40) : v;
            s.tweaked();
            nav.refresh();
        });
        panel.section(p, "ТЕМП");
        TextView[] bpmView = new TextView[1];
        bpmView[0] = panel.stepper(p, "BPM", fmtBpm(pr.bpm), () -> setBpm(pr.bpm - 1, bpmView[0]), () -> setBpm(pr.bpm + 1, bpmView[0]), () -> {
        });
        LinearLayout tr = panel.chipRow(p);
        panel.chip(tr, "Тап (стучите в темп)", false, () -> {
            long now = System.currentTimeMillis();
            if (!taps.isEmpty() && now - taps.get(taps.size() - 1) > 2000) taps.clear();
            taps.add(now);
            if (taps.size() > 6) taps.remove(0);
            if (taps.size() >= 3) {
                float avg = (taps.get(taps.size() - 1) - taps.get(0)) / (float) (taps.size() - 1);
                setBpm(Math.round(60000f / avg * 2) / 2f, bpmView[0]);
            }
        });
        for (int b : new int[]{90, 108, 130, 140, 150, 160}) panel.chip(tr, String.valueOf(b), false, () -> setBpm(b, bpmView[0]));
        slider(p, "Свинг", 0, 0.6f, LIN, 0, Panels::pct, () -> pr.swing, v -> pr.swing = v, true);

        panel.section(p, "ТОНАЛЬНОСТЬ");
        choice(p, null, Theory.KEYS, pr.key, i -> {
            pr.key = i;
            s.tweaked();
            nav.refresh();
        });
        choice(p, null, Theory.SCALE_NAMES, pr.scale, i -> {
            pr.scale = i;
            s.tweaked();
            nav.refresh();
        });
        panel.note(p, "Лад подсвечивается в пиано-ролле, по нему играют пэды «Лад» и пишет генератор. Уже записанные ноты не меняются.");

        panel.section(p, "МАСТЕР");
        slider(p, "Громкость", 0, MixerView.VOL_MAX, LIN, 0.85f, v -> {
            float d = MixerView.gainDb(v);
            return d <= -60 ? "−∞" : db(d);
        }, () -> pr.masterVol, v -> pr.masterVol = v, false);
        slider(p, "Склейка (компрессор)", 0, 1, LIN, 0.25f, Panels::pct, () -> pr.masterComp, v -> pr.masterComp = v, false);
        panel.note(p, "На выходе всегда стоит лимитер: трек не перегрузится, сколько ни добавляй.");
        panel.section(p, "РЕВЕРБЕРАЦИЯ");
        slider(p, "Размер зала", 0, 1, LIN, 0.72f, Panels::pct, () -> pr.revSize, v -> pr.revSize = v, false);
        slider(p, "Глухость", 0, 1, LIN, 0.45f, Panels::pct, () -> pr.revDamp, v -> pr.revDamp = v, false);
        slider(p, "Уровень", 0, 1.5f, LIN, 0.9f, Panels::pct, () -> pr.revLevel, v -> pr.revLevel = v, false);
        panel.section(p, "ЗАДЕРЖКА");
        float[] dv = {1, 2, 3, 4, 6, 8};
        String[] dn = {"1/16", "1/8", "1/8 с точкой", "1/4", "1/4 с точкой", "1/2"};
        int dsel = 2;
        for (int i = 0; i < dv.length; i++) if (Math.abs(pr.delSteps - dv[i]) < 0.01f) dsel = i;
        choice(p, null, dn, dsel, i -> {
            pr.delSteps = dv[i];
            s.tweaked();
        });
        slider(p, "Повторы", 0, 0.9f, LIN, 0.35f, Panels::pct, () -> pr.delFeedback, v -> pr.delFeedback = v, false);
        slider(p, "Глухость", 0, 1, LIN, 0.45f, Panels::pct, () -> pr.delDamp, v -> pr.delDamp = v, false);
        slider(p, "Уровень", 0, 1.5f, LIN, 0.8f, Panels::pct, () -> pr.delLevel, v -> pr.delLevel = v, false);
        panel.section(p, "ПЕСНЯ");
        LinearLayout tg = panel.chipRow(p);
        toggle(tg, "Повтор песни", pr.loop, on -> {
            pr.loop = on;
            s.syncTransport();
            s.tweaked();
        });
        toggle(tg, "Метроном", pr.metronome, on -> {
            pr.metronome = on;
            s.syncTransport();
            s.tweaked();
            nav.refresh();
        });
    }

    static String fmtBpm(float b) {
        return Math.abs(b - Math.round(b)) < 0.01f ? String.valueOf(Math.round(b)) : String.format(Locale.ROOT, "%.1f", b);
    }

    private void setBpm(float bpm, TextView v) {
        s.p.bpm = Math.max(40, Math.min(300, bpm));
        s.syncTransport();
        s.tweaked();
        if (v != null) v.setText(fmtBpm(s.p.bpm));
        nav.refresh();
    }

    // ================================================================== генератор

    private int genStyle = -1, genBars = 2;
    private boolean gDrums = true, gMelody = true, gBass = true, gChords, gTempo = true, gNewPattern;

    void generator() {
        if (genStyle < 0) genStyle = s.prefs.generatorStyle();
        Project pr = s.p;
        LinearLayout p = panel.open("Генератор бита");
        panel.note(p, "Пишет барабаны, мелодию, 808 и аккорды в выбранном стиле прямо в паттерн. Не понравилось — жмите ещё раз или «Отменить».");
        choice(p, "СТИЛЬ", Generator.STYLES, genStyle, i -> {
            genStyle = i;
            s.prefs.put("genStyle", i);
        });
        choice(p, "ТОНАЛЬНОСТЬ", Theory.KEYS, pr.key, i -> {
            pr.key = i;
            s.tweaked();
        });
        choice(p, "ДЛИНА", new String[]{"1 такт", "2 такта", "4 такта"}, genBars == 1 ? 0 : genBars == 2 ? 1 : 2, i -> genBars = i == 0 ? 1 : i == 1 ? 2 : 4);
        panel.section(p, "ЧТО ПИСАТЬ");
        LinearLayout row = panel.chipRow(p);
        toggle(row, "Барабаны", gDrums, on -> gDrums = on);
        toggle(row, "Мелодия", gMelody, on -> gMelody = on);
        toggle(row, "808 / бас", gBass, on -> gBass = on);
        toggle(row, "Аккорды", gChords, on -> gChords = on);
        LinearLayout row2 = panel.chipRow(p);
        toggle(row2, "Темп и лад стиля", gTempo, on -> gTempo = on);
        toggle(row2, "В новый паттерн", gNewPattern, on -> gNewPattern = on);
        TextView go = button(p, "🎲  Сгенерировать", true, () -> generate());
        go.setTextSize(17);
        panel.section(p, "ЦЕЛАЯ ПЕСНЯ");
        panel.note(p, "Новый проект по стилю: вступление, два варианта бита и готовая расстановка в плейлисте.");
        LinearLayout tpl = panel.chipRow(p);
        for (int i = 0; i < Generator.STYLES.length; i++) {
            final int k = i;
            panel.chip(tpl, Generator.STYLES[i], false, () -> {
                s.checkpoint();
                Project np = Templates.make(k, new Random().nextLong());
                s.p.channels.clear();
                s.p.patterns.clear();
                s.p.clips.clear();
                replaceProject(np);
                panel.close();
                nav.toast("Готово: " + Generator.STYLES[k] + " — жмите ▶");
            });
        }
    }

    private void replaceProject(Project np) {
        s.p.channels.addAll(np.channels);
        s.p.patterns.addAll(np.patterns);
        s.p.clips.addAll(np.clips);
        s.p.current = np.current;
        s.p.bpm = np.bpm;
        s.p.key = np.key;
        s.p.scale = np.scale;
        s.p.swing = np.swing;
        s.p.songMode = true;
        s.sel = s.p.channels.isEmpty() ? "" : s.p.channels.get(0).id;
        s.syncTransport();
        s.edited();
        nav.projectReplaced();
    }

    private void generate() {
        s.checkpoint();
        Project pr = s.p;
        Project.Pattern pt;
        if (gNewPattern) {
            pt = new Project.Pattern();
            pt.name = Generator.STYLES[genStyle] + " " + (pr.patterns.size() + 1);
            pt.color = COLORS[pr.patterns.size() % COLORS.length];
            pr.patterns.add(pt);
            pr.current = pt.id;
        } else {
            pt = pr.current();
        }
        Generator.Options o = new Generator.Options();
        o.seed = new Random().nextLong();
        o.bars = genBars;
        o.drums = gDrums;
        o.melody = gMelody;
        o.bass = gBass;
        o.chords = gChords;
        o.applyStyle = gTempo;
        Generator.generate(pr, pt, genStyle, o);
        s.syncTransport();
        s.setSongMode(false);
        s.edited();
        nav.refresh();
        if (!s.playing()) s.play();
    }

    // ================================================================== паттерны

    void patterns() {
        Project pr = s.p;
        LinearLayout p = panel.open("Паттерны");
        for (Project.Pattern pt : pr.patterns) {
            int uses = PlaylistView.uses(pr, pt.id);
            String sub = pt.steps / 16 + (pt.steps % 16 != 0 ? "+" : "") + " такт. · нот: " + PlaylistView.countNotes(pt)
                    + (uses > 0 ? " · в песне ×" + uses : "");
            panel.option(p, pt.name, sub, pt.id.equals(pr.current), () -> {
                pr.current = pt.id;
                s.edited();
                nav.refresh();
                patterns();
            });
        }
        button(p, "＋  Новый паттерн", true, () -> {
            s.checkpoint();
            Project.Pattern pt = new Project.Pattern();
            pt.name = "Паттерн " + (pr.patterns.size() + 1);
            pt.color = COLORS[pr.patterns.size() % COLORS.length];
            pt.steps = pr.current().steps;
            pr.patterns.add(pt);
            pr.current = pt.id;
            s.edited();
            nav.refresh();
            patterns();
        });
        Project.Pattern cur = pr.current();
        panel.section(p, "ТЕКУЩИЙ: " + cur.name.toUpperCase(Locale.ROOT));
        field(p, cur.name, "Название", v -> {
            if (v.isEmpty() || v.equals(cur.name)) return;
            s.checkpoint();
            cur.name = v;
            s.tweaked();
            nav.refresh();
        });
        String[] lens = {"1 такт", "2", "3", "4", "8"};
        int[] lv = {16, 32, 48, 64, 128};
        int lsel = -1;
        for (int i = 0; i < lv.length; i++) if (cur.steps == lv[i]) lsel = i;
        choice(p, "ДЛИНА", lens, lsel, i -> {
            s.checkpoint();
            cur.steps = lv[i];
            s.edited();
            nav.refresh();
        });
        panel.section(p, "ЦВЕТ");
        colors(p, cur.color, col -> {
            cur.color = col;
            s.tweaked();
            nav.refresh();
            patterns();
        });
        LinearLayout row = panel.chipRow(p);
        panel.chip(row, "Дублировать", false, () -> {
            s.checkpoint();
            Project.Pattern d = cur.copy();
            d.name = cur.name + " 2";
            pr.patterns.add(pr.patterns.indexOf(cur) + 1, d);
            pr.current = d.id;
            s.edited();
            nav.refresh();
            patterns();
        });
        panel.chip(row, "Очистить", false, () -> {
            s.checkpoint();
            cur.notes.clear();
            s.edited();
            nav.refresh();
            patterns();
        });
        if (pr.patterns.size() > 1) {
            panel.chip(row, "Удалить", false, () -> {
                s.checkpoint();
                pr.removePattern(cur);
                s.edited();
                nav.refresh();
                patterns();
            });
        }
    }

    // ================================================================== добавить канал

    void addChannel() {
        LinearLayout p = panel.open("Новый канал");
        panel.section(p, "БАРАБАНЫ И ЗВУКИ");
        String[][] roles = {{"kick", "Бочка"}, {"snare", "Малый"}, {"clap", "Клэп"}, {"hat", "Хэт"}, {"ohat", "Открытый хэт"},
                {"perc", "Перкуссия"}, {"cowbell", "Ковбелл"}, {"bell", "Колокол"}, {"vinyl", "Винил"}, {"fx", "Эффект"}};
        LinearLayout row = panel.chipRow(p);
        for (String[] r : roles) panel.chip(row, r[1], false, () -> add(Presets.make(r[0])));
        panel.option(p, "Из библиотеки или своих файлов", "Откроется браузер звуков — жмите «＋» у нужного", false, () -> {
            panel.close();
            nav.showTab(StudioActivity.TAB_SOUNDS);
        });
        panel.section(p, "808");
        LinearLayout r8 = panel.chipRow(p);
        for (int i = 0; i < Presets.BASS.length; i++) {
            final int k = i;
            panel.chip(r8, Presets.BASS[i], false, () -> {
                Project.Channel ch = Presets.make("808");
                Presets.bass(ch, k);
                ch.name = Presets.BASS[k];
                add(ch);
            });
        }
        panel.section(p, "СИНТЕЗАТОР");
        for (int i = 0; i < Presets.SYNTH.length; i++) {
            final int k = i;
            panel.option(p, Presets.SYNTH[i], null, false, () -> {
                Project.Channel ch = Presets.make("lead");
                Presets.synth(ch, k);
                ch.name = Presets.SYNTH[k];
                ch.role = k == 3 || k == 7 || k == 8 ? "bass" : k == 1 ? "chords" : k == 4 ? "keys" : "lead";
                ch.color = COLORS[(s.p.channels.size() * 5) % COLORS.length];
                add(ch);
            });
        }
    }

    private void add(Project.Channel ch) {
        s.checkpoint();
        ch.role = ch.role == null ? "" : ch.role;
        // одинаковые имена различаем номером
        String base = ch.name;
        int n = 2;
        boolean taken = true;
        while (taken) {
            taken = false;
            for (Project.Channel o : s.p.channels) if (o.name.equals(ch.name)) taken = true;
            if (taken) ch.name = base + " " + n++;
        }
        s.p.channels.add(ch);
        s.select(ch);
        s.edited();
        panel.close();
        nav.refresh();
        s.engine.live(ch, s.defaultKey(ch), 0.8f);
        s.main.postDelayed(() -> s.engine.live(ch, s.defaultKey(ch), 0f), 300);
    }

    // ================================================================== меню канала

    void channelMenu(Project.Channel ch) {
        Project pr = s.p;
        LinearLayout p = panel.open(ch.name);
        panel.option(p, "Пиано-ролл", "Ноты и мелодия этого канала", false, () -> {
            panel.close();
            nav.openPiano(ch);
        });
        panel.option(p, "Звук и настройки", null, false, () -> channel(ch));
        panel.option(p, "Эффекты", null, false, () -> fx(ch));
        panel.option(p, "Переименовать", null, false, () -> rename(ch));
        panel.section(p, "ЗАПОЛНИТЬ ШАГИ");
        LinearLayout fr = panel.chipRow(p);
        for (int every : new int[]{1, 2, 4, 8}) {
            panel.chip(fr, every == 1 ? "Каждый" : "Каждый " + every + "-й", false, () -> {
                s.checkpoint();
                Project.Pattern pt = pr.current();
                List<Project.Note> notes = pt.notes(ch.id);
                notes.clear();
                for (int st = 0; st < pt.steps; st += every) notes.add(new Project.Note(st * Project.STEP, s.defaultLen(ch), s.defaultKey(ch), 0.8f));
                s.edited();
                nav.refresh();
                panel.close();
            });
        }
        panel.section(p, "ПОРЯДОК");
        LinearLayout or = panel.chipRow(p);
        panel.chip(or, "Выше", false, () -> move(ch, -1));
        panel.chip(or, "Ниже", false, () -> move(ch, 1));
        panel.chip(or, "Дублировать", false, () -> {
            s.checkpoint();
            Project.Channel d = ch.copy();
            d.name = ch.name + " 2";
            pr.channels.add(pr.channels.indexOf(ch) + 1, d);
            for (Project.Pattern pt : pr.patterns) {
                List<Project.Note> src = pt.notes.get(ch.id);
                if (src == null) continue;
                ArrayList<Project.Note> cp = new ArrayList<>();
                for (Project.Note n : src) cp.add(n.copy());
                pt.notes.put(d.id, cp);
            }
            s.select(d);
            s.edited();
            nav.refresh();
            panel.close();
        });
        panel.section(p, "ОЧИСТКА");
        LinearLayout cr = panel.chipRow(p);
        panel.chip(cr, "Стереть ноты в паттерне", false, () -> {
            s.checkpoint();
            pr.current().notes.remove(ch.id);
            s.edited();
            nav.refresh();
            panel.close();
        });
        panel.chip(cr, "Удалить канал", false, () -> {
            s.checkpoint();
            pr.removeChannel(ch);
            s.edited();
            nav.refresh();
            panel.close();
            nav.toast("Канал удалён — «Отменить», если по ошибке");
        });
    }

    private void move(Project.Channel ch, int d) {
        List<Project.Channel> l = s.p.channels;
        int i = l.indexOf(ch), j = i + d;
        if (i < 0 || j < 0 || j >= l.size()) return;
        s.checkpoint();
        l.remove(i);
        l.add(j, ch);
        s.edited();
        nav.refresh();
    }

    // ================================================================== экспорт

    private Thread exportThread;
    private final AtomicBoolean cancel = new AtomicBoolean();
    private boolean exSong = true;
    private int exLoops = 2;

    void export() {
        Project pr = s.p;
        boolean hasSong = !pr.clips.isEmpty();
        if (!hasSong) exSong = false;
        LinearLayout p = panel.open("Экспорт");
        if (exportThread != null && exportThread.isAlive()) {
            panel.note(p, "Идёт экспорт…");
            return;
        }
        String[] what = hasSong ? new String[]{"Вся песня", "Текущий паттерн"} : new String[]{"Текущий паттерн"};
        choice(p, "ЧТО", what, hasSong ? (exSong ? 0 : 1) : 0, i -> exSong = hasSong && i == 0);
        choice(p, "ПОВТОРОВ ПАТТЕРНА", new String[]{"1", "2", "4", "8"}, exLoops == 1 ? 0 : exLoops == 2 ? 1 : exLoops == 4 ? 2 : 3,
                i -> exLoops = new int[]{1, 2, 4, 8}[i]);
        int fmt = s.prefs.exportFormat(), bits = s.prefs.exportBits();
        choice(p, "ФОРМАТ", new String[]{"WAV 24 бит", "WAV 16 бит", "M4A (AAC 256)"}, fmt == 1 ? 2 : bits == 16 ? 1 : 0, i -> {
            s.prefs.put("exportFormat", i == 2 ? 1 : 0);
            if (i < 2) s.prefs.put("exportBits", i == 0 ? 24 : 16);
        });
        choice(p, "ЧАСТОТА", new String[]{"44.1 кГц", "48 кГц"}, s.prefs.exportRate() == 48000 ? 1 : 0, i -> s.prefs.put("exportRate", i == 0 ? 44100 : 48000));

        LinearLayout status = ui.col();
        TextView msg = ui.text("", 13, Theme.MUTED, false);
        status.addView(msg);
        ProgressBar bar = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(1000);
        bar.setProgressTintList(ColorStateList.valueOf(Theme.ACCENT));
        status.addView(bar, Ui.margins(Ui.MATCH, ui.dp(10), 0, ui.dp(6), 0, 0));
        status.setVisibility(View.GONE);
        LinearLayout actions = ui.col();
        p.addView(actions);
        p.addView(status, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(12), 0, 0));
        LinearLayout result = ui.col();
        p.addView(result);

        java.util.function.BiConsumer<String, Job> start = (title, job) -> {
            if (s.playing()) s.stop();
            actions.setVisibility(View.GONE);
            status.setVisibility(View.VISIBLE);
            result.removeAllViews();
            msg.setText(title + "…");
            bar.setProgress(0);
            cancel.set(false);
            TextView stop = button(status, "Отмена", false, () -> cancel.set(true));
            Project snap = Project.fromJson(pr.toJson());
            exportThread = new Thread(() -> {
                File f = null;
                String err = null;
                try {
                    f = job.run(snap, fr -> {
                        s.main.post(() -> bar.setProgress(Math.round(fr * 1000)));
                        return !cancel.get();
                    });
                } catch (Render.CancelledException e) {
                    err = "";
                } catch (Exception | OutOfMemoryError e) {
                    err = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                }
                File done = f;
                String error = err;
                s.main.post(() -> {
                    status.removeView(stop);
                    status.setVisibility(View.GONE);
                    actions.setVisibility(View.VISIBLE);
                    if (error != null) {
                        if (!error.isEmpty()) nav.toast("Не получилось: " + error);
                        return;
                    }
                    showResult(result, done);
                });
            }, "neon-export");
            exportThread.start();
        };
        button(actions, "Экспорт трека", true, () -> start.accept("Сведение", (snap, prog) -> {
            Render.Spec sp = new Render.Spec();
            sp.song = exSong;
            sp.loops = exLoops;
            return Exporter.track(c, snap, sp, s.prefs.exportFormat(), s.prefs.exportRate(), s.prefs.exportBits(), prog);
        }));
        button(actions, "Стемы — каждый канал отдельно (ZIP)", false, () -> start.accept("Стемы", (snap, prog) ->
                Exporter.stems(c, snap, exSong, s.prefs.exportRate(), prog)));
        LinearLayout r2 = ui.row();
        TextView midi = ui.button("MIDI", false, v -> start.accept("MIDI", (snap, prog) -> Exporter.midi(c, snap, exSong)));
        TextView bundle = ui.button("Бит + звуки", false, v -> start.accept("Упаковка", (snap, prog) -> Exporter.bundle(c, snap)));
        r2.addView(midi, Ui.lp(0, Ui.WRAP, 1f));
        View gap = new View(c);
        r2.addView(gap, Ui.lp(ui.dp(8), 1));
        r2.addView(bundle, Ui.lp(0, Ui.WRAP, 1f));
        actions.addView(r2, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, 0));
        panel.note(actions, "«Бит + звуки» — проект со всеми вашими сэмплами в одном ZIP: откройте его на другом телефоне в Neon Studio.");

        List<File> recent = Exporter.recent(c);
        if (!recent.isEmpty()) {
            panel.section(p, "ГОТОВЫЕ ФАЙЛЫ");
            for (int i = 0; i < Math.min(12, recent.size()); i++) {
                File f = recent.get(i);
                fileRow(p, f);
            }
        }
    }

    interface Job {
        File run(Project snap, Render.Progress prog) throws Exception;
    }

    private void showResult(LinearLayout result, File f) {
        result.removeAllViews();
        panel.section(result, "ГОТОВО");
        fileRow(result, f);
    }

    private void fileRow(LinearLayout parent, File f) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(4), ui.dp(6), 0, ui.dp(6));
        LinearLayout texts = ui.col();
        texts.addView(ui.oneLine(f.getName(), 14, Theme.TEXT, true));
        texts.addView(ui.oneLine(size(f.length()), 11.5f, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(2), 0, 0));
        row.addView(texts, Ui.lp(0, Ui.WRAP, 1f));
        row.addView(ui.iconButton("share", Theme.TEXT, 40, 10, v -> nav.share(f)));
        row.addView(ui.iconButton("download", Theme.ACCENT, 40, 10, v -> {
            try {
                android.net.Uri u = Exporter.saveToMusic(c, f);
                if (u != null) nav.toast("Сохранено: " + (f.getName().endsWith(".zip") || f.getName().endsWith(".mid") ? "Загрузки" : "Музыка") + "/Neon Studio");
                else nav.saveAs(f);
            } catch (java.io.IOException e) {
                nav.saveAs(f);
            }
        }));
        row.addView(ui.iconButton("trash", Theme.MUTED, 40, 10, v -> {
            f.delete();
            ((LinearLayout) row.getParent()).removeView(row);
        }));
        parent.addView(row);
    }

    static String size(long b) {
        if (b < 1024 * 1024) return String.format(Locale.ROOT, "%.0f КБ", b / 1024f);
        return String.format(Locale.ROOT, "%.1f МБ", b / 1048576f);
    }

    // ================================================================== настройки

    void settings() {
        LinearLayout p = panel.open("Настройки");
        panel.section(p, "ЦВЕТ АКЦЕНТА");
        choice(p, null, Theme.ACCENT_NAMES, s.prefs.accent(), i -> {
            s.prefs.put("accent", i);
            nav.toast("Новый цвет — при следующем открытии студии");
        });
        panel.section(p, "ПОВЕДЕНИЕ");
        LinearLayout r = panel.chipRow(p);
        toggle(r, "Вибро-отклик", s.prefs.vibrate(), on -> s.prefs.put("vibrate", on));
        toggle(r, "Подсветка лада", s.prefs.scaleHighlight(), on -> {
            s.prefs.put("scaleHighlight", on);
            nav.refresh();
        });
        LinearLayout r2 = panel.chipRow(p);
        toggle(r2, "Сила по касанию", s.prefs.velocityPads(), on -> s.prefs.put("velocityPads", on));
        toggle(r2, "Квантовать запись", s.prefs.quantizeRec(), on -> s.prefs.put("quantizeRec", on));
        panel.section(p, "ЗВУК");
        panel.note(p, String.format(Locale.ROOT, "Частота %d Гц, блок %d, задержка ~%d мс. Запись с пэдов учитывает задержку.",
                s.rate, s.block, s.out.latencyMs()));
        panel.note(p, "Если звук заикается — закройте тяжёлые приложения; эффекты «Реверберация» и «Задержка» общие на проект и почти не нагружают.");
    }

    /** Строка «нет нот» для пустых действий. */
    static FrameLayout.LayoutParams center() {
        return new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.CENTER);
    }
}
