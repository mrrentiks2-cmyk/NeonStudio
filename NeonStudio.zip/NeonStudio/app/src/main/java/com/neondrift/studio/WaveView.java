package com.neondrift.studio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

/** Форма волны сэмпла: ручки начала и конца, метки нарезки. */
final class WaveView extends View {
    interface Listener {
        void onRangeChanging();

        void onRangeChanged();
    }

    private final Ui ui;
    private final Studio s;
    private Project.Channel ch;
    private Sample sample;
    private Listener listener;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private int drag = -1; // 0 — начало, 1 — конец
    private boolean began;

    WaveView(Context c, Studio s, Ui ui) {
        super(c);
        this.s = s;
        this.ui = ui;
        text.setTextSize(ui.dp(10));
        text.setColor(Theme.MUTED);
    }

    void bind(Project.Channel ch, Sample sample, Listener l) {
        this.ch = ch;
        this.sample = sample;
        listener = l;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        int W = getWidth(), H = getHeight();
        r.set(0, 0, W, H);
        fill.setColor(0xFF0D0B14);
        c.drawRoundRect(r, ui.dp(10), ui.dp(10), fill);
        if (ch == null) return;
        if (sample == null) {
            text.setTextAlign(Paint.Align.CENTER);
            c.drawText(s.broken(ch.sample) ? "файл не найден" : "загрузка…", W / 2f, H / 2f, text);
            return;
        }
        int n = Math.max(16, W / (int) ui.dp(2));
        float[] pk = sample.peaks(n);
        float mid = H / 2f, amp = H * 0.44f, bw = W / (float) n;
        float a = ch.start, b = ch.end;
        for (int i = 0; i < n; i++) {
            float pos = (i + 0.5f) / n;
            boolean in = pos >= a && pos <= b;
            float v = ch.reverse ? pk[n - 1 - i] : pk[i];
            fill.setColor(in ? ch.color : 0xFF3A3450);
            float h = Math.max(ui.dp(1), v * amp);
            c.drawRect(i * bw + bw * 0.15f, mid - h, (i + 1) * bw - bw * 0.15f, mid + h, fill);
        }
        // затемнение за пределами
        fill.setColor(0x88000000);
        c.drawRect(0, 0, a * W, H, fill);
        c.drawRect(b * W, 0, W, H, fill);
        // нарезка
        float[] marks = marks();
        if (marks != null) {
            fill.setColor(0xCCFFFFFF);
            for (int i = 0; i < marks.length; i++) {
                float x = (a + (b - a) * marks[i]) * W;
                c.drawRect(x - ui.dp(0.75f), 0, x + ui.dp(0.75f), H, fill);
                text.setTextAlign(Paint.Align.LEFT);
                text.setColor(0xCCFFFFFF);
                if (marks.length <= 32) c.drawText(String.valueOf(i + 1), x + ui.dp(3), ui.dp(12), text);
            }
        }
        // ручки
        handle(c, a * W, H, true);
        handle(c, b * W, H, false);
        text.setTextAlign(Paint.Align.RIGHT);
        text.setColor(Theme.MUTED);
        c.drawText(String.format(java.util.Locale.ROOT, "%.2f с", sample.seconds() * (b - a)), W - ui.dp(6), H - ui.dp(6), text);
    }

    private float[] marks() {
        if (ch.sliceMarks != null && !ch.sliceMarks.isEmpty()) {
            String[] parts = ch.sliceMarks.split(",");
            float[] m = new float[parts.length];
            try {
                for (int i = 0; i < parts.length; i++) m[i] = Float.parseFloat(parts[i].trim());
                return m;
            } catch (NumberFormatException e) {
                return null;
            }
        }
        if (ch.slices > 1) {
            float[] m = new float[ch.slices];
            for (int i = 0; i < ch.slices; i++) m[i] = i / (float) ch.slices;
            return m;
        }
        return null;
    }

    private void handle(Canvas c, float x, int H, boolean left) {
        fill.setColor(Theme.ACCENT2);
        c.drawRect(x - ui.dp(1), 0, x + ui.dp(1), H, fill);
        r.set(left ? x : x - ui.dp(12), H - ui.dp(22), left ? x + ui.dp(12) : x, H - ui.dp(4));
        c.drawRoundRect(r, ui.dp(3), ui.dp(3), fill);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (ch == null || sample == null) return false;
        float x = Math.max(0, Math.min(1, e.getX() / Math.max(1, getWidth())));
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                drag = Math.abs(x - ch.start) <= Math.abs(x - ch.end) ? 0 : 1;
                began = false;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (!began) {
                    began = true;
                    if (listener != null) listener.onRangeChanging();
                }
                if (drag == 0) ch.start = Math.min(x, ch.end - 0.01f);
                else ch.end = Math.max(x, ch.start + 0.01f);
                ch.start = Math.max(0, ch.start);
                ch.end = Math.min(1, ch.end);
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (began && listener != null) listener.onRangeChanged();
                drag = -1;
                return true;
            default:
                return true;
        }
    }
}
