package com.neondrift.studio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.List;
import java.util.Locale;

/**
 * Микшер: полосы каналов и мастер. Фейдер и панорама — перетаскиванием, двойное касание — сброс,
 * «FX» открывает эффекты канала, M/S — заглушить/соло. Стоит внутри горизонтальной прокрутки.
 */
final class MixerView extends View {
    interface Host {
        void openFx(Project.Channel c);

        void openMaster();
    }

    private final Studio s;
    private final Ui ui;
    private final Host host;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), text = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float stripW, slop;
    private Shader meterShader;

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        meterShader = null;
    }

    MixerView(Context c, Studio s, Ui ui, Host host) {
        super(c);
        this.s = s;
        this.ui = ui;
        this.host = host;
        stripW = ui.dp(78);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        text.setTextAlign(Paint.Align.CENTER);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int n = s.p.channels.size() + 1;
        int w = (int) (n * stripW + ui.dp(12));
        int parentW = MeasureSpec.getSize(wSpec);
        setMeasuredDimension(Math.max(w, parentW), MeasureSpec.getSize(hSpec));
    }

    // разметка полосы по высоте
    private float nameB() { return ui.dp(34); }
    private float panY() { return ui.dp(58); }
    private float fxTop() { return ui.dp(82); }
    private float fxB() { return ui.dp(106); }
    private float faderTop() { return ui.dp(122); }
    private float faderB() { return getHeight() - ui.dp(70); }
    private float msTop() { return getHeight() - ui.dp(46); }

    static final float VOL_MAX = 1.15f;

    static float gainDb(float vol) {
        float g = vol * vol * 1.2f;
        return g <= 1e-5f ? -99f : (float) (20 * Math.log10(g));
    }

    @Override
    protected void onDraw(Canvas c) {
        List<Project.Channel> chs = s.p.channels;
        boolean anySolo = false;
        for (Project.Channel ch : chs) anySolo |= ch.solo;
        Engine.Compiled comp = s.engine.song;
        for (int i = 0; i <= chs.size(); i++) {
            float x0 = ui.dp(6) + i * stripW;
            boolean master = i == chs.size();
            Project.Channel ch = master ? null : chs.get(i);
            int color = master ? Theme.ACCENT : ch.color;
            boolean selected = !master && ch.id.equals(s.sel);
            r.set(x0 + ui.dp(2), ui.dp(4), x0 + stripW - ui.dp(2), getHeight() - ui.dp(4));
            fill.setColor(master ? 0xFF1E1530 : selected ? 0xFF221B35 : Theme.SURFACE);
            c.drawRoundRect(r, ui.dp(10), ui.dp(10), fill);
            // имя
            fill.setColor(color);
            c.drawRoundRect(x0 + ui.dp(10), ui.dp(8), x0 + stripW - ui.dp(10), ui.dp(11), ui.dp(2), ui.dp(2), fill);
            text.setTextSize(ui.dp(11.5f));
            text.setTypeface(Typeface.DEFAULT_BOLD);
            text.setColor(Theme.TEXT);
            String name = master ? "МАСТЕР" : ch.name;
            c.drawText(fit(name, stripW - ui.dp(10)), x0 + stripW / 2, nameB() - ui.dp(6), text);
            float cx = x0 + stripW / 2;
            // панорама (у мастера — склейка)
            float knobV = master ? s.p.masterComp : (ch.pan + 1) / 2f;
            drawKnob(c, cx, panY(), ui.dp(13), knobV, color, master);
            // FX
            boolean fxOn = master ? s.p.masterComp > 0.01f || s.p.revLevel > 0 : fxActive(ch);
            r.set(x0 + ui.dp(12), fxTop(), x0 + stripW - ui.dp(12), fxB());
            fill.setColor(fxOn ? Theme.alpha(color, 70) : Theme.SURFACE2);
            c.drawRoundRect(r, ui.dp(7), ui.dp(7), fill);
            text.setTextSize(ui.dp(11));
            text.setColor(fxOn ? Theme.TEXT : Theme.MUTED);
            c.drawText(master ? "ЭФФЕКТЫ" : "FX", r.centerX(), r.centerY() + ui.dp(4), text);
            // фейдер и индикатор
            float ft = faderTop(), fb = faderB();
            float vol = master ? s.p.masterVol / VOL_MAX : ch.vol / VOL_MAX;
            float peak;
            if (master) peak = Math.max(s.engine.peakL, s.engine.peakR);
            else {
                peak = 0;
                if (comp != null) for (Engine.Strip st : comp.strips) if (st.ch == ch) peak = st.peak;
            }
            boolean audible = master || !ch.mute && (!anySolo || ch.solo);
            // шкала индикатора (−48…+3 дБ)
            float mx = cx + ui.dp(14);
            r.set(mx - ui.dp(3), ft, mx + ui.dp(3), fb);
            fill.setColor(0xFF0D0B14);
            c.drawRoundRect(r, ui.dp(3), ui.dp(3), fill);
            float db = peak <= 1e-5f ? -60 : (float) (20 * Math.log10(peak));
            float lv = Math.max(0, Math.min(1, (db + 48) / 51f));
            if (lv > 0 && audible) {
                r.set(mx - ui.dp(3), fb - (fb - ft) * lv, mx + ui.dp(3), fb);
                if (meterShader == null) meterShader = new LinearGradient(0, fb, 0, ft, new int[]{0xFF00E5FF, 0xFF8CFF5A, 0xFFFFD447, 0xFFFF2D6E},
                        new float[]{0f, 0.6f, 0.86f, 1f}, Shader.TileMode.CLAMP);
                fill.setShader(meterShader);
                c.drawRoundRect(r, ui.dp(3), ui.dp(3), fill);
                fill.setShader(null);
            }
            if (master && s.engine.clipped) {
                fill.setColor(0xFFFF2D6E);
                c.drawCircle(mx, ft - ui.dp(6), ui.dp(3), fill);
            }
            // дорожка фейдера
            float fx = cx - ui.dp(8);
            fill.setColor(0xFF0D0B14);
            r.set(fx - ui.dp(2), ft, fx + ui.dp(2), fb);
            c.drawRoundRect(r, ui.dp(2), ui.dp(2), fill);
            // отметка 0 дБ
            float zeroVol = (float) Math.sqrt(1 / 1.2) / VOL_MAX;
            line.setStrokeWidth(ui.dp(1));
            line.setColor(Theme.LINE);
            float zy = fb - (fb - ft) * zeroVol;
            c.drawLine(fx - ui.dp(9), zy, fx - ui.dp(5), zy, line);
            float hy = fb - (fb - ft) * vol;
            fill.setColor(Theme.alpha(color, audible ? 120 : 50));
            r.set(fx - ui.dp(2), hy, fx + ui.dp(2), fb);
            c.drawRoundRect(r, ui.dp(2), ui.dp(2), fill);
            // ручка
            r.set(fx - ui.dp(11), hy - ui.dp(7), fx + ui.dp(11), hy + ui.dp(7));
            fill.setColor(audible ? 0xFFE9E4F7 : 0xFF6A6280);
            c.drawRoundRect(r, ui.dp(4), ui.dp(4), fill);
            fill.setColor(color);
            c.drawRect(fx - ui.dp(8), hy - ui.dp(1), fx + ui.dp(8), hy + ui.dp(1), fill);
            // значение
            text.setTypeface(Typeface.DEFAULT);
            text.setTextSize(ui.dp(10));
            text.setColor(Theme.MUTED);
            float dbv = master ? gainDb(s.p.masterVol) : gainDb(ch.vol);
            c.drawText(dbv <= -60 ? "−∞" : String.format(Locale.ROOT, "%+.1f", dbv), cx, fb + ui.dp(15), text);
            // M / S
            if (!master) {
                float bw = (stripW - ui.dp(24)) / 2;
                drawToggle(c, x0 + ui.dp(10), msTop(), bw, "M", ch.mute, 0xFFFF8A3D);
                drawToggle(c, x0 + ui.dp(14) + bw, msTop(), bw, "S", ch.solo, 0xFFFFD447);
            } else {
                text.setColor(Theme.MUTED);
                text.setTextSize(ui.dp(9.5f));
                c.drawText("склейка", cx, panY() + ui.dp(24), text);
            }
        }
    }

    private boolean fxActive(Project.Channel ch) {
        return ch.fxDrive > 0.01f || ch.bits < 16 || ch.downsample > 1 || (ch.fType == Dsp.LP ? ch.fCut < 19000 : ch.fCut > 25)
                || Math.abs(ch.eqLow) > 0.1f || Math.abs(ch.eqMid) > 0.1f || Math.abs(ch.eqHigh) > 0.1f || ch.comp > 0.01f
                || ch.duck > 0.01f || ch.sendRev > 0.01f || ch.sendDelay > 0.01f;
    }

    private void drawKnob(Canvas c, float cx, float cy, float rad, float v, int color, boolean fromZero) {
        line.setStrokeWidth(ui.dp(3));
        line.setColor(0xFF0D0B14);
        r.set(cx - rad, cy - rad, cx + rad, cy + rad);
        c.drawArc(r, 135, 270, false, line);
        line.setColor(color);
        if (fromZero) c.drawArc(r, 135, 270 * v, false, line);
        else {
            float a = 135 + 270 * v;
            if (v >= 0.5f) c.drawArc(r, 270, a - 270, false, line);
            else c.drawArc(r, a, 270 - a, false, line);
            if (Math.abs(v - 0.5f) < 0.01f) c.drawPoint(cx, cy - rad, line);
        }
        fill.setColor(0xFFE9E4F7);
        double ang = Math.toRadians(135 + 270 * v);
        c.drawCircle(cx + (float) Math.cos(ang) * (rad - ui.dp(5)), cy + (float) Math.sin(ang) * (rad - ui.dp(5)), ui.dp(2), fill);
    }

    private void drawToggle(Canvas c, float x, float y, float w, String label, boolean on, int color) {
        r.set(x, y, x + w, y + ui.dp(30));
        fill.setColor(on ? color : Theme.SURFACE2);
        c.drawRoundRect(r, ui.dp(7), ui.dp(7), fill);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        text.setTextSize(ui.dp(12));
        text.setColor(on ? Theme.BG : Theme.MUTED);
        c.drawText(label, r.centerX(), r.centerY() + ui.dp(4.5f), text);
    }

    private String fit(String s, float max) {
        if (text.measureText(s) <= max) return s;
        int n = text.breakText(s, true, max - text.measureText("…"), null);
        return s.substring(0, Math.max(0, n)) + "…";
    }

    // ================================================================== касания

    private static final int NONE = 0, FADER = 1, PAN = 2, TAP = 3;
    private int mode, strip = -1;
    private float downX, downY, startVal;
    private long lastTap;
    private int lastTapStrip = -1, lastTapMode;
    private boolean changed;

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = x;
                downY = y;
                changed = false;
                strip = (int) ((x - ui.dp(6)) / stripW);
                if (strip < 0 || strip > s.p.channels.size()) {
                    strip = -1;
                    mode = NONE;
                    return true;
                }
                boolean master = strip == s.p.channels.size();
                Project.Channel ch = master ? null : s.p.channels.get(strip);
                if (y > faderTop() - ui.dp(12) && y < faderB() + ui.dp(12)) {
                    mode = FADER;
                    startVal = master ? s.p.masterVol : ch.vol;
                    getParent().requestDisallowInterceptTouchEvent(true);
                } else if (Math.abs(y - panY()) < ui.dp(22)) {
                    mode = PAN;
                    startVal = master ? s.p.masterComp : ch.pan;
                    getParent().requestDisallowInterceptTouchEvent(true);
                } else {
                    mode = TAP;
                }
                long now = System.currentTimeMillis();
                if ((mode == FADER || mode == PAN) && lastTapStrip == strip && lastTapMode == mode && now - lastTap < 300) {
                    // двойное касание — сброс
                    s.checkpoint();
                    if (mode == FADER) {
                        if (master) s.p.masterVol = 0.85f;
                        else ch.vol = 0.8f;
                    } else {
                        if (master) s.p.masterComp = 0.25f;
                        else ch.pan = 0f;
                    }
                    s.tweaked();
                    mode = NONE;
                    invalidate();
                }
                lastTap = now;
                lastTapStrip = strip;
                lastTapMode = mode;
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (strip < 0) return true;
                boolean master = strip == s.p.channels.size();
                Project.Channel ch = master ? null : s.p.channels.get(strip);
                if (mode == FADER) {
                    if (!changed && Math.abs(y - downY) > slop / 2) {
                        s.checkpoint();
                        changed = true;
                    }
                    if (changed) {
                        float dv = -(y - downY) / (faderB() - faderTop()) * VOL_MAX;
                        float v = Math.max(0, Math.min(VOL_MAX, startVal + dv));
                        if (master) s.p.masterVol = v;
                        else ch.vol = v;
                        invalidate();
                    }
                } else if (mode == PAN) {
                    if (!changed && Math.abs(y - downY) + Math.abs(x - downX) > slop / 2) {
                        s.checkpoint();
                        changed = true;
                    }
                    if (changed) {
                        float d = (-(y - downY) + (x - downX)) / ui.dp(120);
                        if (master) s.p.masterComp = Math.max(0, Math.min(1, startVal + d));
                        else ch.pan = Math.max(-1, Math.min(1, startVal + d * 2));
                        invalidate();
                    }
                } else if (mode == TAP && (Math.abs(x - downX) > slop || Math.abs(y - downY) > slop)) {
                    mode = NONE; // горизонтальная прокрутка уйдёт родителю
                }
                return true;
            }
            case MotionEvent.ACTION_UP: {
                if (mode == TAP && strip >= 0) tap(strip, y);
                if (changed) s.tweaked();
                mode = NONE;
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                if (changed) s.tweaked();
                mode = NONE;
                return true;
            default:
                return true;
        }
    }

    private void tap(int i, float y) {
        boolean master = i == s.p.channels.size();
        if (master) {
            if (y < fxB() + ui.dp(6)) host.openMaster();
            return;
        }
        Project.Channel ch = s.p.channels.get(i);
        if (y >= fxTop() - ui.dp(6) && y <= fxB() + ui.dp(6)) {
            s.select(ch);
            host.openFx(ch);
        } else if (y >= msTop() - ui.dp(6)) {
            float x0 = ui.dp(6) + i * stripW, bw = (stripW - ui.dp(24)) / 2;
            s.checkpoint();
            if (downX < x0 + ui.dp(12) + bw) ch.mute = !ch.mute;
            else ch.solo = !ch.solo;
            s.tweaked();
        } else if (y < nameB() + ui.dp(4)) {
            s.select(ch);
        }
        invalidate();
    }
}
