package com.neondrift.studio;

/** Кирпичики обработки звука: фильтры, огибающие, генераторы, перегруз. Без Android, без выделения памяти в цикле. */
final class Dsp {
    private Dsp() {}

    static final double TAU = Math.PI * 2;

    static float dbToGain(float db) {
        return (float) Math.pow(10, db / 20.0);
    }

    static float gainToDb(float g) {
        return g <= 1e-6f ? -120f : (float) (20 * Math.log10(g));
    }

    static double midiToHz(double key) {
        return 440.0 * Math.pow(2, (key - 69) / 12.0);
    }

    static double semis(double s) {
        return Math.pow(2, s / 12.0);
    }

    /** Быстрый «tanh»: мягкое ограничение без дорогой экспоненты. */
    static float soft(float x) {
        if (x > 3f) return 1f;
        if (x < -3f) return -1f;
        float x2 = x * x;
        return x * (27f + x2) / (27f + 9f * x2);
    }

    static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : v > hi ? hi : v;
    }

    // ================================================================== шум

    private static int seed = 0x1234567;

    /** Белый шум −1…1 (xorshift). */
    static float noise() {
        seed ^= seed << 13;
        seed ^= seed >>> 17;
        seed ^= seed << 5;
        return (seed & 0xFFFFFF) / (float) 0x7FFFFF - 1f;
    }

    // ================================================================== синус по таблице

    private static final int TABLE = 4096;
    private static final float[] SIN = new float[TABLE + 1];

    static {
        for (int i = 0; i <= TABLE; i++) SIN[i] = (float) Math.sin(TAU * i / TABLE);
    }

    /** sin(2π·phase), phase в [0, 1). */
    static float sin01(double phase) {
        double p = phase - Math.floor(phase);
        double x = p * TABLE;
        int i = (int) x;
        float f = (float) (x - i);
        return SIN[i] + (SIN[i + 1] - SIN[i]) * f;
    }

    // ================================================================== генераторы без алиасинга

    /** Поправка PolyBLEP для разрывов пилы и меандра. */
    static float blep(double t, double dt) {
        if (t < dt) {
            double x = t / dt;
            return (float) (x + x - x * x - 1);
        }
        if (t > 1 - dt) {
            double x = (t - 1) / dt;
            return (float) (x * x + x + x + 1);
        }
        return 0f;
    }

    static final int SINE = 0, SAW = 1, SQUARE = 2, TRIANGLE = 3, NOISE = 4;
    static final String[] WAVES = {"Синус", "Пила", "Меандр", "Треугольник", "Шум"};

    /** Значение волны в фазе phase с шагом dt (доля периода за сэмпл). */
    static float wave(int type, double phase, double dt) {
        switch (type) {
            case SAW:
                return (float) (2 * phase - 1) - blep(phase, dt);
            case SQUARE: {
                float v = phase < 0.5 ? 1f : -1f;
                double p2 = phase + 0.5;
                if (p2 >= 1) p2 -= 1;
                return v + blep(phase, dt) - blep(p2, dt);
            }
            case TRIANGLE:
                return (float) (phase < 0.5 ? 4 * phase - 1 : 3 - 4 * phase);
            case NOISE:
                return noise();
            default:
                return sin01(phase);
        }
    }

    // ================================================================== фильтр SVF (Саймпсон / Задавалин)

    static final int LP = 0, HP = 1, BP = 2, NOTCH = 3;
    static final String[] FILTERS = {"Низкие", "Высокие", "Полоса", "Вырез"};

    static final class Svf {
        private float ic1, ic2, a1, a2, a3, k;
        private float lastCut = -1, lastRes = -1;
        float low, band, high;

        /** cutoff — Гц, res — 0…1 (почти самовозбуждение у 1). */
        void set(float cutoff, float res, float sr) {
            if (cutoff == lastCut && res == lastRes) return;
            lastCut = cutoff;
            lastRes = res;
            float fc = clamp(cutoff, 15f, sr * 0.47f);
            float g = (float) Math.tan(Math.PI * fc / sr);
            k = 2f - 1.96f * clamp(res, 0f, 1f);
            a1 = 1f / (1f + g * (g + k));
            a2 = g * a1;
            a3 = g * a2;
        }

        float process(float x) {
            float v3 = x - ic2;
            float v1 = a1 * ic1 + a2 * v3;
            float v2 = ic2 + a2 * ic1 + a3 * v3;
            ic1 = 2 * v1 - ic1;
            ic2 = 2 * v2 - ic2;
            low = v2;
            band = v1;
            high = x - k * v1 - v2;
            return v2;
        }

        float out(int type) {
            switch (type) {
                case HP: return high;
                case BP: return band;
                case NOTCH: return low + high;
                default: return low;
            }
        }

        void reset() {
            ic1 = ic2 = 0;
        }
    }

    // ================================================================== биквад (эквалайзер)

    static final class Biquad {
        private float b0 = 1, b1, b2, a1, a2, z1, z2;

        void peak(float f, float q, float gainDb, float sr) {
            double A = Math.pow(10, gainDb / 40.0), w = TAU * f / sr, alpha = Math.sin(w) / (2 * q), cs = Math.cos(w);
            double a0 = 1 + alpha / A;
            b0 = (float) ((1 + alpha * A) / a0);
            b1 = (float) (-2 * cs / a0);
            b2 = (float) ((1 - alpha * A) / a0);
            a1 = (float) (-2 * cs / a0);
            a2 = (float) ((1 - alpha / A) / a0);
        }

        void shelf(boolean low, float f, float gainDb, float sr) {
            double A = Math.pow(10, gainDb / 40.0), w = TAU * f / sr, cs = Math.cos(w), sn = Math.sin(w);
            double alpha = sn / 2 * Math.sqrt(2), sq = 2 * Math.sqrt(A) * alpha;
            double a0;
            if (low) {
                a0 = (A + 1) + (A - 1) * cs + sq;
                b0 = (float) (A * ((A + 1) - (A - 1) * cs + sq) / a0);
                b1 = (float) (2 * A * ((A - 1) - (A + 1) * cs) / a0);
                b2 = (float) (A * ((A + 1) - (A - 1) * cs - sq) / a0);
                a1 = (float) (-2 * ((A - 1) + (A + 1) * cs) / a0);
                a2 = (float) (((A + 1) + (A - 1) * cs - sq) / a0);
            } else {
                a0 = (A + 1) - (A - 1) * cs + sq;
                b0 = (float) (A * ((A + 1) + (A - 1) * cs + sq) / a0);
                b1 = (float) (-2 * A * ((A - 1) + (A + 1) * cs) / a0);
                b2 = (float) (A * ((A + 1) + (A - 1) * cs - sq) / a0);
                a1 = (float) (2 * ((A - 1) - (A + 1) * cs) / a0);
                a2 = (float) (((A + 1) - (A - 1) * cs - sq) / a0);
            }
        }

        float process(float x) {
            float y = b0 * x + z1;
            z1 = b1 * x - a1 * y + z2;
            z2 = b2 * x - a2 * y;
            return y;
        }

        void reset() {
            z1 = z2 = 0;
        }
    }

    // ================================================================== огибающая ADSR

    static final class Adsr {
        static final int IDLE = 0, ATTACK = 1, DECAY = 2, SUSTAIN = 3, RELEASE = 4;
        int stage = IDLE;
        float level;
        private float attackStep, decayCoef, sustain, releaseCoef;

        /** Времена в секундах; sustain 0…1. Спад и затухание экспоненциальные (−60 дБ за указанное время). */
        void set(float a, float d, float s, float r, float sr) {
            attackStep = a <= 0.0005f ? 1f : 1f / (a * sr);
            decayCoef = coef(d, sr);
            sustain = clamp(s, 0f, 1f);
            releaseCoef = coef(r, sr);
        }

        static float coef(float t, float sr) {
            if (t <= 0.0005f) return 0f;
            return (float) Math.exp(-6.9077553 / (t * sr));
        }

        void gate(boolean on) {
            if (on) stage = ATTACK;
            else if (stage != IDLE) stage = RELEASE;
        }

        void reset() {
            stage = IDLE;
            level = 0;
        }

        float next() {
            switch (stage) {
                case ATTACK:
                    level += attackStep;
                    if (level >= 1f) {
                        level = 1f;
                        stage = DECAY;
                    }
                    break;
                case DECAY:
                    level = sustain + (level - sustain) * decayCoef;
                    if (level - sustain < 1e-4f) {
                        level = sustain;
                        stage = sustain <= 0.0001f ? IDLE : SUSTAIN;
                    }
                    break;
                case RELEASE:
                    level *= releaseCoef;
                    if (level < 1e-5f) {
                        level = 0;
                        stage = IDLE;
                    }
                    break;
                default:
                    break;
            }
            return level;
        }

        boolean active() {
            return stage != IDLE;
        }
    }

    /** Сглаживание параметра (без щелчков при движении ручек). */
    static final class Smooth {
        float value, target;
        private final float coef;

        Smooth(float initial, float ms, float sr) {
            value = target = initial;
            coef = (float) Math.exp(-1.0 / (ms * 0.001 * sr));
        }

        float next() {
            value = target + (value - target) * coef;
            return value;
        }
    }
}
