package com.neondrift.studio;

import android.content.Context;

/** Цвета приложения. Акцент выбирается в настройках. */
final class Theme {
    private Theme() {}

    static final int BG = 0xFF0A0812;
    static final int SURFACE = 0xFF15111F;
    static final int SURFACE2 = 0xFF1E1930;
    static final int LINE = 0xFF2B2442;
    static final int TEXT = 0xFFF2EEFF;
    static final int MUTED = 0xFF9A91B8;
    static final int PANEL = 0xF5120F1C;
    static final int SCRIM = 0x8C000000;

    static final String[] ACCENT_NAMES = {"Неон", "Циан", "Фиолет", "Лайм", "Закат", "Лёд"};
    static final int[] ACCENTS = {0xFFFF2D95, 0xFF00E5FF, 0xFF9D6BFF, 0xFF8CFF5A, 0xFFFF8A3D, 0xFF8FD8FF};
    static final int[] ACCENTS2 = {0xFF00E5FF, 0xFFFF2D95, 0xFFFF4FD8, 0xFF00FFA3, 0xFFFF2E88, 0xFF5C8DFF};

    static int ACCENT = ACCENTS[0];
    static int ACCENT2 = ACCENTS2[0];

    static void load(Context c) {
        int i = new Prefs(c).accent();
        if (i < 0 || i >= ACCENTS.length) i = 0;
        ACCENT = ACCENTS[i];
        ACCENT2 = ACCENTS2[i];
    }

    static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }

    /** Смешать два цвета, t от 0 до 1. */
    static int mix(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 255, ag = (a >> 8) & 255, ab = a & 255, aa = (a >>> 24);
        int br = (b >> 16) & 255, bg = (b >> 8) & 255, bb = b & 255, ba = (b >>> 24);
        return (Math.round(aa + (ba - aa) * t) << 24) | (Math.round(ar + (br - ar) * t) << 16)
                | (Math.round(ag + (bg - ag) * t) << 8) | Math.round(ab + (bb - ab) * t);
    }
}
