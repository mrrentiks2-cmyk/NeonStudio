package com.neondrift.studio;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Choreographer;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Студия: транспорт сверху, страница посередине, вкладки снизу (или слева в горизонтали). */
public class StudioActivity extends Activity implements Studio.Listener, Panels.Nav, RackView.Host, PianoRollView.Host,
        PlaylistView.Host, MixerView.Host, BrowserPage.Host {

    static final int TAB_RACK = 0, TAB_PIANO = 1, TAB_PLAYLIST = 2, TAB_MIXER = 3, TAB_SOUNDS = 4, TAB_PADS = 5;
    static final String[] TAB_NAMES = {"Каналы", "Пиано", "Плейлист", "Микшер", "Звуки", "Пэды"};
    static final String[] TAB_ICONS = {"steps", "piano", "playlist", "mixer", "folder", "pads"};
    private static final int REQ_ZIP = 11, REQ_FILES = 12, REQ_TREE = 13, REQ_SAVE = 14, REQ_MIC = 15;

    private Studio s;
    private Ui ui;
    private Panels panels;
    private SidePanel panel;
    private FrameLayout root, content;
    private LinearLayout transport, toolbar, tabsBar;
    private HorizontalScrollView toolbarScroll;
    private final ArrayList<View> tabViews = new ArrayList<>();
    private ImageView playBtn, recBtn, undoBtn, redoBtn, metroBtn;
    private TextView nameText, posText, bpmText, modeChip, toastView;
    private RackView rack;
    private PianoRollView piano;
    private PlaylistView playlist;
    private HorizontalScrollView mixerScroll;
    private MixerView mixer;
    private BrowserPage browser;
    private PadsView pads;
    private View[] pages;
    private int tab = TAB_RACK, prevTab = TAB_RACK;
    private Project.Channel pickTarget;
    private String brushId;
    private File pendingSave;
    private Runnable pendingMic;
    private boolean ticking, lastPlaying, lastRec;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        ui = new Ui(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        String id = getIntent().getStringExtra("id");
        Project p;
        try {
            p = ProjectStore.load(this, id == null ? "" : id);
        } catch (IOException e) {
            android.widget.Toast.makeText(this, "Проект не открылся: " + e.getMessage(), android.widget.Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        s = new Studio(this, p);
        s.listener = this;
        new Prefs(this).put("lastProject", p.id);
        build();
        if (b != null) tab = b.getInt("tab", TAB_RACK);
        else if (p.songMode && !p.clips.isEmpty()) tab = TAB_PLAYLIST;
        showTab(tab);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        out.putInt("tab", tab);
    }

    // ================================================================== разметка

    private void build() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Theme.BG);
        transport = buildTransport();
        toolbar = ui.row();
        toolbar.setPadding(ui.dp(8), 0, ui.dp(8), 0);
        toolbarScroll = new HorizontalScrollView(this);
        toolbarScroll.setHorizontalScrollBarEnabled(false);
        toolbarScroll.addView(toolbar, new FrameLayout.LayoutParams(Ui.WRAP, Ui.MATCH));
        content = new FrameLayout(this);
        rack = new RackView(this, s, ui, this);
        piano = new PianoRollView(this, s, ui, this);
        playlist = new PlaylistView(this, s, ui, this);
        mixer = new MixerView(this, s, ui, this);
        mixerScroll = new HorizontalScrollView(this);
        mixerScroll.setHorizontalScrollBarEnabled(false);
        mixerScroll.setFillViewport(true);
        mixerScroll.addView(mixer, new FrameLayout.LayoutParams(Ui.WRAP, Ui.MATCH));
        browser = new BrowserPage(this, s, ui, this);
        pads = new PadsView(this, s, ui);
        pages = new View[]{rack, piano, playlist, mixerScroll, browser, pads};
        for (View v : pages) {
            v.setVisibility(View.GONE);
            content.addView(v, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        }
        tabsBar = new LinearLayout(this);
        for (int i = 0; i < TAB_NAMES.length; i++) {
            final int k = i;
            LinearLayout t = ui.col();
            t.setGravity(Gravity.CENTER);
            ImageView ic = new ImageView(this);
            ic.setImageDrawable(new Glyph(TAB_ICONS[i], Theme.MUTED));
            t.addView(ic, Ui.lp(ui.dp(24), ui.dp(24)));
            TextView l = ui.text(TAB_NAMES[i], 10.5f, Theme.MUTED, false);
            l.setGravity(Gravity.CENTER);
            t.addView(l, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
            t.setBackground(Ui.ripple(null, Ui.round(0xFFFFFFFF, ui.dp(12))));
            t.setOnClickListener(v -> showTab(k));
            tabViews.add(t);
        }
        panel = new SidePanel(this, ui);
        toastView = ui.text("", 14, Theme.TEXT, false);
        toastView.setBackground(Ui.round(0xF0221B35, ui.dp(14)));
        toastView.setPadding(ui.dp(16), ui.dp(12), ui.dp(16), ui.dp(12));
        toastView.setVisibility(View.GONE);
        toastView.setMaxLines(4);
        panels = new Panels(this, s, ui, panel, this);
        arrange();
        setContentView(root);
    }

    /** Вертикально — вкладки снизу; горизонтально — колонкой слева, чтобы сберечь высоту. */
    private void arrange() {
        for (View v : new View[]{transport, toolbarScroll, content, tabsBar, panel, toastView}) {
            if (v.getParent() != null) ((ViewGroup) v.getParent()).removeView(v);
        }
        for (View t : tabViews) if (t.getParent() != null) ((ViewGroup) t.getParent()).removeView(t);
        root.removeAllViews();
        boolean land = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        LinearLayout column = ui.col();
        column.addView(transport, Ui.lp(Ui.MATCH, ui.dp(54)));
        column.addView(toolbarScroll, Ui.lp(Ui.MATCH, ui.dp(44)));
        column.addView(content, Ui.lp(Ui.MATCH, 0, 1f));
        tabsBar.setOrientation(land ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        tabsBar.setBackgroundColor(0xFF0D0B14);
        for (View t : tabViews) {
            LinearLayout.LayoutParams lp = land ? Ui.lp(Ui.MATCH, 0, 1f) : Ui.lp(0, Ui.MATCH, 1f);
            tabsBar.addView(t, lp);
        }
        if (land) {
            LinearLayout row = ui.row();
            row.setGravity(Gravity.TOP);
            row.addView(tabsBar, Ui.lp(ui.dp(68), Ui.MATCH));
            row.addView(column, Ui.lp(0, Ui.MATCH, 1f));
            root.addView(row, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        } else {
            LinearLayout all = ui.col();
            all.addView(column, Ui.lp(Ui.MATCH, 0, 1f));
            all.addView(tabsBar, Ui.lp(Ui.MATCH, ui.dp(58)));
            root.addView(all, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        }
        root.addView(panel, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        tl.bottomMargin = ui.dp(land ? 20 : 74);
        tl.leftMargin = tl.rightMargin = ui.dp(16);
        root.addView(toastView, tl);
        updateTransport();
    }

    @Override
    public void onConfigurationChanged(Configuration c) {
        super.onConfigurationChanged(c);
        if (panel.isOpen()) panel.close();
        transport = buildTransport();
        arrange();
        buildToolbar();
        piano.fit();
        playlist.fit();
    }

    private LinearLayout buildTransport() {
        LinearLayout t = ui.row();
        t.setPadding(ui.dp(2), 0, ui.dp(6), 0);
        t.setBackgroundColor(Theme.SURFACE);
        boolean wide = getResources().getConfiguration().screenWidthDp >= 560;
        t.addView(ui.iconButton("back", Theme.TEXT, 40, 9, v -> finish()));
        LinearLayout texts = ui.col();
        nameText = ui.oneLine(s.p.name, 14, Theme.TEXT, true);
        nameText.setOnClickListener(v -> panels.project());
        texts.addView(nameText);
        posText = ui.oneLine("", 12, Theme.MUTED, false);
        posText.setTypeface(Typeface.MONOSPACE);
        texts.addView(posText, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(2), 0, 0));
        texts.setOnClickListener(v -> panels.project());
        t.addView(texts, Ui.lp(0, Ui.WRAP, 1f));
        playBtn = ui.iconButton("play", Theme.BG, 44, 10, v -> {
            s.togglePlay();
            updateTransport();
        });
        LinearLayout.LayoutParams plp = Ui.lp(ui.dp(44), ui.dp(44));
        plp.leftMargin = ui.dp(4);
        playBtn.setLayoutParams(plp);
        t.addView(playBtn);
        recBtn = ui.iconButton("record", 0xFFFF2D6E, 40, 10, v -> toggleRecord());
        t.addView(recBtn);
        bpmText = ui.text("", 14, Theme.TEXT, true);
        bpmText.setGravity(Gravity.CENTER);
        bpmText.setPadding(ui.dp(8), ui.dp(6), ui.dp(8), ui.dp(6));
        bpmText.setBackground(Ui.ripple(Ui.stroke(Theme.SURFACE2, Theme.LINE, ui.dp(1), ui.dp(10)), null));
        bpmText.setOnClickListener(v -> panels.project());
        t.addView(bpmText, Ui.margins(Ui.WRAP, Ui.WRAP, ui.dp(4), 0, ui.dp(4), 0));
        modeChip = ui.text("", 12, Theme.TEXT, true);
        modeChip.setGravity(Gravity.CENTER);
        modeChip.setPadding(ui.dp(9), ui.dp(7), ui.dp(9), ui.dp(7));
        modeChip.setOnClickListener(v -> {
            s.setSongMode(!s.p.songMode);
            updateTransport();
            invalidatePage();
        });
        t.addView(modeChip);
        metroBtn = ui.iconButton("metronome", Theme.MUTED, 40, 10, v -> {
            s.p.metronome = !s.p.metronome;
            s.syncTransport();
            s.tweaked();
            updateTransport();
        });
        if (wide) t.addView(metroBtn);
        t.addView(ui.iconButton("dice", Theme.ACCENT, 40, 10, v -> panels.generator()));
        undoBtn = ui.iconButton("undo", Theme.TEXT, 40, 10, v -> {
            if (!s.undo()) toast("Нечего отменять");
        });
        t.addView(undoBtn);
        redoBtn = ui.iconButton("redo", Theme.TEXT, 40, 10, v -> {
            if (!s.redo()) toast("Нечего повторять");
        });
        if (wide) {
            t.addView(redoBtn);
            t.addView(ui.iconButton("export", Theme.TEXT, 40, 10, v -> panels.export()));
        }
        t.addView(ui.iconButton("more", Theme.TEXT, 40, 10, v -> menu()));
        return t;
    }

    private void menu() {
        LinearLayout p = panel.open("Меню");
        panel.option(p, "Экспорт", "WAV, M4A, стемы, MIDI, бит со звуками", false, () -> panels.export());
        panel.option(p, "Проект", "Темп, свинг, тональность, мастер, реверб и эхо", false, () -> panels.project());
        panel.option(p, "Паттерны", "Выбор, длина, копии", false, () -> panels.patterns());
        panel.option(p, "Генератор бита", "Drift, Memphis, бразильский фонк, фанк", false, () -> panels.generator());
        panel.option(p, "Повторить", "Вернуть отменённое", false, () -> {
            panel.close();
            if (!s.redo()) toast("Нечего повторять");
        });
        panel.option(p, s.p.metronome ? "Метроном: вкл" : "Метроном: выкл", null, s.p.metronome, () -> {
            s.p.metronome = !s.p.metronome;
            s.syncTransport();
            s.tweaked();
            updateTransport();
            menu();
        });
        panel.option(p, "Сохранить копию", "Отдельный проект с этим состоянием", false, () -> {
            Project c = s.p.copy();
            c.name = ProjectStore.uniqueName(this, s.p.name + " (копия)");
            c.created = c.edited = System.currentTimeMillis();
            try {
                ProjectStore.save(this, c);
                toast("Копия сохранена: " + c.name);
            } catch (IOException e) {
                toast("Не сохранилось: " + e.getMessage());
            }
            panel.close();
        });
        panel.option(p, "Настройки", null, false, () -> panels.settings());
    }

    // ================================================================== вкладки

    @Override
    public void showTab(int t) {
        if (t != TAB_SOUNDS && pickTarget != null) pickTarget = null;
        if (tab != t) prevTab = tab;
        tab = t;
        for (int i = 0; i < pages.length; i++) pages[i].setVisibility(i == t ? View.VISIBLE : View.GONE);
        for (int i = 0; i < tabViews.size(); i++) {
            LinearLayout v = (LinearLayout) tabViews.get(i);
            int col = i == t ? Theme.ACCENT : Theme.MUTED;
            ((Glyph) ((ImageView) v.getChildAt(0)).getDrawable()).setColor(col);
            ((TextView) v.getChildAt(1)).setTextColor(col);
        }
        // режим воспроизведения по смыслу вкладки (не во время игры)
        if (!s.playing()) {
            if (t == TAB_PLAYLIST && !s.p.clips.isEmpty()) s.setSongMode(true);
            else if (t == TAB_RACK || t == TAB_PIANO || t == TAB_PADS) s.setSongMode(false);
        }
        if (t != TAB_SOUNDS) browser.stopPreview();
        if (t != TAB_PADS) pads.releaseAll();
        if (t == TAB_PIANO) piano.invalidate();
        if (t == TAB_MIXER) mixer.requestLayout();
        if (t == TAB_PADS) {
            Project.Channel ch = s.selected();
            if (ch != null && pads.mode != PadsView.PADS) pads.octave = Math.max(1, Math.min(7, s.defaultKey(ch) / 12 - 1));
        }
        buildToolbar();
        updateTransport();
        invalidatePage();
    }

    private void invalidatePage() {
        if (tab == TAB_MIXER) mixer.invalidate();
        else if (pages != null) pages[tab].invalidate();
    }

    // ================================================================== панель инструментов вкладки

    private TextView chip(String text, boolean on, Runnable r) {
        TextView c = ui.chip(text, on, v -> r.run());
        c.setTextSize(13);
        c.setPadding(ui.dp(12), ui.dp(7), ui.dp(12), ui.dp(7));
        LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
        lp.rightMargin = ui.dp(6);
        toolbar.addView(c, lp);
        return c;
    }

    private void icon(String name, int color, Runnable r) {
        ImageView v = ui.iconButton(name, color, 38, 9, x -> r.run());
        toolbar.addView(v);
    }

    private void label(String text) {
        TextView l = ui.text(text, 12, Theme.MUTED, false);
        l.setPadding(ui.dp(4), 0, ui.dp(8), 0);
        toolbar.addView(l);
    }

    private void buildToolbar() {
        toolbar.removeAllViews();
        toolbarScroll.setVisibility(View.VISIBLE);
        Project p = s.p;
        switch (tab) {
            case TAB_RACK: {
                Project.Pattern pt = p.current();
                chip("▾ " + pt.name, true, () -> panels.patterns());
                chip("Сила", rack.velocityMode, () -> {
                    rack.velocityMode = !rack.velocityMode;
                    buildToolbar();
                    rack.invalidate();
                });
                chip("＋ Канал", false, () -> panels.addChannel());
                chip("Генератор", false, () -> panels.generator());
                chip("Длина: " + pt.steps / 16 + " такт.", false, () -> panels.patterns());
                break;
            }
            case TAB_PIANO: {
                Project.Channel ch = s.selected();
                chip("▾ " + (ch == null ? "канал" : ch.name), true, this::pickChannel);
                String[] tools = {"Рисовать", "Выбор", "Ластик"};
                for (int i = 0; i < tools.length; i++) {
                    final int k = i;
                    chip(tools[i], piano.tool == i, () -> {
                        piano.tool = k;
                        if (k != PianoRollView.SELECT) piano.selection.clear();
                        buildToolbar();
                        piano.invalidate();
                    });
                }
                if (!piano.selection.isEmpty()) {
                    label("выделено: " + piano.selection.size());
                    icon("copy", Theme.TEXT, () -> {
                        piano.copy();
                        toast("Скопировано");
                        buildToolbar();
                    });
                    chip("Повтор", false, () -> piano.duplicate());
                    chip("Слайд", false, () -> piano.toggleSlideSelected());
                    chip("−12", false, () -> piano.transpose(-12));
                    chip("−1", false, () -> piano.transpose(-1));
                    chip("+1", false, () -> piano.transpose(1));
                    chip("+12", false, () -> piano.transpose(12));
                    icon("trash", Theme.MUTED, () -> piano.deleteSelected());
                } else {
                    chip("Слайд", piano.slideNew, () -> {
                        piano.slideNew = !piano.slideNew;
                        buildToolbar();
                    });
                    chip("Сетка " + PianoRollView.SNAP_NAMES[piano.snapIndex()], false, this::pickSnap);
                    chip(PianoRollView.STAMPS[piano.stamp], piano.stamp > 0, this::pickStamp);
                    chip("Сила", piano.velLane, () -> {
                        piano.velLane = !piano.velLane;
                        buildToolbar();
                        piano.invalidate();
                    });
                    chip("⋯", false, this::pianoMenu);
                }
                break;
            }
            case TAB_PLAYLIST: {
                Project.Clip sel = playlist.selected;
                if (sel != null) {
                    Project.Pattern pt = p.pattern(sel.pattern);
                    label(pt == null ? "клип" : pt.name);
                    chip("Открыть", false, () -> {
                        if (pt != null) {
                            p.current = pt.id;
                            s.edited();
                            showTab(TAB_RACK);
                        }
                    });
                    chip("Копия рядом", false, () -> playlist.duplicateSelected());
                    chip(sel.mute ? "Включить" : "Заглушить", false, () -> {
                        playlist.muteSelected();
                        buildToolbar();
                    });
                    chip("Уникальный", false, () -> {
                        Project.Pattern u = playlist.makeUnique();
                        if (u != null) toast("Теперь у клипа своя копия: «" + u.name + "»");
                        buildToolbar();
                    });
                    icon("trash", Theme.MUTED, () -> playlist.deleteSelected());
                } else {
                    if (brushId == null || p.pattern(brushId) == null) brushId = p.current().id;
                    label("Ставить:");
                    for (Project.Pattern pt : p.patterns) {
                        TextView c = chip(pt.name, pt.id.equals(brushId), () -> {
                            brushId = pt.id;
                            buildToolbar();
                        });
                        c.setCompoundDrawablePadding(ui.dp(6));
                        android.graphics.drawable.GradientDrawable dot = Ui.oval(pt.color);
                        dot.setBounds(0, 0, ui.dp(10), ui.dp(10));
                        c.setCompoundDrawables(dot, null, null, null);
                    }
                    chip("＋", false, () -> {
                        s.checkpoint();
                        Project.Pattern pt = new Project.Pattern();
                        pt.name = "Паттерн " + (p.patterns.size() + 1);
                        pt.color = Panels.COLORS[p.patterns.size() % Panels.COLORS.length];
                        pt.steps = p.current().steps;
                        p.patterns.add(pt);
                        p.current = pt.id;
                        brushId = pt.id;
                        s.edited();
                        buildToolbar();
                        toast("Пустой паттерн — заполните его на вкладке «Каналы»");
                    });
                }
                break;
            }
            case TAB_PADS: {
                String[] modes = {"Пэды", "Клавиши", "Лад"};
                for (int i = 0; i < modes.length; i++) {
                    final int k = i;
                    chip(modes[i], pads.mode == i, () -> {
                        pads.releaseAll();
                        pads.mode = k;
                        Project.Channel ch = s.selected();
                        if (k != PadsView.PADS && ch != null) pads.octave = Math.max(1, Math.min(7, s.defaultKey(ch) / 12 - 1));
                        buildToolbar();
                        pads.invalidate();
                    });
                }
                if (pads.mode != PadsView.PADS) {
                    Project.Channel ch = s.selected();
                    chip("▾ " + (ch == null ? "канал" : ch.name), true, this::pickChannel);
                    icon("minus", Theme.TEXT, () -> {
                        pads.octave = Math.max(0, pads.octave - 1);
                        buildToolbar();
                        pads.invalidate();
                    });
                    label("окт. " + pads.octave);
                    icon("plus", Theme.TEXT, () -> {
                        pads.octave = Math.min(8, pads.octave + 1);
                        buildToolbar();
                        pads.invalidate();
                    });
                }
                label(s.recording ? "● идёт запись в «" + p.current().name + "»" : "● — запись в паттерн");
                break;
            }
            case TAB_SOUNDS:
                if (pickTarget != null) {
                    label("Звук для «" + pickTarget.name + "» — жмите ⇄ у нужного");
                    chip("Отмена", false, () -> {
                        pickTarget = null;
                        showTab(prevTab);
                    });
                } else {
                    toolbarScroll.setVisibility(View.GONE);
                }
                break;
            case TAB_MIXER:
            default:
                chip("Мастер и эффекты", false, () -> panels.project());
                label("двойное касание фейдера — сброс");
                break;
        }
    }

    private void pickChannel() {
        LinearLayout p = panel.open("Канал");
        for (Project.Channel ch : s.p.channels) {
            String sub = ch.type == Project.SAMPLER ? Sounds.title(ch.sample) : ch.type == Project.BASS ? "808" : "синтезатор";
            panel.option(p, ch.name, sub, ch.id.equals(s.sel), () -> {
                s.select(ch);
                panel.close();
                piano.selection.clear();
                piano.fit();
                if (tab == TAB_PADS && pads.mode != PadsView.PADS) pads.octave = Math.max(1, Math.min(7, s.defaultKey(ch) / 12 - 1));
                buildToolbar();
                invalidatePage();
            });
        }
    }

    private void pickSnap() {
        LinearLayout p = panel.open("Сетка");
        for (int i = 0; i < PianoRollView.SNAPS.length; i++) {
            final int k = i;
            panel.option(p, PianoRollView.SNAP_NAMES[i], null, piano.snap == PianoRollView.SNAPS[i], () -> {
                piano.snap = PianoRollView.SNAPS[k];
                s.prefs.put("snapTicks", piano.snap);
                panel.close();
                buildToolbar();
                piano.invalidate();
            });
        }
    }

    private void pickStamp() {
        LinearLayout p = panel.open("Аккорд при рисовании");
        panel.note(p, "Касание ставит сразу весь аккорд от этой ноты. «Лада» — аккорд из нот тональности, не промахнётесь.");
        for (int i = 0; i < PianoRollView.STAMPS.length; i++) {
            final int k = i;
            panel.option(p, PianoRollView.STAMPS[i], null, piano.stamp == i, () -> {
                piano.stamp = k;
                panel.close();
                buildToolbar();
            });
        }
    }

    private void pianoMenu() {
        LinearLayout p = panel.open("Ноты");
        panel.option(p, "Выделить всё", null, false, () -> {
            piano.tool = PianoRollView.SELECT;
            piano.selectAll();
            panel.close();
            buildToolbar();
        });
        if (piano.canPaste()) panel.option(p, "Вставить", "В начало видимой части", false, () -> {
            piano.paste();
            panel.close();
        });
        panel.option(p, "Квантовать", "Ноты — точно по сетке", false, () -> {
            piano.quantize();
            panel.close();
        });
        panel.option(p, "В лад", "Притянуть ноты к тональности " + Theory.KEYS[s.p.key] + " " + Theory.SCALE_NAMES[s.p.scale], false, () -> {
            piano.toScale();
            panel.close();
        });
        panel.option(p, "Повторить в конце", "Удвоить ноты (паттерн удлинится)", false, () -> {
            piano.duplicate();
            panel.close();
        });
        panel.option(p, piano.ghosts ? "Ноты других каналов: видны" : "Ноты других каналов: скрыты", null, piano.ghosts, () -> {
            piano.ghosts = !piano.ghosts;
            piano.invalidate();
            pianoMenu();
        });
        panel.option(p, "Показать всё", "Масштаб по паттерну", false, () -> {
            piano.fit();
            panel.close();
        });
        panel.option(p, "Очистить канал", "Стереть ноты в этом паттерне", false, () -> {
            Project.Channel ch = s.selected();
            if (ch != null) {
                s.checkpoint();
                s.p.current().notes.remove(ch.id);
                piano.selection.clear();
                s.edited();
            }
            panel.close();
            piano.invalidate();
        });
    }

    // ================================================================== транспорт

    private void updateTransport() {
        if (s == null || playBtn == null) return;
        boolean playing = s.playing();
        playBtn.setImageDrawable(new Glyph(playing ? "stop" : "play", Theme.BG));
        playBtn.setBackground(Ui.ripple(Ui.oval(playing ? Theme.ACCENT2 : Theme.ACCENT), Ui.oval(0xFFFFFFFF)));
        recBtn.setBackground(s.recording ? Ui.ripple(Ui.oval(0x55FF2D6E), Ui.oval(0xFFFFFFFF)) : Ui.ripple(null, Ui.oval(0xFFFFFFFF)));
        bpmText.setText(Panels.fmtBpm(s.p.bpm));
        boolean song = s.p.songMode;
        modeChip.setText(song ? "ПЕСНЯ" : "ПАТ");
        modeChip.setTextColor(song ? Theme.BG : Theme.TEXT);
        modeChip.setBackground(Ui.ripple(song ? Ui.round(Theme.ACCENT2, ui.dp(10)) : Ui.stroke(Theme.SURFACE2, Theme.LINE, ui.dp(1), ui.dp(10)), null));
        ((Glyph) metroBtn.getDrawable()).setColor(s.p.metronome ? Theme.ACCENT : Theme.MUTED);
        ((Glyph) undoBtn.getDrawable()).setColor(s.canUndo() ? Theme.TEXT : 0xFF4A4458);
        ((Glyph) redoBtn.getDrawable()).setColor(s.canRedo() ? Theme.TEXT : 0xFF4A4458);
        nameText.setText(s.p.name);
        updatePosition();
        lastPlaying = playing;
        lastRec = s.recording;
    }

    private void updatePosition() {
        double t = s.playing() ? s.position() : 0;
        int bar = (int) (t / (Project.BAR * Project.STEP)) + 1, beat = (int) (t % (Project.BAR * Project.STEP) / Project.PPQ) + 1,
                st = (int) (t % Project.PPQ / Project.STEP) + 1;
        String where = s.engine.songMode ? "песня" : s.p.current().name;
        String key = Theory.KEYS[s.p.key] + " " + Theory.SCALE_NAMES[s.p.scale].split(" ")[0].toLowerCase(Locale.ROOT);
        posText.setText(String.format(Locale.ROOT, "%s%d.%d.%d · %s · %s", s.recording ? "● " : "", bar, beat, st, where, key));
    }

    private void toggleRecord() {
        if (s.recording) {
            s.stopRecording();
            toast("Запись остановлена — «Отменить» уберёт весь дубль");
        } else {
            if (tab != TAB_PADS && tab != TAB_PIANO) showTab(TAB_PADS);
            s.startRecording();
            toast("Запись: играйте на пэдах — ноты встают в «" + s.p.current().name + "»");
        }
        updateTransport();
        buildToolbar();
    }

    private final Choreographer.FrameCallback frame = new Choreographer.FrameCallback() {
        private long lastPos;

        @Override
        public void doFrame(long now) {
            if (!ticking) return;
            boolean playing = s.playing();
            if (playing != lastPlaying || s.recording != lastRec) updateTransport();
            if (playing && now - lastPos > 33_000_000L) {
                lastPos = now;
                updatePosition();
                if (tab != TAB_SOUNDS && tab != TAB_PADS) invalidatePage();
            } else if (tab == TAB_MIXER && now - lastPos > 33_000_000L) {
                lastPos = now;
                mixer.invalidate(); // спад индикаторов
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
        if (s == null) return;
        s.out.start();
        ticking = true;
        Choreographer.getInstance().postFrameCallback(frame);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (s != null) s.saveSync();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (s == null) return;
        ticking = false;
        browser.stopRecord();
        if (s.recording) s.stopRecording();
        s.engine.stop();
        s.saveNow();
        s.out.stop();
        updateTransport();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (s != null) s.release();
    }

    @Override
    public void onBackPressed() {
        if (panel != null && panel.isOpen()) panel.close();
        else if (tab == TAB_SOUNDS && pickTarget != null) {
            pickTarget = null;
            showTab(prevTab);
        } else super.onBackPressed();
    }

    // ================================================================== Studio.Listener

    @Override
    public void onProjectReplaced() {
        piano.selection.clear();
        playlist.selected = null;
        if (panel.isOpen()) panel.close();
        mixer.requestLayout();
        buildToolbar();
        updateTransport();
        invalidatePage();
    }

    @Override
    public void onContentChanged() {
        buildToolbar();
        updateTransport();
        invalidatePage();
    }

    @Override
    public void onSoundsLoaded() {
        invalidatePage();
    }

    // ================================================================== Panels.Nav

    @Override
    public void refresh() {
        mixer.requestLayout();
        buildToolbar();
        updateTransport();
        invalidatePage();
    }

    @Override
    public void pickSoundFor(Project.Channel ch) {
        pickTarget = ch;
        int back = tab;
        showTab(TAB_SOUNDS);
        prevTab = back;
        pickTarget = ch;
        buildToolbar();
    }

    @Override
    public void openPiano(Project.Channel ch) {
        s.select(ch);
        piano.selection.clear();
        piano.fit();
        showTab(TAB_PIANO);
    }

    @Override
    public void toast(String text) {
        toastView.setText(text);
        toastView.setVisibility(View.VISIBLE);
        toastView.setAlpha(0f);
        toastView.animate().alpha(1f).setDuration(150).start();
        toastView.removeCallbacks(hideToast);
        toastView.postDelayed(hideToast, Math.max(2200, text.length() * 55L));
    }

    private final Runnable hideToast = () -> toastView.animate().alpha(0f).setDuration(200).withEndAction(() -> toastView.setVisibility(View.GONE)).start();

    @Override
    public void share(File f) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType(Files.type(f.getName()));
        i.putExtra(Intent.EXTRA_STREAM, Files.uri(this, f));
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(i, f.getName()));
        } catch (Exception e) {
            toast("Некуда отправить");
        }
    }

    @Override
    public void saveAs(File f) {
        pendingSave = f;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(Files.type(f.getName()));
        i.putExtra(Intent.EXTRA_TITLE, f.getName());
        try {
            startActivityForResult(i, REQ_SAVE);
        } catch (Exception e) {
            toast("Нет приложения для сохранения файлов");
        }
    }

    @Override
    public void projectReplaced() {
        onProjectReplaced();
        playlist.fit();
        piano.fit();
    }

    // ================================================================== RackView.Host

    @Override
    public void openChannel(Project.Channel c) {
        rack.invalidate();
        panels.channel(c);
    }

    @Override
    public void channelMenu(Project.Channel c) {
        panels.channelMenu(c);
    }

    @Override
    public void addChannel() {
        panels.addChannel();
    }

    // ================================================================== PianoRollView.Host / PlaylistView.Host

    @Override
    public void onSelectionChanged() {
        buildToolbar();
    }

    @Override
    public void onClipSelected(Project.Clip c) {
        buildToolbar();
    }

    @Override
    public Project.Pattern brush() {
        Project.Pattern pt = brushId == null ? null : s.p.pattern(brushId);
        return pt != null ? pt : s.p.current();
    }

    // ================================================================== MixerView.Host

    @Override
    public void openFx(Project.Channel c) {
        panels.fx(c);
    }

    @Override
    public void openMaster() {
        panels.project();
    }

    // ================================================================== BrowserPage.Host

    @Override
    public void addChannelWithSound(String ref, String name, String category) {
        s.checkpoint();
        Project.Channel ch = channelFor(ref, name, category);
        s.p.channels.add(ch);
        s.select(ch);
        s.edited();
        toast("Канал «" + ch.name + "» добавлен");
        if ("Петли".equals(category)) fitLoop(ch, ref);
    }

    private Project.Channel channelFor(String ref, String name, String category) {
        String role;
        switch (category == null ? "" : category) {
            case "Бочки": role = "kick"; break;
            case "Малые": role = "snare"; break;
            case "Клэпы": role = "clap"; break;
            case "Хэты": role = "hat"; break;
            case "Ковбелл": role = "cowbell"; break;
            case "Перкуссия": role = "perc"; break;
            default: role = "fx";
        }
        Project.Channel ch = Presets.make(role);
        ch.sample = ref;
        ch.role = "";
        String low = name.toLowerCase(Locale.ROOT);
        String nm = name.length() > 18 ? name.substring(0, 18).trim() : name;
        ch.name = nm;
        if ("Хэты".equals(category) && (low.contains("open") || low.contains("oh") || low.contains("откр"))) ch.choke = 1;
        if ("808".equals(category)) {
            ch.color = 0xFFB57BFF;
            ch.mode = Project.GATE;
            ch.release = 0.08f;
            ch.choke = 2; // новая нота обрывает хвост, как у настоящего 808
            ch.duck = 0.25f;
            ch.sendRev = 0;
        } else if ("Ковбелл".equals(category)) {
            ch.root = 60;
        } else if ("Вокал".equals(category)) {
            ch.color = 0xFFFF4F9A;
            ch.sendRev = 0.18f;
        } else if ("Петли".equals(category) || "Мелодии".equals(category)) {
            ch.color = 0xFF5C8DFF;
            ch.sendRev = 0;
        }
        if (Sounds.builtin(ref)) {
            String id = ref.substring(Kits.PREFIX.length());
            if (id.startsWith("b808")) {
                ch.root = 36;
                ch.mode = Project.GATE;
                ch.choke = 2;
            } else if (id.startsWith("cowbell") || id.startsWith("bell")) ch.root = 72;
            if (id.equals("vinyl")) ch.mode = Project.LOOP;
        }
        return ch;
    }

    /** Петля: подогнать под темп и поставить ноту на весь паттерн. */
    private void fitLoop(Project.Channel ch, String ref) {
        float named = Library.bpm(ref);
        s.loadSound(ref, smp -> {
            if (smp == null) return;
            float sec = smp.seconds();
            float beats;
            if (named > 0) beats = Math.round(sec * named / 60f);
            else {
                float raw = sec * s.p.bpm / 60f;
                beats = 1;
                for (int b : new int[]{1, 2, 4, 8, 16, 32}) if (Math.abs(raw - b) < Math.abs(raw - beats)) beats = b;
            }
            beats = Math.max(1, beats);
            ch.fitBeats = beats;
            Project.Pattern pt = s.p.current();
            int len = (int) Math.min(pt.ticks(), beats * Project.PPQ);
            List<Project.Note> notes = pt.notes(ch.id);
            if (notes.isEmpty()) {
                for (int at = 0; at < pt.ticks(); at += len) notes.add(new Project.Note(at, len, ch.root, 0.8f));
            }
            s.edited();
            toast("Петля подогнана под " + Panels.fmtBpm(s.p.bpm) + " BPM (" + Math.round(beats) + " дол.)");
            invalidatePage();
        });
    }

    @Override
    public void replaceSound(String ref) {
        Project.Channel ch = pickTarget != null ? pickTarget : s.selected();
        if (ch == null) {
            addChannelWithSound(ref, Sounds.title(ref), "");
            return;
        }
        s.checkpoint();
        ch.type = Project.SAMPLER;
        ch.sample = ref;
        ch.start = 0;
        ch.end = 1;
        ch.slices = 0;
        ch.sliceMarks = "";
        ch.fitBeats = 0;
        if (Sounds.builtin(ref)) {
            String id = ref.substring(Kits.PREFIX.length());
            ch.root = id.startsWith("b808") ? 36 : id.startsWith("cowbell") || id.startsWith("bell") ? 72 : 60;
        }
        s.edited();
        toast("Звук «" + ch.name + "» → " + Sounds.title(ref));
        if (pickTarget != null) {
            pickTarget = null;
            showTab(prevTab);
            panels.channel(ch);
        }
    }

    @Override
    public void insertMidi(String ref, String name) {
        new Thread(() -> {
            try {
                Midi.Result r = Library.midi(this, ref);
                runOnUiThread(() -> midiChoice(r, name));
            } catch (IOException e) {
                runOnUiThread(() -> toast("MIDI не читается: " + e.getMessage()));
            }
        }, "neon-midi").start();
    }

    private void midiChoice(Midi.Result r, String name) {
        if (r.notes.isEmpty()) {
            toast("В файле нет нот");
            return;
        }
        boolean drums = MidiImport.looksLikeDrums(r, name);
        LinearLayout p = panel.open("MIDI: " + name);
        panel.note(p, "Нот: " + r.notes.size() + (r.bpm > 0 ? " · темп файла " + Panels.fmtBpm(r.bpm) + " BPM" : "")
                + ". Вставится в паттерн «" + s.p.current().name + "» (он удлинится при необходимости).");
        Project.Channel sel = s.selected();
        if (sel != null) panel.option(p, "Мелодией в «" + sel.name + "»", "Ноты канала в паттерне заменятся", !drums, () -> {
            s.checkpoint();
            int n = MidiImport.melody(s.p.current(), sel, r.notes);
            s.edited();
            panel.close();
            toast("Вставлено нот: " + n);
            openPiano(sel);
        });
        panel.option(p, "Барабанами по каналам", "Бочка, малый, хэты… — раскладка General MIDI", drums, () -> {
            s.checkpoint();
            int n = MidiImport.drums(s.p, s.p.current(), r.notes, s);
            s.edited();
            panel.close();
            toast("Вставлено нот: " + n);
            showTab(TAB_RACK);
        });
        panel.option(p, "В новый синтезатор", "Канал «" + Presets.SYNTH[0] + "» с этими нотами", false, () -> {
            s.checkpoint();
            Project.Channel ch = Presets.make("lead");
            ch.name = name.length() > 18 ? name.substring(0, 18) : name;
            s.p.channels.add(ch);
            MidiImport.melody(s.p.current(), ch, r.notes);
            s.select(ch);
            s.edited();
            panel.close();
            openPiano(ch);
        });
        if (r.bpm > 0 && Math.abs(r.bpm - s.p.bpm) > 0.5f) {
            LinearLayout row = panel.chipRow(p);
            panel.chip(row, "Взять темп файла (" + Panels.fmtBpm(r.bpm) + ")", false, () -> {
                s.checkpoint();
                s.p.bpm = Math.max(40, Math.min(300, r.bpm));
                s.syncTransport();
                s.tweaked();
                updateTransport();
                toast("Темп " + Panels.fmtBpm(s.p.bpm) + " BPM");
            });
        }
    }

    @Override
    public void importZip() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/x-zip",
                "application/octet-stream", "application/x-rar-compressed", "application/vnd.rar", "application/x-7z-compressed"});
        launch(i, REQ_ZIP);
    }

    @Override
    public void importFiles() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "audio/midi", "audio/x-midi", "application/x-midi", "application/zip"});
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        launch(i, REQ_FILES);
    }

    @Override
    public void importFolder() {
        launch(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE);
    }

    private void launch(Intent i, int req) {
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            toast("Нет приложения для выбора файлов");
        }
    }

    @Override
    public void deletePack(String pack) {
        LinearLayout p = panel.open("Удалить пак?");
        panel.note(p, "«" + pack + "» исчезнет с телефона. Каналы, которые играют его звуки, замолчат (проекты останутся).");
        TextView del = ui.button("Удалить", true, v -> {
            Library.deletePack(this, pack);
            s.forgetFailures();
            s.rebuild();
            browser.reloadLibrary();
            panel.close();
            toast("Пак удалён");
        });
        p.addView(del, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(14), 0, 0));
    }

    @Override
    public void requestMic(Runnable granted) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            granted.run();
            return;
        }
        pendingMic = granted;
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        if (req == REQ_MIC) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED && pendingMic != null) pendingMic.run();
            else toast("Без доступа к микрофону запись невозможна");
            pendingMic = null;
        }
    }

    // ================================================================== результаты выбора файлов

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) {
            pendingSave = null;
            return;
        }
        if (req == REQ_SAVE) {
            File f = pendingSave;
            pendingSave = null;
            if (f == null || data.getData() == null) return;
            try {
                Exporter.copyTo(this, f, data.getData());
                toast("Сохранено");
            } catch (IOException e) {
                toast("Не сохранилось: " + e.getMessage());
            }
            return;
        }
        ArrayList<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int i = 0; i < data.getClipData().getItemCount(); i++) uris.add(data.getClipData().getItemAt(i).getUri());
        } else if (data.getData() != null) {
            uris.add(data.getData());
        }
        if (uris.isEmpty()) return;
        runImport(req, uris);
    }

    private void runImport(int req, List<Uri> uris) {
        LinearLayout p = panel.open("Импорт");
        TextView status = panel.note(p, "Чтение…");
        new Thread(() -> {
            String msg;
            String pack = null;
            try {
                Library.Progress prog = (file, n) -> runOnUiThread(() -> status.setText("Файлов: " + n + "\n" + file));
                Library.Report rep;
                if (req == REQ_ZIP) rep = Library.importZip(this, uris.get(0), prog);
                else if (req == REQ_TREE) rep = Library.importTree(this, uris.get(0), prog);
                else rep = Library.importFiles(this, uris, prog);
                pack = rep.pack;
                msg = "Готово: " + rep.files + " " + plural(rep.files, "звук", "звука", "звуков") + " в паке «" + rep.pack + "»"
                        + (rep.skipped > 0 ? "\nПропущено других файлов: " + rep.skipped : "");
            } catch (IOException e) {
                msg = "Не получилось: " + e.getMessage();
            } catch (Exception | OutOfMemoryError e) {
                msg = "Не получилось: " + e.getClass().getSimpleName();
            }
            String m = msg, pk = pack;
            runOnUiThread(() -> {
                status.setText(m);
                if (pk != null) {
                    TextView open = ui.button("Открыть пак", true, v -> {
                        panel.close();
                        showTab(TAB_SOUNDS);
                        browser.showLibrary();
                    });
                    p.addView(open, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(14), 0, 0));
                    browser.reloadLibrary();
                }
            });
        }, "neon-import").start();
    }

    static String plural(int n, String one, String few, String many) {
        int m10 = n % 10, m100 = n % 100;
        if (m10 == 1 && m100 != 11) return one;
        if (m10 >= 2 && m10 <= 4 && (m100 < 12 || m100 > 14)) return few;
        return many;
    }
}
