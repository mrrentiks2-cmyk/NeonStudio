package com.neondrift.studio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.SystemClock;
import android.util.SparseArray;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;

/**
 * Живая игра: 16 пэдов по каналам, клавиатура или «лад» (только ноты тональности —
 * мимо не сыграть). Мультитач, сила удара — по высоте касания внутри пэда.
 * Когда идёт запись, ноты попадают в паттерн.
 */
final class PadsView extends View {
    static final int PADS = 0, KEYS = 1, SCALE = 2;
    int mode = PADS;
    int octave = 4;              // для клавиш и лада

    private final Studio s;
    private final Ui ui;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final long[] flash = new long[128];          // пэд/клавиша → время удара
    private final SparseArray<int[]> pointers = new SparseArray<>(); // id пальца → {канал(индекс), нота}

    PadsView(Context c, Studio s, Ui ui) {
        super(c);
        this.s = s;
        this.ui = ui;
        text.setTextAlign(Paint.Align.CENTER);
        setHapticFeedbackEnabled(true);
    }

    // ================================================================== разметка

    private int cols() {
        if (mode == SCALE) return getWidth() > getHeight() ? 8 : 4;
        return 4;
    }

    private int rows() {
        if (mode == SCALE) return getWidth() > getHeight() ? 3 : 6;
        return 4;
    }

    private void cell(int i, RectF out) {
        int cols = cols(), rows = rows();
        float pad = ui.dp(6);
        float size = Math.min((getWidth() - pad) / cols, (getHeight() - pad) / rows);
        float w = mode == PADS ? size : (getWidth() - pad) / cols, h = mode == PADS ? size : (getHeight() - pad) / rows;
        float ox = (getWidth() - w * cols) / 2, oy = (getHeight() - h * rows) / 2;
        int row = rows - 1 - i / cols, col = i % cols; // снизу вверх, как на пэд-контроллерах
        out.set(ox + col * w + pad / 2, oy + row * h + pad / 2, ox + (col + 1) * w - pad / 2, oy + (row + 1) * h - pad / 2);
    }

    /** Нота пэда в режиме «лад». */
    private int scaleKey(int i) {
        return Theory.degree(s.p.key, s.p.scale, i, octave);
    }

    // ================================================================== рисование

    @Override
    protected void onDraw(Canvas c) {
        long now = SystemClock.uptimeMillis();
        boolean anim = false;
        if (mode == KEYS) {
            anim = drawKeys(c, now);
        } else {
            List<Project.Channel> chs = s.p.channels;
            Project.Channel sel = s.selected();
            int n = cols() * rows();
            for (int i = 0; i < n; i++) {
                cell(i, r);
                int color;
                String label, sub = null;
                int key;
                if (mode == PADS) {
                    if (i >= chs.size()) {
                        fill.setColor(0xFF120F1C);
                        c.drawRoundRect(r, ui.dp(14), ui.dp(14), fill);
                        continue;
                    }
                    Project.Channel ch = chs.get(i);
                    color = ch.color;
                    label = ch.name;
                    sub = ch.mute ? "выкл" : null;
                    key = i;
                } else {
                    if (sel == null) return;
                    color = sel.color;
                    key = scaleKey(i);
                    label = Theory.name(key);
                    if (Math.floorMod(key - s.p.key, 12) == 0) sub = "тоника";
                }
                float t = Math.max(0, 1 - (now - flash[key & 127]) / 260f);
                if (t > 0) anim = true;
                boolean root = mode == SCALE && sub != null;
                int base = Theme.mix(0xFF1B1629, color, root ? 0.32f : 0.16f);
                fill.setColor(Theme.mix(base, color, t * 0.85f));
                c.drawRoundRect(r, ui.dp(14), ui.dp(14), fill);
                fill.setStyle(Paint.Style.STROKE);
                fill.setStrokeWidth(ui.dp(1.5f));
                fill.setColor(Theme.mix(Theme.alpha(color, 120), 0xFFFFFFFF, t * 0.6f));
                c.drawRoundRect(r, ui.dp(14), ui.dp(14), fill);
                fill.setStyle(Paint.Style.FILL);
                text.setTypeface(Typeface.DEFAULT_BOLD);
                text.setTextSize(Math.min(ui.dp(14), r.height() / 4));
                text.setColor(Theme.TEXT);
                c.drawText(fit(label, r.width() - ui.dp(10)), r.centerX(), r.centerY() + ui.dp(5), text);
                if (sub != null) {
                    text.setTypeface(Typeface.DEFAULT);
                    text.setTextSize(ui.dp(10));
                    text.setColor(Theme.MUTED);
                    c.drawText(sub, r.centerX(), r.centerY() + ui.dp(20), text);
                }
            }
        }
        if (anim) postInvalidateOnAnimation();
    }

    private String fit(String s, float max) {
        if (text.measureText(s) <= max) return s;
        int n = text.breakText(s, true, max - text.measureText("…"), null);
        return s.substring(0, Math.max(0, n)) + "…";
    }

    private int whiteCount() {
        return getWidth() > getHeight() ? 21 : 14;
    }

    /** Клавиша под точкой: сначала чёрные (они сверху). */
    private int keyAt(float x, float y) {
        int whites = whiteCount();
        float ww = getWidth() / (float) whites;
        int base = 12 * (octave + 1);
        if (y < getHeight() * 0.6f) {
            for (int w = 0; w < whites; w++) {
                int wk = whiteKey(base, w);
                if (Theory.black(wk + 1) && Math.abs(x - (w + 1) * ww) < ww * 0.32f) return wk + 1;
            }
        }
        int w = Math.max(0, Math.min(whites - 1, (int) (x / ww)));
        return whiteKey(base, w);
    }

    private static int whiteKey(int base, int w) {
        int[] W = {0, 2, 4, 5, 7, 9, 11};
        return base + 12 * (w / 7) + W[w % 7];
    }

    private boolean drawKeys(Canvas c, long now) {
        Project.Channel sel = s.selected();
        int color = sel == null ? Theme.ACCENT : sel.color;
        int whites = whiteCount();
        float ww = getWidth() / (float) whites, H = getHeight();
        int base = 12 * (octave + 1);
        boolean anim = false;
        text.setTextSize(ui.dp(10));
        for (int w = 0; w < whites; w++) {
            int k = whiteKey(base, w);
            float t = Math.max(0, 1 - (now - flash[k & 127]) / 260f);
            if (t > 0) anim = true;
            boolean inScale = s.p.scale != 8 && Theory.inScale(k, s.p.key, s.p.scale);
            r.set(w * ww + ui.dp(1), 0, (w + 1) * ww - ui.dp(1), H - ui.dp(2));
            int col = inScale ? Theme.mix(0xFFE9E4F7, color, 0.18f) : 0xFFE9E4F7;
            fill.setColor(Theme.mix(col, color, t));
            c.drawRoundRect(r, ui.dp(6), ui.dp(6), fill);
            if (Math.floorMod(k, 12) == 0) {
                text.setColor(0xFF6A6280);
                c.drawText(Theory.name(k), r.centerX(), H - ui.dp(12), text);
            }
        }
        for (int w = 0; w < whites; w++) {
            int k = whiteKey(base, w) + 1;
            if (!Theory.black(k) || w == whites - 1) continue;
            float t = Math.max(0, 1 - (now - flash[k & 127]) / 260f);
            if (t > 0) anim = true;
            boolean inScale = s.p.scale != 8 && Theory.inScale(k, s.p.key, s.p.scale);
            float cx = (w + 1) * ww;
            r.set(cx - ww * 0.32f, 0, cx + ww * 0.32f, H * 0.6f);
            int col = inScale ? Theme.mix(0xFF1C1828, color, 0.35f) : 0xFF1C1828;
            fill.setColor(Theme.mix(col, color, t));
            c.drawRoundRect(r, ui.dp(5), ui.dp(5), fill);
        }
        return anim;
    }

    // ================================================================== касания

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        switch (act) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                getParent().requestDisallowInterceptTouchEvent(true);
                int i = e.getActionIndex();
                press(e.getPointerId(i), e.getX(i), e.getY(i));
                return true;
            }
            case MotionEvent.ACTION_MOVE:
                if (mode == KEYS) {
                    // скольжение по клавишам — новая нота
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        int id = e.getPointerId(i);
                        int[] cur = pointers.get(id);
                        if (cur == null) continue;
                        int k = keyAt(e.getX(i), e.getY(i));
                        if (k != cur[1]) {
                            release(id);
                            press(id, e.getX(i), e.getY(i));
                        }
                    }
                }
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                release(e.getPointerId(e.getActionIndex()));
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                for (int i = pointers.size() - 1; i >= 0; i--) release(pointers.keyAt(i));
                return true;
            default:
                return true;
        }
    }

    private void press(int id, float x, float y) {
        List<Project.Channel> chs = s.p.channels;
        Project.Channel ch;
        int key, chIdx, flashIdx;
        float vel = 0.85f;
        if (mode == KEYS) {
            ch = s.selected();
            key = keyAt(x, y);
            chIdx = ch == null ? -1 : chs.indexOf(ch);
            flashIdx = key;
            if (s.prefs.velocityPads()) vel = 0.45f + 0.55f * Math.min(1f, y / (getHeight() * 0.85f));
        } else {
            int n = cols() * rows(), hit = -1;
            for (int i = 0; i < n; i++) {
                cell(i, r);
                if (r.contains(x, y)) {
                    hit = i;
                    break;
                }
            }
            if (hit < 0) return;
            if (s.prefs.velocityPads()) vel = 0.35f + 0.65f * Math.max(0f, Math.min(1f, 1 - (y - r.top) / r.height() * 0.9f));
            if (mode == PADS) {
                if (hit >= chs.size()) return;
                ch = chs.get(hit);
                key = s.defaultKey(ch);
                chIdx = hit;
                flashIdx = hit;
            } else {
                ch = s.selected();
                key = scaleKey(hit);
                chIdx = ch == null ? -1 : chs.indexOf(ch);
                flashIdx = key;
            }
        }
        if (ch == null || chIdx < 0 || key < 0 || key > 127) return;
        pointers.put(id, new int[]{chIdx, key});
        flash[flashIdx & 127] = SystemClock.uptimeMillis();
        s.live(ch, key, vel);
        if (s.prefs.vibrate()) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        invalidate();
    }

    private void release(int id) {
        int[] cur = pointers.get(id);
        pointers.remove(id);
        if (cur == null) return;
        List<Project.Channel> chs = s.p.channels;
        if (cur[0] >= 0 && cur[0] < chs.size()) s.live(chs.get(cur[0]), cur[1], 0f);
    }

    void releaseAll() {
        for (int i = pointers.size() - 1; i >= 0; i--) release(pointers.keyAt(i));
    }
}
