package com.neondrift.studio;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;

/** Вставка MIDI в паттерн: мелодией в один канал или барабанами по каналам (раскладка General MIDI). */
final class MidiImport {
    private MidiImport() {}

    /** Похоже на барабанную партию? */
    static boolean looksLikeDrums(Midi.Result r, String name) {
        if (r.notes.isEmpty()) return false;
        String n = name == null ? "" : name.toLowerCase(Locale.ROOT);
        if (n.contains("drum") || n.contains("бараб") || n.contains("perc") || n.contains("hihat") || n.contains("kick")) return true;
        HashSet<Integer> keys = new HashSet<>();
        for (Project.Note x : r.notes) {
            if (x.key < 35 || x.key > 81) return false;
            keys.add(x.key);
        }
        int core = 0;
        for (int k : new int[]{35, 36, 38, 40, 42, 44, 46}) if (keys.contains(k)) core++;
        return core >= 2;
    }

    private static Project.Channel drumChannel(Project p, int key) {
        switch (key) {
            case 35:
            case 36:
                return Presets.ensure(p, "kick");
            case 38:
            case 40:
                return Presets.ensure(p, "snare");
            case 39:
                return Presets.ensure(p, "clap");
            case 42:
            case 44:
                return Presets.ensure(p, "hat");
            case 46:
                return Presets.ensure(p, "ohat");
            case 56:
                return Presets.ensure(p, "cowbell");
            case 49:
            case 52:
            case 55:
            case 57:
                return extra(p, "crash", "Крэш", "crash", 0xFFFFD447);
            case 51:
            case 53:
            case 59:
                return extra(p, "ride", "Райд", "ride", 0xFF8FD8FF);
            case 54:
                return extra(p, "tamb", "Бубен", "tambourine", 0xFFFF8A3D);
            case 69:
            case 70:
            case 82:
                return extra(p, "shaker", "Шейкер", "shaker", 0xFF8CFF5A);
            case 60:
            case 61:
                return extra(p, "bongo", "Бонго", "bongo", 0xFF3DFFB0);
            case 62:
            case 63:
            case 64:
                return extra(p, "conga", "Конга", "conga", 0xFF33E1FF);
            case 41:
            case 43:
            case 45:
                return extra(p, "tom_low", "Том низкий", "tom_low", 0xFFFF4F9A);
            case 47:
            case 48:
            case 50:
                return extra(p, "tom_high", "Том высокий", "tom_high", 0xFFFF4F9A);
            default:
                return Presets.ensure(p, "perc");
        }
    }

    private static Project.Channel extra(Project p, String role, String name, String sound, int color) {
        for (Project.Channel c : p.channels) if (role.equals(c.role)) return c;
        Project.Channel c = new Project.Channel();
        c.role = role;
        Presets.sampler(c, name, sound, color);
        c.vol = 0.65f;
        p.channels.add(c);
        return c;
    }

    /** Барабаны: каждая нота — в свой канал по раскладке GM. Возвращает число нот. */
    static int drums(Project p, Project.Pattern pt, List<Project.Note> notes, Studio s) {
        fit(pt, notes);
        HashSet<String> cleared = new HashSet<>();
        int n = 0;
        for (Project.Note src : notes) {
            if (src.start >= pt.ticks()) continue;
            Project.Channel ch = drumChannel(p, src.key);
            if (cleared.add(ch.id)) pt.notes(ch.id).clear();
            Project.Note x = new Project.Note(src.start, Math.max(1, src.len), s.defaultKey(ch), src.vel);
            pt.notes(ch.id).add(x);
            n++;
        }
        return n;
    }

    /** Мелодия: все ноты в один канал (его ноты в паттерне заменяются). */
    static int melody(Project.Pattern pt, Project.Channel ch, List<Project.Note> notes) {
        fit(pt, notes);
        List<Project.Note> dst = pt.notes(ch.id);
        dst.clear();
        int n = 0;
        for (Project.Note src : notes) {
            if (src.start >= pt.ticks()) continue;
            dst.add(src.copy());
            n++;
        }
        return n;
    }

    /** Удлинить паттерн под MIDI (до 32 тактов). */
    private static void fit(Project.Pattern pt, List<Project.Note> notes) {
        int end = 0;
        for (Project.Note x : notes) end = Math.max(end, x.end());
        int steps = (int) Math.ceil(end / (double) Project.STEP);
        steps = ((steps + 15) / 16) * 16;
        if (steps > pt.steps) pt.steps = Math.min(512, steps);
    }
}
