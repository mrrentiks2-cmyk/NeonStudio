package com.neondrift.studio;

/** Готовые настройки инструментов и каналы по ролям (бочка, 808, ковбелл…). */
final class Presets {
    private Presets() {}

    // ================================================================== синтезатор

    static final String[] SYNTH = {"Phonk Lead", "Тёмный пэд", "Memphis Bell (FM)", "Funk Slap Bass", "Электропиано",
            "Медь", "Вау-плак", "Саб-бас", "Acid", "Плак", "Стеклянный колокол"};

    static void synth(Project.Channel c, int i) {
        Project.Channel d = new Project.Channel(); // сброс к умолчаниям
        c.type = Project.SYNTH;
        c.osc1 = d.osc1; c.osc2 = d.osc2; c.osc2Semi = 0; c.detune = 8; c.mix = 0.5f; c.sub = 0; c.noise = 0;
        c.fm = 0; c.fmRatio = 2; c.fmDecay = 0.6f; c.ftype = Dsp.LP; c.cutoff = 3500; c.res = 0.15f; c.envAmt = 0;
        c.fAttack = 0.002f; c.fDecay = 0.3f; c.fSustain = 0; c.fRelease = 0.2f; c.glide = 0; c.mono = false; c.vdrive = 0;
        c.attack = 0.003f; c.decay = 0.3f; c.sustain = 0.7f; c.release = 0.15f;
        switch (i) {
            case 0: // Phonk Lead — две расстроенные пилы
                c.detune = 14; c.cutoff = 2400; c.res = 0.25f; c.envAmt = 1.5f; c.fDecay = 0.25f; c.sustain = 0.65f; c.vdrive = 0.25f;
                break;
            case 1: // тёмный пэд
                c.detune = 18; c.sub = 0.3f; c.cutoff = 900; c.res = 0.1f; c.envAmt = 1f; c.fAttack = 0.8f; c.fDecay = 1.5f; c.fSustain = 0.4f;
                c.attack = 0.5f; c.decay = 1f; c.sustain = 0.85f; c.release = 1.2f;
                break;
            case 2: // колокол FM
                c.osc2 = Dsp.SINE; c.fm = 0.9f; c.fmRatio = 3.5f; c.fmDecay = 0.5f; c.mix = 0f; c.cutoff = 9000; c.res = 0.05f;
                c.attack = 0.002f; c.decay = 1.4f; c.sustain = 0f; c.release = 0.8f;
                break;
            case 3: // слэп-бас
                c.osc1 = Dsp.SAW; c.osc2 = Dsp.SQUARE; c.osc2Semi = -12; c.detune = 0; c.mix = 0.4f; c.cutoff = 380; c.res = 0.4f;
                c.envAmt = 3.2f; c.fDecay = 0.15f; c.attack = 0.001f; c.decay = 0.28f; c.sustain = 0.35f; c.release = 0.08f;
                c.vdrive = 0.35f; c.mono = true; c.glide = 0.04f;
                break;
            case 4: // электропиано
                c.osc2 = Dsp.SINE; c.fm = 0.45f; c.fmRatio = 1f; c.fmDecay = 0.9f; c.mix = 0f; c.cutoff = 6000; c.res = 0.05f;
                c.attack = 0.002f; c.decay = 1.6f; c.sustain = 0.25f; c.release = 0.4f;
                break;
            case 5: // медь
                c.detune = 10; c.cutoff = 700; c.res = 0.15f; c.envAmt = 2.4f; c.fAttack = 0.06f; c.fDecay = 0.35f; c.fSustain = 0.4f;
                c.attack = 0.02f; c.decay = 0.4f; c.sustain = 0.75f; c.release = 0.15f; c.vdrive = 0.15f;
                break;
            case 6: // вау-плак
                c.osc1 = Dsp.SQUARE; c.osc2 = Dsp.SAW; c.mix = 0.3f; c.ftype = Dsp.BP; c.cutoff = 350; c.res = 0.55f; c.envAmt = 3f;
                c.fAttack = 0.03f; c.fDecay = 0.25f; c.attack = 0.002f; c.decay = 0.35f; c.sustain = 0.3f; c.release = 0.1f;
                break;
            case 7: // саб-бас
                c.osc1 = Dsp.SINE; c.osc2 = Dsp.SINE; c.mix = 0f; c.detune = 0; c.cutoff = 600; c.res = 0f;
                c.attack = 0.004f; c.decay = 0.2f; c.sustain = 1f; c.release = 0.08f; c.mono = true; c.glide = 0.06f;
                break;
            case 8: // acid
                c.osc2 = Dsp.SAW; c.detune = 0; c.mix = 0f; c.cutoff = 300; c.res = 0.82f; c.envAmt = 3.6f; c.fDecay = 0.2f;
                c.attack = 0.001f; c.decay = 0.3f; c.sustain = 0.5f; c.release = 0.06f; c.mono = true; c.glide = 0.06f; c.vdrive = 0.3f;
                break;
            case 9: // плак
                c.detune = 6; c.cutoff = 500; c.res = 0.2f; c.envAmt = 3.5f; c.fDecay = 0.18f;
                c.attack = 0.001f; c.decay = 0.35f; c.sustain = 0f; c.release = 0.2f;
                break;
            case 10: // стеклянный колокол
                c.osc2 = Dsp.SINE; c.fm = 0.6f; c.fmRatio = 7f; c.fmDecay = 0.3f; c.mix = 0f; c.cutoff = 12000;
                c.attack = 0.001f; c.decay = 1.1f; c.sustain = 0f; c.release = 0.9f;
                break;
            default:
                break;
        }
    }

    // ================================================================== 808

    static final String[] BASS = {"808 Phonk", "808 чистый", "808 злой", "808 длинный", "808 Brazil"};

    static void bass(Project.Channel c, int i) {
        c.type = Project.BASS;
        c.glide = 0.07f;
        switch (i) {
            case 1: c.punch = 10; c.punchTime = 0.03f; c.drive808 = 0.08f; c.decay808 = 1.1f; c.click = 0.15f; break;
            case 2: c.punch = 14; c.punchTime = 0.04f; c.drive808 = 0.85f; c.decay808 = 1.3f; c.click = 0.3f; c.fxDrive = 0.25f; c.driveType = 2; break;
            case 3: c.punch = 9; c.punchTime = 0.03f; c.drive808 = 0.3f; c.decay808 = 3.2f; c.click = 0.2f; break;
            case 4: c.punch = 16; c.punchTime = 0.05f; c.drive808 = 0.6f; c.decay808 = 0.9f; c.click = 0.4f; break;
            default: c.punch = 12; c.punchTime = 0.035f; c.drive808 = 0.45f; c.decay808 = 1.5f; c.click = 0.25f;
        }
    }

    // ================================================================== каналы по ролям

    static final String[] ROLES = {"kick", "snare", "clap", "hat", "ohat", "perc", "cowbell", "808", "lead", "chords", "bell", "bass", "keys", "vinyl", "fx"};

    static Project.Channel make(String role) {
        Project.Channel c = new Project.Channel();
        c.role = role;
        switch (role) {
            case "kick": sampler(c, "Бочка", "kick_memphis", 0xFFFF2D95); c.sideSource = true; c.vol = 0.85f; break;
            case "snare": sampler(c, "Малый", "snare_memphis", 0xFFFF8A3D); c.sendRev = 0.12f; break;
            case "clap": sampler(c, "Клэп", "clap_phonk", 0xFFFFD447); c.sendRev = 0.15f; c.vol = 0.75f; break;
            case "hat": sampler(c, "Хэт", "hat_closed", 0xFF8CFF5A); c.choke = 1; c.vol = 0.62f; c.pan = 0.08f; break;
            case "ohat": sampler(c, "Хэт откр.", "hat_open", 0xFF3DFFB0); c.choke = 1; c.vol = 0.55f; c.pan = -0.08f; break;
            case "perc": sampler(c, "Перкуссия", "rim", 0xFF33E1FF); c.vol = 0.6f; c.sendRev = 0.1f; break;
            case "cowbell":
                sampler(c, "Ковбелл", "cowbell_808", 0xFF00E5FF);
                c.root = 72; c.vol = 0.66f; c.sendRev = 0.16f; c.sendDelay = 0.1f; c.mode = Project.ONESHOT;
                break;
            case "808":
                c.name = "808";
                c.color = 0xFFB57BFF;
                bass(c, 0);
                c.vol = 0.82f;
                c.duck = 0.25f;
                break;
            case "lead": c.name = "Лид"; c.color = 0xFF5C8DFF; synth(c, 0); c.vol = 0.6f; c.sendRev = 0.2f; c.sendDelay = 0.15f; break;
            case "chords": c.name = "Аккорды"; c.color = 0xFF9D6BFF; synth(c, 1); c.vol = 0.55f; c.sendRev = 0.3f; c.duck = 0.35f; break;
            case "bell":
                sampler(c, "Колокол", "bell_memphis", 0xFF8FD8FF);
                c.root = 72; c.vol = 0.6f; c.sendRev = 0.3f; c.mode = Project.GATE; c.release = 0.6f;
                break;
            case "bass": c.name = "Бас"; c.color = 0xFFB57BFF; synth(c, 3); c.vol = 0.75f; break;
            case "keys": c.name = "Клавиши"; c.color = 0xFF9D6BFF; synth(c, 4); c.vol = 0.55f; c.sendRev = 0.22f; break;
            case "vinyl": sampler(c, "Винил", "vinyl", 0xFF9A91B8); c.mode = Project.LOOP; c.vol = 0.45f; break;
            case "fx": sampler(c, "Эффект", "riser", 0xFFFF4F9A); c.sendRev = 0.2f; break;
            default: sampler(c, "Канал", "kick_memphis", 0xFFFF2D95);
        }
        return c;
    }

    static void sampler(Project.Channel c, String name, String sound, int color) {
        c.type = Project.SAMPLER;
        c.name = name;
        c.sample = Kits.PREFIX + sound;
        c.color = color;
    }

    /** Найти канал по роли или создать. */
    static Project.Channel ensure(Project p, String role) {
        for (Project.Channel c : p.channels) if (role.equals(c.role)) return c;
        Project.Channel c = make(role);
        p.channels.add(c);
        return c;
    }
}
