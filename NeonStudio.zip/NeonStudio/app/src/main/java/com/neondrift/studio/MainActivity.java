package com.neondrift.studio;

import android.app.Activity;
import android.content.Intent;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Главный экран: новые биты из шаблонов, свои проекты, импорт. */
public class MainActivity extends Activity {
    private static final int REQ_PROJECT = 21, REQ_SOUNDS = 22;
    private Ui ui;
    private SidePanel panel;
    private LinearLayout list;
    private TextView toastView;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Theme.load(this);
        ui = new Ui(this);
        build();
        handle(getIntent());
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        handle(i);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    // ================================================================== разметка

    private void build() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Theme.BG);
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout col = ui.col();
        col.setPadding(ui.dp(18), ui.dp(18), ui.dp(18), ui.dp(30));
        sv.addView(col);
        root.addView(sv, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));

        LinearLayout head = ui.row();
        LinearLayout titles = ui.col();
        TextView title = ui.text("Neon Studio", 30, Theme.TEXT, true);
        title.post(() -> {
            title.getPaint().setShader(new LinearGradient(0, 0, title.getWidth(), 0, Theme.ACCENT, Theme.ACCENT2, Shader.TileMode.CLAMP));
            title.invalidate();
        });
        titles.addView(title);
        titles.addView(ui.text("фонк · фанк · биты на телефоне", 13, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        head.addView(titles, Ui.lp(0, Ui.WRAP, 1f));
        head.addView(ui.iconButton("settings", Theme.MUTED, 44, 10, v -> settings()));
        col.addView(head);

        col.addView(ui.label("НОВЫЙ БИТ"), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(24), 0, ui.dp(10)));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setClipToPadding(false);
        LinearLayout cards = ui.row();
        int[][] grads = {{0xFFFF2D95, 0xFF5C1AFF}, {0xFF6B4BFF, 0xFF0E0A1C}, {0xFF00C2A8, 0xFFFFD447}, {0xFFFF8A3D, 0xFFFF2D95}, {0xFF2B2442, 0xFF15111F}};
        for (int i = 0; i < Templates.NAMES.length; i++) {
            final int k = i;
            LinearLayout card = ui.col();
            card.setPadding(ui.dp(14), ui.dp(14), ui.dp(14), ui.dp(14));
            card.setGravity(Gravity.BOTTOM);
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, grads[i % grads.length]);
            g.setCornerRadius(ui.dp(18));
            card.setBackground(Ui.ripple(g, Ui.round(0xFFFFFFFF, ui.dp(18))));
            TextView n = ui.text(Templates.NAMES[i], 17, 0xFFFFFFFF, true);
            card.addView(n);
            TextView sub = ui.text(Templates.SUBS[i], 11.5f, 0xDDFFFFFF, false);
            sub.setMaxLines(3);
            sub.setLineSpacing(0, 1.15f);
            card.addView(sub, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(5), 0, 0));
            card.setOnClickListener(v -> create(k));
            LinearLayout.LayoutParams lp = Ui.lp(ui.dp(168), ui.dp(128));
            lp.rightMargin = ui.dp(10);
            cards.addView(card, lp);
        }
        hs.addView(cards);
        col.addView(hs);

        LinearLayout acts = ui.row();
        TextView imp = ui.button("Открыть бит / проект", false, v -> pick(REQ_PROJECT));
        imp.setTextSize(13);
        TextView snd = ui.button("Звуки в библиотеку", false, v -> pick(REQ_SOUNDS));
        snd.setTextSize(13);
        acts.addView(imp, Ui.lp(0, Ui.WRAP, 1f));
        View gap = new View(this);
        acts.addView(gap, Ui.lp(ui.dp(10), 1));
        acts.addView(snd, Ui.lp(0, Ui.WRAP, 1f));
        col.addView(acts, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(14), 0, 0));

        col.addView(ui.label("МОИ БИТЫ"), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(26), 0, ui.dp(6)));
        list = ui.col();
        col.addView(list);

        panel = new SidePanel(this, ui);
        root.addView(panel, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        toastView = ui.text("", 14, Theme.TEXT, false);
        toastView.setBackground(Ui.round(0xF0221B35, ui.dp(14)));
        toastView.setPadding(ui.dp(16), ui.dp(12), ui.dp(16), ui.dp(12));
        toastView.setVisibility(View.GONE);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        tl.bottomMargin = ui.dp(28);
        tl.leftMargin = tl.rightMargin = ui.dp(16);
        root.addView(toastView, tl);
        setContentView(root);
    }

    private int refreshGen;

    private void refresh() {
        int gen = ++refreshGen;
        new Thread(() -> {
            List<ProjectStore.Info> all = ProjectStore.list(this);
            runOnUiThread(() -> {
                if (gen == refreshGen && !isFinishing()) show(all);
            });
        }, "neon-list").start();
    }

    private void show(List<ProjectStore.Info> all) {
        list.removeAllViews();
        if (all.isEmpty()) {
            TextView e = ui.text("Пока пусто. Выберите стиль выше — получите готовый бит, который можно сразу крутить и переделывать.",
                    14, Theme.MUTED, false);
            e.setLineSpacing(0, 1.3f);
            e.setPadding(ui.dp(4), ui.dp(10), ui.dp(4), ui.dp(10));
            list.addView(e);
            return;
        }
        for (ProjectStore.Info i : all) list.addView(card(i));
    }

    private View card(ProjectStore.Info i) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(14), ui.dp(12), ui.dp(4), ui.dp(12));
        row.setBackground(Ui.ripple(Ui.round(Theme.SURFACE, ui.dp(16)), Ui.round(0xFFFFFFFF, ui.dp(16))));
        View bar = new View(this);
        bar.setBackground(Ui.round(Theme.ACCENT, ui.dp(2)));
        row.addView(bar, Ui.margins(ui.dp(4), ui.dp(34), 0, 0, ui.dp(12), 0));
        LinearLayout texts = ui.col();
        texts.addView(ui.oneLine(i.name, 16, Theme.TEXT, true));
        String info = Panels.fmtBpm(i.bpm) + " BPM · " + Theory.KEYS[Math.floorMod(i.key, 12)] + " "
                + Theory.SCALE_NAMES[Math.max(0, Math.min(Theory.SCALE_NAMES.length - 1, i.scale))].split(" ")[0].toLowerCase()
                + (i.bars > 0 ? " · " + i.bars + " " + StudioActivity.plural(i.bars, "такт", "такта", "тактов") : "")
                + " · " + DateUtils.getRelativeTimeSpanString(i.edited, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS);
        texts.addView(ui.oneLine(info, 12, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(4), 0, 0));
        row.addView(texts, Ui.lp(0, Ui.WRAP, 1f));
        row.addView(ui.iconButton("more", Theme.MUTED, 44, 11, v -> projectMenu(i)));
        row.setOnClickListener(v -> open(i.id));
        row.setOnLongClickListener(v -> {
            projectMenu(i);
            return true;
        });
        LinearLayout.LayoutParams lp = Ui.lp(Ui.MATCH, Ui.WRAP);
        lp.bottomMargin = ui.dp(8);
        row.setLayoutParams(lp);
        return row;
    }

    // ================================================================== действия

    private void create(int template) {
        Project p = Templates.make(template, new Random().nextLong());
        p.name = ProjectStore.uniqueName(this, p.name);
        try {
            ProjectStore.save(this, p);
            open(p.id);
        } catch (IOException e) {
            toast("Не удалось создать: " + e.getMessage());
        }
    }

    private void open(String id) {
        Intent i = new Intent(this, StudioActivity.class);
        i.putExtra("id", id);
        startActivity(i);
    }

    private void projectMenu(ProjectStore.Info i) {
        LinearLayout p = panel.open(i.name);
        panel.option(p, "Открыть", null, false, () -> {
            panel.close();
            open(i.id);
        });
        panel.option(p, "Переименовать", null, false, () -> rename(i));
        panel.option(p, "Дублировать", null, false, () -> {
            try {
                Project pr = ProjectStore.load(this, i.id).copy();
                pr.name = ProjectStore.uniqueName(this, i.name + " (копия)");
                pr.created = pr.edited = System.currentTimeMillis();
                ProjectStore.save(this, pr);
                refresh();
            } catch (IOException e) {
                toast("Не получилось: " + e.getMessage());
            }
            panel.close();
        });
        panel.option(p, "Поделиться битом", "ZIP с проектом и вашими звуками", false, () -> {
            panel.close();
            new Thread(() -> {
                try {
                    Project pr = ProjectStore.load(this, i.id);
                    java.io.File f = Exporter.bundle(this, pr);
                    runOnUiThread(() -> {
                        Intent s = new Intent(Intent.ACTION_SEND);
                        s.setType("application/zip");
                        s.putExtra(Intent.EXTRA_STREAM, Files.uri(this, f));
                        s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        startActivity(Intent.createChooser(s, f.getName()));
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> toast("Не получилось: " + e.getMessage()));
                }
            }, "neon-share").start();
        });
        panel.option(p, "Удалить", null, false, () -> {
            LinearLayout q = panel.open("Удалить «" + i.name + "»?");
            panel.note(q, "Проект исчезнет насовсем. Звуки в библиотеке останутся.");
            TextView del = ui.button("Удалить", true, v -> {
                ProjectStore.delete(this, i.id);
                panel.close();
                refresh();
            });
            q.addView(del, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(14), 0, 0));
        });
    }

    private void rename(ProjectStore.Info i) {
        LinearLayout p = panel.open("Название");
        android.widget.EditText e = new android.widget.EditText(this);
        e.setText(i.name);
        e.setTextColor(Theme.TEXT);
        e.setSingleLine(true);
        e.setBackground(Ui.stroke(Theme.SURFACE, Theme.LINE, ui.dp(1), ui.dp(12)));
        e.setPadding(ui.dp(14), ui.dp(11), ui.dp(14), ui.dp(11));
        p.addView(e, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(6), 0, 0));
        TextView ok = ui.button("Готово", true, v -> {
            String name = e.getText().toString().trim();
            if (!name.isEmpty()) {
                try {
                    Project pr = ProjectStore.load(this, i.id);
                    pr.name = name.length() > 40 ? name.substring(0, 40) : name;
                    ProjectStore.save(this, pr);
                } catch (IOException ex) {
                    toast("Не получилось: " + ex.getMessage());
                }
            }
            android.view.inputmethod.InputMethodManager im = getSystemService(android.view.inputmethod.InputMethodManager.class);
            if (im != null) im.hideSoftInputFromWindow(e.getWindowToken(), 0);
            panel.close();
            refresh();
        });
        p.addView(ok, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(12), 0, 0));
        e.requestFocus();
        e.selectAll();
    }

    private void settings() {
        LinearLayout p = panel.open("Цвет акцента");
        Prefs pr = new Prefs(this);
        for (int i = 0; i < Theme.ACCENT_NAMES.length; i++) {
            final int k = i;
            panel.option(p, Theme.ACCENT_NAMES[i], null, pr.accent() == i, () -> {
                pr.put("accent", k);
                panel.close();
                recreate();
            });
        }
        panel.section(p, "О ПРИЛОЖЕНИИ");
        panel.note(p, "Все встроенные звуки синтезируются прямо в приложении — никаких чужих сэмплов. "
                + "Свои звуки добавляйте ZIP-архивами, файлами или папкой. Проекты хранятся только на телефоне.");
    }

    private void pick(int req) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        if (req == REQ_SOUNDS) {
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream",
                    "audio/*", "audio/midi", "application/x-rar-compressed", "application/vnd.rar"});
            i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        } else {
            i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/json",
                    "application/octet-stream", "text/plain"});
        }
        try {
            startActivityForResult(i, req);
        } catch (Exception e) {
            toast("Нет приложения для выбора файлов");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (res != RESULT_OK || data == null) return;
        ArrayList<Uri> uris = new ArrayList<>();
        if (data.getClipData() != null) {
            for (int k = 0; k < data.getClipData().getItemCount(); k++) uris.add(data.getClipData().getItemAt(k).getUri());
        } else if (data.getData() != null) uris.add(data.getData());
        if (uris.isEmpty()) return;
        if (req == REQ_PROJECT) importProject(uris.get(0));
        else importSounds(uris);
    }

    // ================================================================== входящие файлы

    private void handle(Intent i) {
        if (i == null) return;
        String act = i.getAction();
        if ("com.neondrift.studio.NEW".equals(act)) {
            create(0);
            return;
        }
        if ("com.neondrift.studio.LAST".equals(act)) {
            String last = new Prefs(this).lastProject();
            if (!last.isEmpty()) open(last);
            return;
        }
        ArrayList<Uri> uris = new ArrayList<>();
        if (Intent.ACTION_VIEW.equals(act) && i.getData() != null) uris.add(i.getData());
        else if (Intent.ACTION_SEND.equals(act)) {
            Uri u = i.getParcelableExtra(Intent.EXTRA_STREAM);
            if (u != null) uris.add(u);
        } else if (Intent.ACTION_SEND_MULTIPLE.equals(act)) {
            ArrayList<Uri> l = i.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
            if (l != null) uris.addAll(l);
        }
        if (uris.isEmpty()) return;
        setIntent(new Intent(this, MainActivity.class)); // не повторять при повороте
        if (uris.size() == 1 && isBundle(uris.get(0))) importProject(uris.get(0));
        else importSounds(uris);
    }

    /** ZIP с project.json — это бит из Neon Studio. */
    private boolean isBundle(Uri u) {
        try (InputStream in = getContentResolver().openInputStream(u)) {
            if (in == null) return false;
            ZipInputStream z = new ZipInputStream(in);
            ZipEntry e;
            int n = 0;
            while ((e = z.getNextEntry()) != null && n++ < 4000) if (e.getName().equals("project.json")) return true;
        } catch (Exception ignored) {
        }
        return false;
    }

    private void importProject(Uri u) {
        LinearLayout p = panel.open("Открытие");
        TextView st = panel.note(p, "Чтение…");
        new Thread(() -> {
            try {
                Project pr = Exporter.importProject(this, u);
                pr.name = ProjectStore.uniqueName(this, pr.name);
                ProjectStore.save(this, pr);
                runOnUiThread(() -> {
                    panel.close();
                    open(pr.id);
                });
            } catch (IOException e) {
                runOnUiThread(() -> st.setText("Не получилось: " + e.getMessage()));
            }
        }, "neon-open").start();
    }

    private void importSounds(List<Uri> uris) {
        LinearLayout p = panel.open("Звуки в библиотеку");
        TextView st = panel.note(p, "Чтение…");
        new Thread(() -> {
            String msg;
            try {
                Library.Progress prog = (f, n) -> runOnUiThread(() -> st.setText("Файлов: " + n + "\n" + f));
                Library.Report r;
                if (uris.size() == 1 && Library.displayName(this, uris.get(0)).toLowerCase().matches(".*\\.(zip|rar|7z)$")) {
                    r = Library.importZip(this, uris.get(0), prog);
                } else {
                    r = Library.importFiles(this, uris, prog);
                }
                msg = "Готово: " + r.files + " " + StudioActivity.plural(r.files, "звук", "звука", "звуков") + " в паке «" + r.pack
                        + "». Откройте любой бит → вкладка «Звуки» → «Библиотека».";
            } catch (IOException e) {
                msg = "Не получилось: " + e.getMessage();
            } catch (Exception | OutOfMemoryError e) {
                msg = "Не получилось: " + e.getClass().getSimpleName();
            }
            String m = msg;
            runOnUiThread(() -> st.setText(m));
        }, "neon-import").start();
    }

    private void toast(String text) {
        toastView.setText(text);
        toastView.setVisibility(View.VISIBLE);
        toastView.removeCallbacks(hide);
        toastView.postDelayed(hide, 2800);
    }

    private final Runnable hide = () -> toastView.setVisibility(View.GONE);

    @Override
    public void onBackPressed() {
        if (panel.isOpen()) panel.close();
        else super.onBackPressed();
    }
}
