package com.neondrift.studio;

import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/** Расшифровка MP3, OGG, FLAC, M4A и прочего встроенными кодеками Android. */
final class Decoder {
    private Decoder() {}

    static Wav.Audio decode(String path, float maxSec) throws IOException {
        MediaExtractor ex = new MediaExtractor();
        MediaCodec codec = null;
        try {
            ex.setDataSource(path);
            int track = -1;
            MediaFormat fmt = null;
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    track = i;
                    fmt = f;
                    break;
                }
            }
            if (track < 0) throw new IOException("в файле нет звука");
            ex.selectTrack(track);
            int rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE), channels = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
            codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME));
            codec.configure(fmt, null, null, 0);
            codec.start();
            int limit = (int) (maxSec * rate);
            float[][] out = new float[Math.max(1, Math.min(2, channels))][rate * 4];
            int frames = 0;
            boolean inDone = false, outDone = false;
            boolean isFloat = false;
            MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
            long guard = 0;
            while (!outDone && frames < limit) {
                if (++guard > 2_000_000) break;
                if (!inDone) {
                    int ii = codec.dequeueInputBuffer(5000);
                    if (ii >= 0) {
                        ByteBuffer ib = codec.getInputBuffer(ii);
                        int n = ib == null ? -1 : ex.readSampleData(ib, 0);
                        if (n < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                            inDone = true;
                        } else {
                            codec.queueInputBuffer(ii, 0, n, ex.getSampleTime(), 0);
                            ex.advance();
                        }
                    }
                }
                int oi = codec.dequeueOutputBuffer(info, 5000);
                if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    if (of.containsKey("pcm-encoding")) isFloat = of.getInteger("pcm-encoding") == 4; // ENCODING_PCM_FLOAT
                    limit = (int) (maxSec * rate);
                } else if (oi >= 0) {
                    ByteBuffer ob = codec.getOutputBuffer(oi);
                    if (ob != null && info.size > 0) {
                        ob.position(info.offset);
                        ob.limit(info.offset + info.size);
                        ob.order(ByteOrder.LITTLE_ENDIAN);
                        int bps = isFloat ? 4 : 2, n = info.size / (bps * channels);
                        if (frames + n > out[0].length) {
                            int cap = Math.max(out[0].length * 2, frames + n);
                            for (int c = 0; c < out.length; c++) out[c] = java.util.Arrays.copyOf(out[c], cap);
                        }
                        for (int i = 0; i < n; i++) {
                            for (int c = 0; c < channels; c++) {
                                float v = isFloat ? ob.getFloat() : ob.getShort() / 32768f;
                                if (c < out.length) out[c][frames] = v;
                            }
                            frames++;
                        }
                    }
                    codec.releaseOutputBuffer(oi, false);
                    if ((info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true;
                }
            }
            if (frames == 0) throw new IOException("не удалось расшифровать");
            for (int c = 0; c < out.length; c++) out[c] = java.util.Arrays.copyOf(out[c], Math.min(frames, limit));
            if (channels == 1 && out.length > 1) out = new float[][]{out[0]};
            return new Wav.Audio(out, rate);
        } catch (IllegalStateException | IllegalArgumentException e) {
            throw new IOException("формат не поддерживается: " + e.getMessage());
        } finally {
            if (codec != null) {
                try {
                    codec.stop();
                } catch (Exception ignored) {
                }
                codec.release();
            }
            ex.release();
        }
    }
}
