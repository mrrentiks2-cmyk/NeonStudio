package com.neondrift.studio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Пиано-ролл выбранного канала. Двумя пальцами — масштаб и прокрутка; одним — инструмент:
 * «Рисовать» (касание — нота, протяжка — длина, касание ноты — удалить, перетаскивание — сдвиг,
 * край ноты — длина), «Выбор» (рамка, сдвиг группы), «Стереть».
 */
final class PianoRollView extends View {
    interface Host {
        void onSelectionChanged();
    }

    static final int DRAW = 0, SELECT = 1, ERASE = 2;
    static final String[] STAMPS;
    static {
        STAMPS = new String[Theory.CHORD_NAMES.length + 2];
        System.arraycopy(Theory.CHORD_NAMES, 0, STAMPS, 0, Theory.CHORD_NAMES.length);
        STAMPS[STAMPS.length - 2] = "Трезвучие лада";
        STAMPS[STAMPS.length - 1] = "Септаккорд лада";
    }
    static final int[] SNAPS = {96, 48, 24, 12, 16, 8, 1};
    static final String[] SNAP_NAMES = {"1/4", "1/8", "1/16", "1/32", "1/16 триоль", "1/32 триоль", "Без сетки"};

    private final Studio s;
    private final Ui ui;
    private final Host host;
    int tool = DRAW;
    int snap = Project.STEP;
    int stamp;
    boolean slideNew, velLane, ghosts = true;
    final Set<Project.Note> selection = Collections.newSetFromMap(new IdentityHashMap<>());
    private static final List<Project.Note> clipboard = new ArrayList<>();
    private int lastLen = -1;
    private float lastVel = 0.8f;

    private float pxPerTick, keyH, scrollX, topKey;
    private boolean fitted;
    private final float kbW, rulerH, velH, slop;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(), text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();
    private int pressedKey = -1;

    PianoRollView(Context c, Studio s, Ui ui, Host host) {
        super(c);
        this.s = s;
        this.ui = ui;
        this.host = host;
        kbW = ui.dp(46);
        rulerH = ui.dp(24);
        velH = ui.dp(72);
        keyH = ui.dp(20);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        text.setTextSize(ui.dp(10));
        line.setStrokeWidth(1);
        snap = Math.max(1, s.prefs.snap());
    }

    Project.Channel channel() {
        return s.selected();
    }

    List<Project.Note> notes() {
        Project.Channel ch = channel();
        return ch == null ? new ArrayList<>() : s.p.current().notes(ch.id);
    }

    /** Подогнать масштаб: весь паттерн по ширине, ноты канала — по центру. */
    void fit() {
        fitted = false;
        invalidate();
    }

    private void doFit() {
        if (getWidth() == 0) return;
        fitted = true;
        int ticks = Math.max(Project.BAR * Project.STEP, s.p.current().ticks());
        pxPerTick = (getWidth() - kbW) / (float) Math.min(ticks, 4 * Project.BAR * Project.STEP);
        scrollX = 0;
        List<Project.Note> ns = notes();
        float center;
        if (!ns.isEmpty()) {
            int lo = 127, hi = 0;
            for (Project.Note n : ns) {
                lo = Math.min(lo, n.key);
                hi = Math.max(hi, n.key);
            }
            center = (lo + hi) / 2f + 0.5f;
        } else {
            Project.Channel ch = channel();
            center = (ch == null ? 60 : s.defaultKey(ch)) + 6;
        }
        topKey = center + gridH() / keyH / 2f;
        clamp();
    }

    private float gridH() {
        return getHeight() - rulerH - (velLane ? velH : 0);
    }

    private void clamp() {
        float minPx = (getWidth() - kbW) / (float) (64 * Project.BAR * Project.STEP);
        float maxPx = ui.dp(6) / 1f; // 6 dp на тик — очень крупно
        pxPerTick = Math.max(minPx, Math.min(maxPx, pxPerTick));
        keyH = Math.max(ui.dp(9), Math.min(ui.dp(56), keyH));
        int ticks = s.p.current().ticks();
        float visTicks = (getWidth() - kbW) / pxPerTick;
        scrollX = Math.max(0, Math.min(scrollX, Math.max(0, ticks + Project.BAR * Project.STEP - visTicks)));
        float visKeys = gridH() / keyH;
        topKey = Math.max(Math.min(128, visKeys), Math.min(128, topKey));
    }

    float x(double tick) {
        return (float) (kbW + (tick - scrollX) * pxPerTick);
    }

    double tick(float x) {
        return scrollX + (x - kbW) / pxPerTick;
    }

    float yTop(int key) {
        return rulerH + (topKey - key - 1) * keyH;
    }

    int key(float y) {
        return (int) Math.floor(topKey - (y - rulerH) / keyH);
    }

    int snapTick(double t) {
        if (snap <= 1) return (int) Math.round(t);
        return (int) (Math.round(t / snap) * snap);
    }

    int snapFloor(double t) {
        if (snap <= 1) return (int) Math.floor(t);
        return (int) (Math.floor(t / snap) * snap);
    }

    // ================================================================== рисование

    @Override
    protected void onDraw(Canvas c) {
        if (!fitted) doFit();
        if (getWidth() == 0) return;
        clamp();
        Project p = s.p;
        Project.Pattern pt = p.current();
        Project.Channel ch = channel();
        int W = getWidth();
        float gridBottom = rulerH + gridH();
        // ряды клавиш
        int kTop = (int) Math.ceil(topKey), kBot = key(gridBottom);
        for (int k = Math.min(127, kTop); k >= Math.max(0, kBot); k--) {
            float y0 = yTop(k);
            int col = Theory.black(k) ? 0xFF110E1A : 0xFF19142A;
            if (s.prefs.scaleHighlight() && p.scale != 8) {
                if (Math.floorMod(k - p.key, 12) == 0) col = Theme.mix(col, Theme.ACCENT, 0.13f);
                else if (Theory.inScale(k, p.key, p.scale)) col = Theme.mix(col, Theme.ACCENT, 0.055f);
            }
            fill.setColor(col);
            c.drawRect(kbW, Math.max(rulerH, y0), W, Math.min(gridBottom, y0 + keyH), fill);
            if (Math.floorMod(k, 12) == 0) {
                line.setColor(0xFF3A3254);
                c.drawLine(kbW, y0 + keyH, W, y0 + keyH, line);
            }
        }
        // вертикальная сетка
        double t0 = Math.max(0, tick(kbW)), t1 = tick(W);
        float stepPx = Project.STEP * pxPerTick;
        int every = stepPx >= ui.dp(7) ? Project.STEP : stepPx * 4 >= ui.dp(7) ? Project.PPQ : Project.BAR * Project.STEP;
        for (long t = (long) (Math.floor(t0 / every) * every); t <= t1; t += every) {
            float xx = x(t);
            if (xx < kbW) continue;
            boolean bar = t % (Project.BAR * Project.STEP) == 0, beat = t % Project.PPQ == 0;
            line.setColor(bar ? 0xFF4A4068 : beat ? 0xFF2E2742 : 0xFF221C33);
            c.drawLine(xx, rulerH, xx, gridBottom, line);
        }
        // за концом паттерна
        float endX = x(pt.ticks());
        if (endX < W) {
            fill.setColor(0x99000000);
            c.drawRect(Math.max(kbW, endX), rulerH, W, gridBottom, fill);
        }
        c.save();
        c.clipRect(kbW, rulerH, W, gridBottom);
        // призраки других каналов
        if (ghosts) {
            fill.setColor(0x33FFFFFF);
            for (Map.Entry<String, List<Project.Note>> e : pt.notes.entrySet()) {
                if (ch != null && e.getKey().equals(ch.id)) continue;
                Project.Channel och = p.channel(e.getKey());
                if (och == null || och.type == Project.SAMPLER && och.slices < 2 && (och.sliceMarks == null || och.sliceMarks.isEmpty())) continue;
                for (Project.Note n : e.getValue()) noteRect(n, r, c, fill, ui.dp(2));
            }
        }
        // ноты канала
        if (ch != null) {
            text.setTypeface(Typeface.DEFAULT_BOLD);
            for (Project.Note n : notes()) {
                float top = yTop(n.key);
                if (top > gridBottom || top + keyH < rulerH) continue;
                boolean sel = selection.contains(n);
                int col = Theme.mix(Theme.mix(ch.color, Theme.BG, 0.5f), ch.color, 0.3f + 0.7f * n.vel);
                fill.setColor(sel ? Theme.mix(col, 0xFFFFFFFF, 0.45f) : col);
                noteRect(n, r, c, fill, ui.dp(4));
                if (sel) {
                    fill.setStyle(Paint.Style.STROKE);
                    fill.setStrokeWidth(ui.dp(1.5f));
                    fill.setColor(0xFFFFFFFF);
                    c.drawRoundRect(r, ui.dp(4), ui.dp(4), fill);
                    fill.setStyle(Paint.Style.FILL);
                }
                // ручка длины
                if (r.width() > ui.dp(18)) {
                    fill.setColor(0x55000000);
                    c.drawRect(r.right - ui.dp(4), r.top + ui.dp(3), r.right - ui.dp(2), r.bottom - ui.dp(3), fill);
                }
                if (n.slide) {
                    path.reset();
                    path.moveTo(r.left + ui.dp(2), r.bottom - ui.dp(2));
                    path.lineTo(r.left + ui.dp(9), r.top + ui.dp(2));
                    fill.setStyle(Paint.Style.STROKE);
                    fill.setStrokeWidth(ui.dp(2));
                    fill.setColor(Theme.BG);
                    c.drawPath(path, fill);
                    fill.setStyle(Paint.Style.FILL);
                }
                if (r.width() > ui.dp(30) && keyH >= ui.dp(14)) {
                    text.setColor(Theme.BG);
                    text.setTextAlign(Paint.Align.LEFT);
                    c.drawText(Theory.name(n.key), r.left + ui.dp(n.slide ? 12 : 5), r.centerY() + ui.dp(3.5f), text);
                }
            }
        }
        // рамка выделения
        if (mode == BAND) {
            r.set(Math.min(downX, curX), Math.min(downY, curY), Math.max(downX, curX), Math.max(downY, curY));
            fill.setColor(Theme.alpha(Theme.ACCENT, 40));
            c.drawRect(r, fill);
            fill.setStyle(Paint.Style.STROKE);
            fill.setStrokeWidth(ui.dp(1));
            fill.setColor(Theme.ACCENT);
            c.drawRect(r, fill);
            fill.setStyle(Paint.Style.FILL);
        }
        // курсор
        if (s.playing() && !s.engine.songMode) {
            double pos = s.position() % Math.max(1, pt.ticks());
            float px = x(pos);
            fill.setColor(Theme.ACCENT2);
            c.drawRect(px - ui.dp(1), rulerH, px + ui.dp(1), gridBottom, fill);
        }
        c.restore();
        drawKeyboard(c, gridBottom);
        drawRuler(c, W, pt);
        if (velLane) drawVelocity(c, W, gridBottom);
    }

    private void noteRect(Project.Note n, RectF out, Canvas c, Paint p, float rad) {
        float top = yTop(n.key);
        out.set(x(n.start) + 1, top + 1, Math.max(x(n.start) + ui.dp(4), x(n.end()) - 1), top + keyH - 1);
        c.drawRoundRect(out, rad, rad, p);
    }

    private void drawKeyboard(Canvas c, float gridBottom) {
        // белые клавиши сплошной полосой, чёрные — поверх, как на настоящем пианино
        fill.setColor(0xFFE9E4F7);
        c.drawRect(0, rulerH, kbW - 1, gridBottom, fill);
        int kTop = (int) Math.ceil(topKey), kBot = key(gridBottom);
        c.save();
        c.clipRect(0, rulerH, kbW, gridBottom);
        text.setTypeface(Typeface.DEFAULT);
        line.setColor(0xFFB9B2CC);
        for (int k = Math.min(127, kTop); k >= Math.max(0, kBot); k--) {
            float y0 = yTop(k);
            int pc = Math.floorMod(k, 12);
            // граница между белыми: под C и под F (там нет чёрной клавиши)
            if (pc == 0 || pc == 5) c.drawLine(0, y0 + keyH, kbW, y0 + keyH, line);
            if (k == pressedKey && !Theory.black(k)) {
                fill.setColor(Theme.ACCENT);
                c.drawRect(0, y0, kbW - 1, y0 + keyH, fill);
            }
            if (pc == 0 && keyH >= ui.dp(11)) {
                text.setColor(0xFF6A6280);
                text.setTextAlign(Paint.Align.RIGHT);
                c.drawText(Theory.name(k), kbW - ui.dp(4), y0 + keyH - ui.dp(4), text);
            }
        }
        for (int k = Math.min(127, kTop); k >= Math.max(0, kBot); k--) {
            if (!Theory.black(k)) continue;
            float y0 = yTop(k);
            fill.setColor(k == pressedKey ? Theme.ACCENT : 0xFF1C1828);
            r.set(0, y0 + 1, kbW * 0.62f, y0 + keyH - 1);
            c.drawRoundRect(r, ui.dp(2), ui.dp(2), fill);
        }
        line.setColor(0xFF2B2442);
        c.drawLine(kbW - 1, rulerH, kbW - 1, gridBottom, line);
        c.restore();
    }

    private void drawRuler(Canvas c, int W, Project.Pattern pt) {
        fill.setColor(Theme.SURFACE);
        c.drawRect(0, 0, W, rulerH, fill);
        text.setColor(Theme.MUTED);
        text.setTextAlign(Paint.Align.LEFT);
        int bar = Project.BAR * Project.STEP;
        float barPx = bar * pxPerTick;
        int every = barPx < ui.dp(28) ? 4 : barPx < ui.dp(56) ? 2 : 1;
        for (int b = (int) Math.max(0, Math.floor(tick(kbW) / bar)); b * bar <= tick(W); b++) {
            float xx = x((double) b * bar);
            if (xx < kbW - 1) continue;
            line.setColor(0xFF4A4068);
            c.drawLine(xx, rulerH * 0.45f, xx, rulerH, line);
            if (b % every == 0) {
                text.setColor(b * bar < pt.ticks() ? Theme.TEXT : Theme.MUTED);
                c.drawText(String.valueOf(b + 1), xx + ui.dp(3), rulerH - ui.dp(8), text);
            }
        }
        fill.setColor(Theme.SURFACE);
        c.drawRect(0, 0, kbW, rulerH, fill);
        text.setColor(Theme.ACCENT);
        text.setTextAlign(Paint.Align.CENTER);
        c.drawText(SNAP_NAMES[snapIndex()].split(" ")[0], kbW / 2, rulerH - ui.dp(8), text);
        if (s.playing() && !s.engine.songMode) {
            float px = x(s.position() % Math.max(1, pt.ticks()));
            if (px >= kbW) {
                path.reset();
                path.moveTo(px - ui.dp(5), 0);
                path.lineTo(px + ui.dp(5), 0);
                path.lineTo(px, ui.dp(7));
                path.close();
                fill.setColor(Theme.ACCENT2);
                c.drawPath(path, fill);
            }
        }
    }

    int snapIndex() {
        for (int i = 0; i < SNAPS.length; i++) if (SNAPS[i] == snap) return i;
        return 2;
    }

    private void drawVelocity(Canvas c, int W, float top) {
        fill.setColor(0xFF0D0B14);
        c.drawRect(0, top, W, getHeight(), fill);
        line.setColor(Theme.LINE);
        c.drawLine(0, top, W, top, line);
        text.setColor(Theme.MUTED);
        text.setTextAlign(Paint.Align.CENTER);
        c.drawText("сила", kbW / 2, top + velH / 2 + ui.dp(3), text);
        Project.Channel ch = channel();
        if (ch == null) return;
        c.save();
        c.clipRect(kbW, top, W, getHeight());
        float h = velH - ui.dp(12);
        for (Project.Note n : notes()) {
            float xx = x(n.start);
            if (xx < kbW - ui.dp(6) || xx > W) continue;
            float y = top + ui.dp(6) + h * (1 - n.vel);
            boolean sel = selection.contains(n);
            fill.setColor(sel ? 0xFFFFFFFF : ch.color);
            c.drawRect(xx, y, xx + ui.dp(2), top + velH - ui.dp(4), fill);
            c.drawCircle(xx + ui.dp(1), y, ui.dp(4), fill);
        }
        c.restore();
    }

    // ================================================================== касания

    private static final int NONE = 0, PINCH = 1, KEYS = 2, PAN_KEYS = 3, RULER = 4, PAN_RULER = 5, DRAW_PENDING = 6,
            DRAW_LEN = 7, NOTE_PENDING = 8, MOVE = 9, RESIZE = 10, ERASE_DRAG = 11, BAND = 12, VEL = 13;
    private int mode;
    private float downX, downY, curX, curY, lastX, lastY;
    private boolean changed;
    private Project.Note grabbed;
    private final IdentityHashMap<Project.Note, int[]> orig = new IdentityHashMap<>();
    private final List<Project.Note> created = new ArrayList<>();
    private int lastPreviewKey = -1;
    // щипок
    private float pSpanX, pSpanY, pFocX, pFocY;

    private Project.Note hit(float x, float y) {
        if (y < rulerH || y > rulerH + gridH() || x < kbW) return null;
        int k = key(y);
        List<Project.Note> ns = notes();
        for (int i = ns.size() - 1; i >= 0; i--) {
            Project.Note n = ns.get(i);
            if (n.key != k) continue;
            float x0 = x(n.start), x1 = Math.max(x0 + ui.dp(4), x(n.end()));
            if (x >= x0 - ui.dp(2) && x <= x1 + ui.dp(4)) return n;
        }
        return null;
    }

    private boolean onEdge(Project.Note n, float x) {
        float x0 = x(n.start), x1 = x(n.end());
        float zone = Math.min(ui.dp(16), (x1 - x0) * 0.4f);
        return x >= x1 - zone;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        float x = e.getX(), y = e.getY();
        if (act == MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount() == 2) {
            if (mode == NONE || mode == DRAW_PENDING || mode == NOTE_PENDING || mode == KEYS || mode == RULER || mode == PAN_KEYS || mode == PAN_RULER) {
                if (mode == KEYS) keyOff();
                mode = PINCH;
                startPinch(e);
            }
            return true;
        }
        if (mode == PINCH) {
            if (act == MotionEvent.ACTION_MOVE && e.getPointerCount() >= 2) pinch(e);
            else if (act == MotionEvent.ACTION_POINTER_UP || act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                if (act != MotionEvent.ACTION_POINTER_UP) mode = NONE;
                else if (e.getPointerCount() <= 2) mode = NONE; // остаток жеста игнорируем
            }
            return true;
        }
        switch (act) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                downX = lastX = curX = x;
                downY = lastY = curY = y;
                changed = false;
                created.clear();
                orig.clear();
                grabbed = null;
                if (y < rulerH) {
                    mode = RULER;
                } else if (x < kbW && y < rulerH + gridH()) {
                    mode = KEYS;
                    keyOn(key(y));
                } else if (velLane && y > rulerH + gridH()) {
                    mode = VEL;
                    velocityAt(x, y);
                } else {
                    Project.Note n = hit(x, y);
                    if (tool == ERASE) {
                        mode = ERASE_DRAG;
                        eraseAt(x, y);
                    } else if (tool == SELECT) {
                        if (n == null) {
                            mode = BAND;
                        } else {
                            if (!selection.contains(n)) {
                                selection.clear();
                                selection.add(n);
                                host.onSelectionChanged();
                            }
                            grabbed = n;
                            mode = onEdge(n, x) ? RESIZE : NOTE_PENDING;
                            if (mode == RESIZE) beginEdit();
                        }
                    } else {
                        if (n == null) {
                            mode = DRAW_PENDING;
                        } else {
                            grabbed = n;
                            mode = onEdge(n, x) ? RESIZE : NOTE_PENDING;
                            if (mode == RESIZE) beginEdit();
                        }
                    }
                }
                invalidate();
                return true;
            case MotionEvent.ACTION_MOVE:
                curX = x;
                curY = y;
                boolean far = Math.abs(x - downX) > slop || Math.abs(y - downY) > slop;
                switch (mode) {
                    case RULER:
                        if (far) mode = PAN_RULER;
                        break;
                    case PAN_RULER:
                        scrollX -= (x - lastX) / pxPerTick;
                        clamp();
                        break;
                    case KEYS:
                        if (Math.abs(y - downY) > slop * 1.5f) {
                            keyOff();
                            mode = PAN_KEYS;
                        }
                        break;
                    case PAN_KEYS:
                        topKey += (y - lastY) / keyH;
                        clamp();
                        break;
                    case DRAW_PENDING:
                        if (far) {
                            beginEdit();
                            createAt(downX, downY, snap);
                            mode = DRAW_LEN;
                            stretch(x);
                        }
                        break;
                    case DRAW_LEN:
                        stretch(x);
                        break;
                    case NOTE_PENDING:
                        if (far) {
                            beginEdit();
                            mode = MOVE;
                            move(x, y);
                        }
                        break;
                    case MOVE:
                        move(x, y);
                        break;
                    case RESIZE:
                        resize(x);
                        break;
                    case ERASE_DRAG:
                        eraseAt(x, y);
                        break;
                    case VEL:
                        velocityAt(x, y);
                        break;
                    default:
                        break;
                }
                lastX = x;
                lastY = y;
                invalidate();
                return true;
            case MotionEvent.ACTION_UP:
                switch (mode) {
                    case RULER:
                        if (!s.engine.songMode) s.engine.seek(Math.max(0, snapFloor(tick(x))));
                        break;
                    case KEYS:
                        keyOff();
                        break;
                    case DRAW_PENDING:
                        beginEdit();
                        createAt(downX, downY, lastLen > 0 ? lastLen : s.defaultLen(channel()));
                        break;
                    case DRAW_LEN:
                        if (!created.isEmpty()) lastLen = created.get(0).len;
                        break;
                    case NOTE_PENDING:
                        if (tool == DRAW && grabbed != null) {
                            beginEdit();
                            notes().remove(grabbed);
                            selection.remove(grabbed);
                            haptic();
                        } else if (grabbed != null) {
                            audition(grabbed.key, grabbed.vel);
                        }
                        break;
                    case RESIZE:
                        if (grabbed != null) lastLen = grabbed.len;
                        break;
                    case MOVE:
                        if (grabbed != null) {
                            lastVel = grabbed.vel;
                            lastLen = grabbed.len;
                        }
                        break;
                    case BAND:
                        finishBand();
                        break;
                    default:
                        break;
                }
                endPreview();
                if (changed) s.edited();
                mode = NONE;
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                keyOff();
                endPreview();
                if (changed) s.edited();
                mode = NONE;
                invalidate();
                return true;
            default:
                return true;
        }
    }

    private void beginEdit() {
        if (!changed) s.checkpoint();
        changed = true;
        orig.clear();
        Iterable<Project.Note> set = (tool == SELECT && grabbed != null && selection.contains(grabbed)) ? selection
                : grabbed != null ? Collections.singletonList(grabbed) : Collections.emptyList();
        for (Project.Note n : set) orig.put(n, new int[]{n.start, n.key, n.len});
    }

    private void createAt(float x, float y, int len) {
        Project.Channel ch = channel();
        if (ch == null) return;
        int k = key(y);
        if (k < 0 || k > 127) return;
        int start = snapFloor(tick(x));
        if (start < 0 || start >= s.p.current().ticks()) return;
        int[] keys = stampKeys(k);
        created.clear();
        for (int kk : keys) {
            if (kk < 0 || kk > 127) continue;
            Project.Note n = new Project.Note(start, Math.max(1, len), kk, lastVel);
            n.slide = slideNew;
            notes().add(n);
            created.add(n);
        }
        if (!created.isEmpty()) {
            grabbed = created.get(0);
            for (Project.Note n : created) audition(n.key, n.vel);
            haptic();
        }
        s.rebuild();
    }

    int[] stampKeys(int k) {
        Project p = s.p;
        if (stamp <= 0) return new int[]{k};
        if (stamp == STAMPS.length - 2) return Theory.diatonic(k, p.key, p.scale, 3);
        if (stamp == STAMPS.length - 1) return Theory.diatonic(k, p.key, p.scale, 4);
        int[] iv = Theory.CHORDS[Math.min(stamp, Theory.CHORDS.length - 1)];
        int[] out = new int[iv.length];
        for (int i = 0; i < iv.length; i++) out[i] = k + iv[i];
        return out;
    }

    private void stretch(float x) {
        if (created.isEmpty()) return;
        int start = created.get(0).start;
        int end = snap <= 1 ? (int) Math.round(tick(x)) : (int) (Math.ceil(tick(x) / snap) * snap);
        int len = Math.max(Math.max(1, snap), end - start);
        for (Project.Note n : created) n.len = len;
    }

    private void move(float x, float y) {
        if (grabbed == null || orig.isEmpty()) return;
        int[] g = orig.get(grabbed);
        if (g == null) return;
        int dt = snapTick(g[0] + tick(x) - tick(downX)) - g[0];
        int dk = key(y) - key(downY);
        int plen = s.p.current().ticks();
        // не выходить за паттерн и за диапазон клавиш
        for (Map.Entry<Project.Note, int[]> e : orig.entrySet()) {
            int[] o = e.getValue();
            dt = Math.max(dt, -o[0]);
            dt = Math.min(dt, plen - 1 - o[0]);
            dk = Math.max(dk, -o[1]);
            dk = Math.min(dk, 127 - o[1]);
        }
        boolean keyChanged = false;
        for (Map.Entry<Project.Note, int[]> e : orig.entrySet()) {
            Project.Note n = e.getKey();
            int[] o = e.getValue();
            if (n.key != o[1] + dk) keyChanged = true;
            n.start = o[0] + dt;
            n.key = o[1] + dk;
        }
        if (keyChanged) preview(grabbed.key, grabbed.vel);
        s.rebuild();
    }

    private void resize(float x) {
        if (grabbed == null || orig.isEmpty()) return;
        int[] g = orig.get(grabbed);
        if (g == null) return;
        int end = snap <= 1 ? (int) Math.round(tick(x)) : (int) (Math.round(tick(x) / snap) * snap);
        int dl = Math.max(end, g[0] + Math.max(1, snap)) - (g[0] + g[2]);
        for (Map.Entry<Project.Note, int[]> e : orig.entrySet()) e.getKey().len = Math.max(Math.max(1, snap / 2), e.getValue()[2] + dl);
        s.rebuild();
    }

    private void eraseAt(float x, float y) {
        Project.Note n = hit(x, y);
        if (n == null) return;
        if (!changed) s.checkpoint();
        changed = true;
        notes().remove(n);
        selection.remove(n);
        haptic();
        s.rebuild();
    }

    private void velocityAt(float x, float y) {
        float top = rulerH + gridH() + ui.dp(6), h = velH - ui.dp(12);
        float v = Math.max(0.03f, Math.min(1f, 1 - (y - top) / h));
        boolean any = false;
        for (Project.Note n : notes()) {
            float xx = x(n.start);
            if (Math.abs(xx - x) > ui.dp(10)) continue;
            if (!selection.isEmpty() && !selection.contains(n)) continue;
            if (!changed) s.checkpoint();
            changed = true;
            n.vel = v;
            any = true;
        }
        if (any) lastVel = v;
    }

    private void finishBand() {
        float x0 = Math.min(downX, curX), x1 = Math.max(downX, curX), y0 = Math.min(downY, curY), y1 = Math.max(downY, curY);
        if (x1 - x0 < slop && y1 - y0 < slop) {
            selection.clear();
        } else {
            selection.clear();
            for (Project.Note n : notes()) {
                float nx0 = x(n.start), nx1 = x(n.end()), ny0 = yTop(n.key), ny1 = ny0 + keyH;
                if (nx1 >= x0 && nx0 <= x1 && ny1 >= y0 && ny0 <= y1) selection.add(n);
            }
        }
        host.onSelectionChanged();
    }

    private void startPinch(MotionEvent e) {
        pSpanX = Math.abs(e.getX(0) - e.getX(1));
        pSpanY = Math.abs(e.getY(0) - e.getY(1));
        pFocX = (e.getX(0) + e.getX(1)) / 2;
        pFocY = (e.getY(0) + e.getY(1)) / 2;
    }

    private void pinch(MotionEvent e) {
        float sx = Math.abs(e.getX(0) - e.getX(1)), sy = Math.abs(e.getY(0) - e.getY(1));
        float fx = (e.getX(0) + e.getX(1)) / 2, fy = (e.getY(0) + e.getY(1)) / 2;
        double tickAt = tick(pFocX);
        float keyAt = topKey - (pFocY - rulerH) / keyH;
        if (pSpanX > ui.dp(40) && sx > ui.dp(40)) pxPerTick *= sx / pSpanX;
        if (pSpanY > ui.dp(40) && sy > ui.dp(40)) keyH *= sy / pSpanY;
        clamp();
        // точка под пальцами остаётся на месте, плюс сдвиг
        scrollX = (float) (tickAt - (fx - kbW) / pxPerTick);
        topKey = keyAt + (fy - rulerH) / keyH;
        clamp();
        pSpanX = sx;
        pSpanY = sy;
        pFocX = fx;
        pFocY = fy;
        invalidate();
    }

    // ================================================================== звук

    private void keyOn(int k) {
        Project.Channel ch = channel();
        if (ch == null || k < 0 || k > 127) return;
        pressedKey = k;
        s.live(ch, k, 0.85f); // при записи нота попадёт в паттерн
    }

    private void keyOff() {
        Project.Channel ch = channel();
        if (pressedKey >= 0 && ch != null) s.live(ch, pressedKey, 0f);
        pressedKey = -1;
    }

    private void audition(int k, float vel) {
        Project.Channel ch = channel();
        if (ch == null || s.playing()) return;
        s.engine.live(ch, k, vel);
        postDelayed(() -> s.engine.live(ch, k, 0f), 220);
    }

    private void preview(int k, float vel) {
        Project.Channel ch = channel();
        if (ch == null || s.playing()) return;
        if (lastPreviewKey >= 0) s.engine.live(ch, lastPreviewKey, 0f);
        lastPreviewKey = k;
        s.engine.live(ch, k, vel);
    }

    private void endPreview() {
        Project.Channel ch = channel();
        if (lastPreviewKey >= 0 && ch != null) s.engine.live(ch, lastPreviewKey, 0f);
        lastPreviewKey = -1;
    }

    private void haptic() {
        if (s.prefs.vibrate()) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    // ================================================================== действия с выделением

    void selectAll() {
        selection.clear();
        selection.addAll(notes());
        host.onSelectionChanged();
        invalidate();
    }

    private List<Project.Note> targets() {
        return selection.isEmpty() ? new ArrayList<>(notes()) : new ArrayList<>(selection);
    }

    void copy() {
        clipboard.clear();
        List<Project.Note> t = targets();
        int min = Integer.MAX_VALUE;
        for (Project.Note n : t) min = Math.min(min, n.start);
        for (Project.Note n : t) {
            Project.Note c = n.copy();
            c.start -= min;
            clipboard.add(c);
        }
    }

    boolean canPaste() {
        return !clipboard.isEmpty();
    }

    /** Вставить в начало видимой области (по сетке). */
    void paste() {
        if (clipboard.isEmpty() || channel() == null) return;
        s.checkpoint();
        int at = Math.max(0, snapFloor(scrollX + Project.STEP / 2.0));
        int plen = s.p.current().ticks();
        selection.clear();
        for (Project.Note n : clipboard) {
            Project.Note c = n.copy();
            c.start += at;
            if (c.start >= plen) continue;
            notes().add(c);
            selection.add(c);
        }
        s.edited();
        host.onSelectionChanged();
        invalidate();
    }

    /** Повторить выделенное сразу после него. */
    void duplicate() {
        List<Project.Note> t = targets();
        if (t.isEmpty()) return;
        s.checkpoint();
        int min = Integer.MAX_VALUE, max = 0;
        for (Project.Note n : t) {
            min = Math.min(min, n.start);
            max = Math.max(max, n.end());
        }
        int span = Math.max(Project.STEP, (int) Math.ceil((max - min) / (double) Project.PPQ) * Project.PPQ);
        Project.Pattern pt = s.p.current();
        if (max + span > pt.ticks()) {
            // паттерн мал — удлиняем до целых тактов
            int needSteps = (int) Math.ceil((max + span) / (double) Project.STEP);
            pt.steps = Math.min(512, ((needSteps + 15) / 16) * 16);
        }
        selection.clear();
        for (Project.Note n : t) {
            Project.Note c = n.copy();
            c.start += span;
            if (c.start >= pt.ticks()) continue;
            notes().add(c);
            selection.add(c);
        }
        s.edited();
        host.onSelectionChanged();
        invalidate();
    }

    void deleteSelected() {
        if (selection.isEmpty()) return;
        s.checkpoint();
        notes().removeAll(selection);
        selection.clear();
        s.edited();
        host.onSelectionChanged();
        invalidate();
    }

    void quantize() {
        List<Project.Note> t = targets();
        if (t.isEmpty()) return;
        s.checkpoint();
        int q = Math.max(Project.STEP / 2, snap <= 1 ? Project.STEP : snap);
        for (Project.Note n : t) {
            n.start = Math.round(n.start / (float) q) * q;
            n.len = Math.max(q, Math.round(n.len / (float) q) * q);
        }
        s.edited();
        invalidate();
    }

    void transpose(int semis) {
        List<Project.Note> t = targets();
        if (t.isEmpty()) return;
        s.checkpoint();
        for (Project.Note n : t) n.key = Math.max(0, Math.min(127, n.key + semis));
        s.edited();
        invalidate();
    }

    /** Притянуть ноты к ладу проекта. */
    void toScale() {
        List<Project.Note> t = targets();
        if (t.isEmpty()) return;
        s.checkpoint();
        for (Project.Note n : t) n.key = Theory.snap(n.key, s.p.key, s.p.scale);
        s.edited();
        invalidate();
    }

    void toggleSlideSelected() {
        if (selection.isEmpty()) return;
        s.checkpoint();
        boolean on = false;
        for (Project.Note n : selection) on |= !n.slide;
        for (Project.Note n : selection) n.slide = on;
        s.edited();
        invalidate();
    }

    /** Вставить ноты из MIDI в канал с позиции at (тики). */
    void insert(List<Project.Note> src, int at) {
        Project.Pattern pt = s.p.current();
        int end = 0;
        for (Project.Note n : src) end = Math.max(end, at + n.end());
        int needSteps = (int) Math.ceil(end / (double) Project.STEP);
        if (needSteps > pt.steps) pt.steps = Math.min(512, ((needSteps + 15) / 16) * 16);
        selection.clear();
        for (Project.Note n : src) {
            Project.Note c = n.copy();
            c.start += at;
            if (c.start >= pt.ticks()) continue;
            notes().add(c);
            selection.add(c);
        }
        fit();
    }
}
