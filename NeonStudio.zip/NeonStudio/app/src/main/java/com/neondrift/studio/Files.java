package com.neondrift.studio;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/** Отдаёт готовые треки, стемы и MIDI другим приложениям по content://-ссылке, только на чтение. */
public class Files extends ContentProvider {
    static final String AUTHORITY = "com.neondrift.studio.files";

    static File exports(Context c) {
        File d = new File(c.getFilesDir(), "exports");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    static File share(Context c) {
        File d = new File(c.getCacheDir(), "share");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    static File root(Context c, String name) {
        switch (name) {
            case "exp": return exports(c);
            case "share": return share(c);
            default: return null;
        }
    }

    static Uri uri(Context c, File f) {
        String root = f.getParentFile() != null && f.getParentFile().equals(exports(c)) ? "exp" : "share";
        return new Uri.Builder().scheme("content").authority(AUTHORITY).appendPath(root).appendPath(f.getName()).build();
    }

    private File resolve(Uri uri) throws FileNotFoundException {
        if (uri.getPathSegments().size() != 2) throw new FileNotFoundException(uri.toString());
        File r = root(getContext(), uri.getPathSegments().get(0));
        String name = uri.getPathSegments().get(1);
        if (r == null || name.contains("/") || name.startsWith(".")) throw new FileNotFoundException(uri.toString());
        File f = new File(r, name);
        try {
            if (!f.getCanonicalPath().startsWith(r.getCanonicalPath() + File.separator)) throw new FileNotFoundException(uri.toString());
        } catch (IOException e) {
            throw new FileNotFoundException(uri.toString());
        }
        return f;
    }

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public ParcelFileDescriptor openFile(Uri uri, String mode) throws FileNotFoundException {
        if (mode.contains("w")) throw new FileNotFoundException("только чтение");
        return ParcelFileDescriptor.open(resolve(uri), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection, String[] args, String sort) {
        File f;
        try {
            f = resolve(uri);
        } catch (FileNotFoundException e) {
            return null;
        }
        String[] cols = projection != null ? projection : new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor c = new MatrixCursor(cols, 1);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = f.getName();
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = f.length();
        }
        c.addRow(row);
        return c;
    }

    @Override
    public String getType(Uri uri) {
        return type(uri.getLastPathSegment());
    }

    static String type(String name) {
        String n = name == null ? "" : name.toLowerCase(java.util.Locale.ROOT);
        if (n.endsWith(".wav")) return "audio/wav";
        if (n.endsWith(".m4a")) return "audio/mp4";
        if (n.endsWith(".mid")) return "audio/midi";
        if (n.endsWith(".zip")) return "application/zip";
        if (n.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int delete(Uri uri, String s, String[] a) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int update(Uri uri, ContentValues v, String s, String[] a) {
        throw new UnsupportedOperationException();
    }
}
