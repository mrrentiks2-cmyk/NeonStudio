package com.neondrift.studio;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Проект: каналы (инструменты + настройки микшера), паттерны с нотами и плейлист.
 * Время — в тиках: 96 на четверть, шаг (1/16) — 24 тика.
 */
final class Project {
    static final int PPQ = 96, STEP = 24, BAR = 16;

    String id = uid();
    String name = "Новый бит";
    long created, edited;
    float bpm = 140f;
    float swing = 0f;           // 0…0.6 — сдвиг чётных шестнадцатых
    int key = 0;                // 0 — C
    int scale = 1;              // индекс в Theory.SCALES
    float masterVol = 0.85f;
    float masterComp = 0.25f;
    float revSize = 0.72f, revDamp = 0.45f, revLevel = 0.9f;
    float delSteps = 3f, delFeedback = 0.35f, delDamp = 0.45f, delLevel = 0.8f;
    boolean songMode, loop = true, metronome;
    String current = "";        // открытый паттерн
    int tracks = 8;

    final List<Channel> channels = new ArrayList<>();
    final List<Pattern> patterns = new ArrayList<>();
    final List<Clip> clips = new ArrayList<>();

    static String uid() {
        return UUID.randomUUID().toString().replace("-", "").substring(0, 12);
    }

    // ================================================================== канал

    static final int SAMPLER = 0, SYNTH = 1, BASS = 2;
    static final String[] TYPES = {"Сэмплер", "Синтезатор", "808"};
    static final int ONESHOT = 0, GATE = 1, LOOP = 2;
    static final String[] MODES = {"Целиком", "По длине ноты", "Петля"};

    static final class Channel {
        String id = uid();
        String name = "Канал";
        String role = "";           // kick, snare, hat, cowbell, 808, lead, chords… — для генератора
        int color = 0xFFFF2D95;
        int type = SAMPLER;

        // сэмплер
        String sample = "";
        int root = 60;
        float tune = 0f;            // полутоны
        float start = 0f, end = 1f; // доли длины
        boolean reverse;
        int mode = ONESHOT;
        int slices;                 // нарезка на N равных частей (0 — нет)
        String sliceMarks = "";     // нарезка по ударам: «0.0,0.13,…»
        float fitBeats;             // подогнать длину под N долей (петли)
        float attack = 0f, decay = 0.3f, sustain = 1f, release = 0.04f;
        int choke;                  // группа заглушения (хэты)

        // синтезатор
        int osc1 = Dsp.SAW, osc2 = Dsp.SAW;
        float osc2Semi = 0f, detune = 8f, mix = 0.5f, sub = 0f, noise = 0f;
        float fm = 0f, fmRatio = 2f, fmDecay = 0.6f;
        int ftype = Dsp.LP;
        float cutoff = 3500f, res = 0.15f, envAmt = 0f;
        float fAttack = 0.002f, fDecay = 0.3f, fSustain = 0f, fRelease = 0.2f;
        float glide = 0f;
        boolean mono;
        float vdrive = 0f;

        // 808
        float punch = 12f, punchTime = 0.035f, drive808 = 0.35f, decay808 = 1.4f, click = 0.25f;

        // микшер
        float vol = 0.8f, pan = 0f;
        boolean mute, solo;
        float fxDrive = 0f;
        int driveType = 0;
        int bits = 16, downsample = 1;
        int fType = Dsp.LP;
        float fCut = 20000f, fRes = 0.1f;
        float eqLow = 0f, eqMid = 0f, eqHigh = 0f;
        float comp = 0f;
        float duck = 0f, duckRelease = 0.22f;
        boolean sideSource;
        float sendRev = 0f, sendDelay = 0f;

        Channel copy() {
            Channel c = new Channel();
            Fields.fill(c, Fields.map(this));
            c.id = uid();
            return c;
        }

        boolean monophonic() {
            return mono || type == BASS;
        }
    }

    // ================================================================== ноты и паттерны

    static final class Note {
        int start, len, key;
        float vel = 0.8f;
        boolean slide;

        Note(int start, int len, int key, float vel) {
            this.start = start;
            this.len = len;
            this.key = key;
            this.vel = vel;
        }

        Note copy() {
            Note n = new Note(start, len, key, vel);
            n.slide = slide;
            return n;
        }

        int end() {
            return start + len;
        }
    }

    static final class Pattern {
        String id = uid();
        String name = "Паттерн";
        int color = 0xFF9D6BFF;
        int steps = 16;
        final Map<String, List<Note>> notes = new HashMap<>();

        List<Note> notes(String channel) {
            List<Note> l = notes.get(channel);
            if (l == null) {
                l = new ArrayList<>();
                notes.put(channel, l);
            }
            return l;
        }

        int ticks() {
            return steps * STEP;
        }

        boolean empty() {
            for (List<Note> l : notes.values()) if (!l.isEmpty()) return false;
            return true;
        }

        Pattern copy() {
            Pattern p = new Pattern();
            p.name = name;
            p.color = color;
            p.steps = steps;
            for (Map.Entry<String, List<Note>> e : notes.entrySet()) {
                ArrayList<Note> l = new ArrayList<>();
                for (Note n : e.getValue()) l.add(n.copy());
                p.notes.put(e.getKey(), l);
            }
            return p;
        }
    }

    /** Паттерн в плейлисте: дорожка, начало и длина в шагах. Длиннее паттерна — повторяется. */
    static final class Clip {
        String pattern;
        int track, start, len;
        boolean mute;

        Clip(String pattern, int track, int start, int len) {
            this.pattern = pattern;
            this.track = track;
            this.start = start;
            this.len = len;
        }

        int end() {
            return start + len;
        }
    }

    // ================================================================== поиск

    Channel channel(String id) {
        for (Channel c : channels) if (c.id.equals(id)) return c;
        return null;
    }

    Pattern pattern(String id) {
        for (Pattern p : patterns) if (p.id.equals(id)) return p;
        return null;
    }

    Pattern current() {
        Pattern p = pattern(current);
        if (p == null) {
            if (patterns.isEmpty()) patterns.add(new Pattern());
            p = patterns.get(0);
            current = p.id;
        }
        return p;
    }

    /** Длина песни в шагах (до конца последнего клипа). */
    int songSteps() {
        int end = 0;
        for (Clip c : clips) end = Math.max(end, c.end());
        return end;
    }

    void removeChannel(Channel c) {
        channels.remove(c);
        for (Pattern p : patterns) p.notes.remove(c.id);
    }

    void removePattern(Pattern p) {
        patterns.remove(p);
        clips.removeIf(c -> c.pattern.equals(p.id));
        if (current.equals(p.id)) current = patterns.isEmpty() ? "" : patterns.get(0).id;
    }

    // ================================================================== JSON

    String toJson() {
        LinkedHashMap<String, Object> m = new LinkedHashMap<>();
        m.put("app", "Neon Studio");
        m.put("format", 1L);
        m.putAll(Fields.map(this));
        ArrayList<Object> ch = new ArrayList<>();
        for (Channel c : channels) ch.add(Fields.map(c));
        m.put("channels", ch);
        ArrayList<Object> ps = new ArrayList<>();
        for (Pattern p : patterns) {
            LinkedHashMap<String, Object> pm = new LinkedHashMap<>();
            pm.put("id", p.id);
            pm.put("name", p.name);
            pm.put("color", (long) p.color);
            pm.put("steps", (long) p.steps);
            LinkedHashMap<String, Object> nm = new LinkedHashMap<>();
            for (Map.Entry<String, List<Note>> e : p.notes.entrySet()) {
                if (e.getValue().isEmpty()) continue;
                // компактно: [start, len, key, vel×100, slide]
                ArrayList<Object> arr = new ArrayList<>();
                for (Note n : e.getValue()) {
                    ArrayList<Object> a = new ArrayList<>();
                    a.add((long) n.start);
                    a.add((long) n.len);
                    a.add((long) n.key);
                    a.add((long) Math.round(n.vel * 100));
                    a.add(n.slide ? 1L : 0L);
                    arr.add(a);
                }
                nm.put(e.getKey(), arr);
            }
            pm.put("notes", nm);
            ps.add(pm);
        }
        m.put("patterns", ps);
        ArrayList<Object> cl = new ArrayList<>();
        for (Clip c : clips) {
            LinkedHashMap<String, Object> cm = new LinkedHashMap<>();
            cm.put("p", c.pattern);
            cm.put("t", (long) c.track);
            cm.put("s", (long) c.start);
            cm.put("l", (long) c.len);
            if (c.mute) cm.put("m", true);
            cl.add(cm);
        }
        m.put("clips", cl);
        return Json.write(m);
    }

    @SuppressWarnings("unchecked")
    static Project fromJson(String json) {
        Object o = Json.parse(json);
        if (!(o instanceof Map)) throw new IllegalArgumentException("не проект");
        Map<String, Object> m = (Map<String, Object>) o;
        if (!m.containsKey("channels")) throw new IllegalArgumentException("не проект Neon Studio");
        Project p = new Project();
        Fields.fill(p, m);
        p.bpm = Dsp.clamp(p.bpm, 40f, 300f);
        p.swing = Dsp.clamp(p.swing, 0f, 0.6f);
        p.tracks = Math.max(1, Math.min(64, p.tracks));
        for (Object co : Json.list(m, "channels")) {
            if (!(co instanceof Map)) continue;
            Channel c = new Channel();
            Fields.fill(c, (Map<String, Object>) co);
            p.channels.add(c);
        }
        for (Object po : Json.list(m, "patterns")) {
            if (!(po instanceof Map)) continue;
            Map<String, Object> pm = (Map<String, Object>) po;
            Pattern pt = new Pattern();
            pt.id = Json.str(pm, "id", pt.id);
            pt.name = Json.str(pm, "name", pt.name);
            pt.color = (int) Json.num(pm, "color", pt.color);
            pt.steps = (int) Math.max(1, Math.min(512, Json.num(pm, "steps", 16)));
            Object nm = pm.get("notes");
            if (nm instanceof Map) {
                for (Map.Entry<String, Object> e : ((Map<String, Object>) nm).entrySet()) {
                    if (!(e.getValue() instanceof List)) continue;
                    ArrayList<Note> l = new ArrayList<>();
                    for (Object no : (List<Object>) e.getValue()) {
                        if (!(no instanceof List) || ((List<Object>) no).size() < 4) continue;
                        List<Object> a = (List<Object>) no;
                        Note n = new Note(num(a, 0), Math.max(1, num(a, 1)), Math.max(0, Math.min(127, num(a, 2))), Dsp.clamp(num(a, 3) / 100f, 0.01f, 1f));
                        n.slide = a.size() > 4 && num(a, 4) != 0;
                        l.add(n);
                    }
                    pt.notes.put(e.getKey(), l);
                }
            }
            p.patterns.add(pt);
        }
        for (Object co : Json.list(m, "clips")) {
            if (!(co instanceof Map)) continue;
            Map<String, Object> cm = (Map<String, Object>) co;
            Clip c = new Clip(Json.str(cm, "p", ""), (int) Json.num(cm, "t", 0), (int) Json.num(cm, "s", 0), (int) Math.max(1, Json.num(cm, "l", 16)));
            c.mute = Json.bool(cm, "m");
            if (p.pattern(c.pattern) != null) p.clips.add(c);
        }
        p.current();
        return p;
    }

    private static int num(List<Object> a, int i) {
        Object v = a.get(i);
        return v instanceof Number ? ((Number) v).intValue() : 0;
    }

    Project copy() {
        Project p = fromJson(toJson());
        p.id = uid();
        return p;
    }

    // ================================================================== простые поля через отражение

    /** Числа, строки и флаги объекта ↔ Map. Новые параметры сохраняются сами, без ручного кода. */
    static final class Fields {
        private Fields() {}

        static LinkedHashMap<String, Object> map(Object o) {
            LinkedHashMap<String, Object> m = new LinkedHashMap<>();
            for (Field f : o.getClass().getDeclaredFields()) {
                int mod = f.getModifiers();
                if (Modifier.isStatic(mod) || Modifier.isTransient(mod) || f.isSynthetic()) continue;
                Class<?> t = f.getType();
                try {
                    f.setAccessible(true);
                    if (t == float.class) m.put(f.getName(), round(f.getFloat(o)));
                    else if (t == int.class) m.put(f.getName(), (long) f.getInt(o));
                    else if (t == long.class) m.put(f.getName(), f.getLong(o));
                    else if (t == boolean.class) m.put(f.getName(), f.getBoolean(o));
                    else if (t == String.class) m.put(f.getName(), f.get(o));
                } catch (IllegalAccessException ignored) {
                }
            }
            return m;
        }

        private static double round(float v) {
            return Math.round(v * 100000.0) / 100000.0;
        }

        static void fill(Object o, Map<String, Object> m) {
            for (Field f : o.getClass().getDeclaredFields()) {
                int mod = f.getModifiers();
                if (Modifier.isStatic(mod) || Modifier.isTransient(mod) || Modifier.isFinal(mod) || f.isSynthetic()) continue;
                Object v = m.get(f.getName());
                if (v == null) continue;
                Class<?> t = f.getType();
                try {
                    f.setAccessible(true);
                    if (t == float.class && v instanceof Number) {
                        float x = ((Number) v).floatValue();
                        if (!Float.isNaN(x) && !Float.isInfinite(x)) f.setFloat(o, x);
                    } else if (t == int.class && v instanceof Number) f.setInt(o, ((Number) v).intValue());
                    else if (t == long.class && v instanceof Number) f.setLong(o, ((Number) v).longValue());
                    else if (t == boolean.class && v instanceof Boolean) f.setBoolean(o, (Boolean) v);
                    else if (t == String.class && v instanceof String) f.set(o, v);
                } catch (IllegalAccessException ignored) {
                }
            }
        }
    }
}
