package com.neondrift.studio;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Генератор битов по стилям: барабаны, мелодия ковбелла/колокола, 808 со слайдами, аккорды, фанк-бас.
 * Всё в выбранной тональности; одинаковое зерно — одинаковый результат.
 */
final class Generator {
    private Generator() {}

    static final String[] STYLES = {"Drift Phonk", "Memphis Phonk", "Бразильский фонк", "Funk"};
    static final float[] BPM = {150f, 132f, 130f, 108f};
    static final int[] SCALE = {2, 1, 2, 4};
    static final float[] SWING = {0f, 0.16f, 0f, 0.12f};
    static final int DRIFT = 0, MEMPHIS = 1, BRAZIL = 2, FUNK = 3;

    static final class Options {
        boolean drums = true, melody = true, bass = true, chords;
        int bars = 2;
        long seed = System.nanoTime();
        boolean applyStyle;     // поставить темп, лад и свинг стиля
    }

    private static final String[][] KICKS = {
            {"x.....x...x.....", "x..x..x...x.....", "x.....x..x..x...", "x.x...x...x....."},
            {"x.....x.x.......", "x..x......x.....", "x.......x.x....."},
            {"x..x..x...x..x..", "x..x..x...x.x..x", "x..x..x.x.x..x.."},
            {"x.........x.x...", "x......x..x.....", "x.x.......x..x.."},
    };
    private static final String[][] RHYTHMS = {
            {"x..x..x.x..x..x.", "x..x..x...x.x...", "x.x..x..x.x..x..", "x..x..x..x..x.x."},
            {"x.......x...x...", "x...x.......x.x.", "x.....x.x.......", "x...x...x...x..."},
            {"x.xx.x.xx.x.x.x.", "x..xx.x.x..xx.x.", "xx.x.xx.x.x.xx.x", "x.x.xx.x.x.xx.x."},
            {"x..x..xx..xx..x.", "x.x..x.x..x..xx.", "x..x.x..x.xx.x..", "x.xx..x..x.x..x."},
    };

    static void generate(Project p, Project.Pattern pt, int style, Options o) {
        Random r = new Random(o.seed);
        style = Math.max(0, Math.min(STYLES.length - 1, style));
        if (o.applyStyle) {
            p.bpm = BPM[style];
            p.scale = SCALE[style];
            p.swing = SWING[style];
        }
        pt.steps = 16 * Math.max(1, Math.min(4, o.bars));
        int bars = pt.steps / 16;
        int[] kick = pattern(KICKS[style], bars, r);
        int[] prog = progression(style, bars, r);
        if (o.drums) drums(p, pt, style, bars, kick, r);
        if (o.melody) melody(p, pt, style, bars, r);
        if (o.bass) {
            if (style == FUNK) funkBass(p, pt, bars, prog, r);
            else bass808(p, pt, style, bars, kick, prog, r);
        }
        if (o.chords || style == FUNK) chords(p, pt, style, bars, prog, r);
        if (style == MEMPHIS) {
            Project.Channel v = Presets.ensure(p, "vinyl");
            List<Project.Note> l = clear(pt, v);
            l.add(new Project.Note(0, pt.ticks(), 60, 0.6f));
        }
    }

    // ================================================================== барабаны

    private static void drums(Project p, Project.Pattern pt, int style, int bars, int[] kick, Random r) {
        Project.Channel k = Presets.ensure(p, "kick");
        k.sample = Kits.PREFIX + (style == FUNK ? "kick_funk" : style == DRIFT ? "kick_drift" : "kick_memphis");
        List<Project.Note> kl = clear(pt, k);
        for (int s = 0; s < kick.length; s++) if (kick[s] > 0) kl.add(note(s, 1, 60, 0.95f, r));

        Project.Channel sn = Presets.ensure(p, "snare");
        sn.sample = Kits.PREFIX + (style == FUNK ? "snare_funk" : style == DRIFT ? "snare_crunch" : "snare_memphis");
        List<Project.Note> sl = clear(pt, sn);
        Project.Channel cl = Presets.ensure(p, "clap");
        List<Project.Note> cll = clear(pt, cl);
        for (int b = 0; b < bars; b++) {
            int o = b * 16;
            sl.add(note(o + 4, 1, 60, 0.9f, r));
            sl.add(note(o + 12, 1, 60, 0.9f, r));
            if (style != FUNK) {
                cll.add(note(o + 4, 1, 60, 0.8f, r));
                cll.add(note(o + 12, 1, 60, 0.8f, r));
            }
            if (style == FUNK) {
                // призрачные ноты малого
                int[] ghosts = {2, 3, 7, 9, 10, 14, 15};
                for (int g : ghosts) if (r.nextFloat() < 0.4f) sl.add(new Project.Note((o + g) * Project.STEP, Project.STEP, 60, 0.18f + r.nextFloat() * 0.1f));
            }
            if (style == BRAZIL && r.nextBoolean()) cll.add(note(o + 7, 1, 60, 0.6f, r));
            if (style == DRIFT && b == bars - 1 && r.nextBoolean()) sl.add(note(o + 15, 1, 60, 0.55f, r));
        }

        Project.Channel h = Presets.ensure(p, "hat");
        List<Project.Note> hl = clear(pt, h);
        Project.Channel oh = Presets.ensure(p, "ohat");
        List<Project.Note> ohl = clear(pt, oh);
        for (int b = 0; b < bars; b++) {
            int o = b * 16;
            for (int beat = 0; beat < 4; beat++) {
                int s = o + beat * 4;
                boolean roll = style != FUNK && (beat == 3 || r.nextFloat() < 0.18f) && r.nextFloat() < 0.55f;
                if (roll) {
                    // дробь: триоли шестнадцатыми на всю долю, громкость нарастает
                    int n = r.nextBoolean() ? 6 : 4;
                    for (int i = 0; i < n; i++) {
                        hl.add(new Project.Note(s * Project.STEP + i * Project.PPQ / n, Project.PPQ / n, 60, 0.35f + 0.45f * i / n));
                    }
                    continue;
                }
                if (style == FUNK || style == MEMPHIS) {
                    for (int i = 0; i < 4; i++) {
                        if (style == FUNK && beat == 3 && i == 2 && b == bars - 1) {
                            ohl.add(note(s + i, 2, 60, 0.6f, r));
                            continue;
                        }
                        hl.add(note(s + i, 1, 60, i == 0 ? 0.72f : i == 2 ? 0.58f : 0.38f, r));
                    }
                } else {
                    hl.add(note(s, 1, 60, 0.7f, r));
                    hl.add(note(s + 2, 1, 60, 0.5f, r));
                }
            }
            if (style == DRIFT || style == BRAZIL) {
                if (r.nextFloat() < 0.6f) ohl.add(note(o + 6, 2, 60, 0.45f, r));
                if (b == bars - 1) ohl.add(note(o + 14, 2, 60, 0.5f, r));
            }
        }
        if (style == BRAZIL || style == FUNK) {
            Project.Channel pc = Presets.ensure(p, "perc");
            pc.sample = Kits.PREFIX + (style == BRAZIL ? "conga" : "tambourine");
            List<Project.Note> pl = clear(pt, pc);
            String pat = style == BRAZIL ? "..x..x..x..x..x." : "....x.......x...";
            for (int b = 0; b < bars; b++) {
                for (int s = 0; s < 16; s++) {
                    if (pat.charAt(s) == 'x') pl.add(note(b * 16 + s, 1, style == BRAZIL ? (s % 3 == 2 ? 62 : 60) : 60, 0.6f, r));
                }
            }
        }
    }

    // ================================================================== мелодия

    private static void melody(Project p, Project.Pattern pt, int style, int bars, Random r) {
        String role = style == MEMPHIS ? "bell" : style == FUNK ? "lead" : "cowbell";
        Project.Channel c = Presets.ensure(p, role);
        if (style == FUNK) Presets.synth(c, 6); // вау-плак
        List<Project.Note> l = clear(pt, c);
        String rhythm = RHYTHMS[style][r.nextInt(RHYTHMS[style].length)];
        ArrayList<Integer> onsets = new ArrayList<>();
        for (int s = 0; s < 16; s++) if (rhythm.charAt(s) == 'x') onsets.add(s);
        int oct = style == FUNK ? 4 : style == MEMPHIS ? 4 : 5;
        // мотив: случайное блуждание по ступеням с тягой к тонике
        int[] motif = new int[onsets.size()];
        int deg = r.nextBoolean() ? 0 : 2;
        for (int i = 0; i < motif.length; i++) {
            motif[i] = deg;
            int step = r.nextInt(5) - 2;
            if (deg > 5) step = -Math.abs(step);
            if (deg < -2) step = Math.abs(step);
            if (r.nextFloat() < 0.25f) step = -deg / 2; // к тонике
            deg += step;
        }
        if (motif.length > 1) motif[motif.length - 1] = r.nextBoolean() ? 4 : 6;
        for (int b = 0; b < bars; b++) {
            boolean last = b == bars - 1 && bars > 1;
            for (int i = 0; i < onsets.size(); i++) {
                int s = onsets.get(i);
                int next = i + 1 < onsets.size() ? onsets.get(i + 1) : 16;
                int d = motif[i];
                if (last && i >= onsets.size() - 2) d = i == onsets.size() - 1 ? 0 : d - 1; // в конце — к тонике
                if (style == BRAZIL && r.nextFloat() < 0.15f) d += 7; // скачки на октаву
                int key = Theory.degree(p.key, p.scale, d, oct);
                int len = style == MEMPHIS ? Math.max(1, next - s) : Math.min(2, Math.max(1, next - s));
                l.add(note(b * 16 + s, len, key, i == 0 ? 0.92f : 0.78f, r));
            }
        }
    }

    // ================================================================== басы

    private static int[] progression(int style, int bars, Random r) {
        int[][] options = style == FUNK ? new int[][]{{0, 3}, {0, 0}, {0, 4}} : style == MEMPHIS ? new int[][]{{0, 5}, {0, 3}, {0, 4}}
                : new int[][]{{0, 1}, {0, 5}, {0, 0}, {0, 3}};
        int[] pick = options[r.nextInt(options.length)];
        int[] out = new int[bars];
        for (int b = 0; b < bars; b++) out[b] = pick[b % pick.length];
        return out;
    }

    private static void bass808(Project p, Project.Pattern pt, int style, int bars, int[] kick, int[] prog, Random r) {
        Project.Channel c = Presets.ensure(p, "808");
        Presets.bass(c, style == BRAZIL ? 4 : style == MEMPHIS ? 1 : 0);
        List<Project.Note> l = clear(pt, c);
        ArrayList<Integer> on = new ArrayList<>();
        for (int s = 0; s < kick.length; s++) if (kick[s] > 0) on.add(s);
        boolean up = false;
        for (int i = 0; i < on.size(); i++) {
            int s = on.get(i), next = i + 1 < on.size() ? on.get(i + 1) : kick.length;
            int bar = s / 16;
            int key = Theory.degree(p.key, p.scale, prog[bar], 1);
            if (key < 28) key += 12;
            boolean slide = false;
            if (up) { // после скачка — плавно вниз
                slide = true;
                up = false;
            } else if (style != MEMPHIS && i > 0 && r.nextFloat() < (style == BRAZIL ? 0.4f : 0.3f)) {
                key += 12;
                slide = true;
                up = true;
            }
            Project.Note n = note(s, Math.max(1, next - s), key, 1f, r);
            n.slide = slide;
            l.add(n);
        }
    }

    private static void funkBass(Project p, Project.Pattern pt, int bars, int[] prog, Random r) {
        Project.Channel c = Presets.ensure(p, "bass");
        List<Project.Note> l = clear(pt, c);
        String rhythm = RHYTHMS[FUNK][r.nextInt(RHYTHMS[FUNK].length)];
        int[] tones = {0, 0, 7, 12, 10, 5, 3}; // тоника, квинта, октава, септима — фанковый набор
        for (int b = 0; b < bars; b++) {
            int root = Theory.degree(p.key, p.scale, prog[b], 2);
            for (int s = 0; s < 16; s++) {
                if (rhythm.charAt(s) != 'x') continue;
                int iv = s == 0 ? 0 : tones[r.nextInt(tones.length)];
                int key = Theory.snap(root + iv, p.key, p.scale);
                boolean shortNote = r.nextFloat() < 0.6f;
                l.add(note(b * 16 + s, shortNote ? 1 : 2, key, s % 4 == 0 ? 0.95f : 0.78f, r));
            }
        }
    }

    private static void chords(Project p, Project.Pattern pt, int style, int bars, int[] prog, Random r) {
        Project.Channel c = Presets.ensure(p, style == FUNK ? "keys" : "chords");
        List<Project.Note> l = clear(pt, c);
        for (int b = 0; b < bars; b++) {
            int[] ch = Theory.chord(p.key, p.scale, prog[b], style == FUNK ? 4 : 3, style == FUNK ? 4 : 3);
            if (style == FUNK) {
                // короткие аккорды на слабые доли
                int[] stabs = {2, 6, 10, 13};
                for (int s : stabs) {
                    if (r.nextFloat() < 0.2f) continue;
                    for (int k : ch) l.add(note(b * 16 + s, 1, k, 0.62f, r));
                }
            } else {
                for (int k : ch) l.add(note(b * 16, 16, k, 0.6f, r));
            }
        }
    }

    // ================================================================== мелочи

    private static int[] pattern(String[] variants, int bars, Random r) {
        int[] out = new int[bars * 16];
        String a = variants[r.nextInt(variants.length)], b = variants[r.nextInt(variants.length)];
        for (int bar = 0; bar < bars; bar++) {
            String v = bar % 2 == 1 && r.nextFloat() < 0.6f ? b : a;
            for (int s = 0; s < 16; s++) out[bar * 16 + s] = v.charAt(s) == 'x' ? 1 : 0;
        }
        return out;
    }

    private static Project.Note note(int step, int lenSteps, int key, float vel, Random r) {
        float v = Math.max(0.05f, Math.min(1f, vel + (r.nextFloat() - 0.5f) * 0.08f));
        return new Project.Note(step * Project.STEP, Math.max(1, lenSteps) * Project.STEP, key, v);
    }

    private static List<Project.Note> clear(Project.Pattern pt, Project.Channel c) {
        List<Project.Note> l = pt.notes(c.id);
        l.clear();
        return l;
    }
}
