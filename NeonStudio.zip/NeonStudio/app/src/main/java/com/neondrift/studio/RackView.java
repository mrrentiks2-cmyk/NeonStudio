package com.neondrift.studio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.List;

/**
 * Стойка каналов с шаговым секвенсором. Касание шага ставит/снимает ноту, ведение пальцем
 * по ряду «рисует». В режиме «Сила» шаги показывают громкость — тяните вверх-вниз.
 */
final class RackView extends View {
    interface Host {
        void openChannel(Project.Channel c);

        void channelMenu(Project.Channel c);

        void addChannel();

        void openPiano(Project.Channel c);
    }

    private final Studio s;
    private final Ui ui;
    private final Host host;
    boolean velocityMode;
    int page;                   // страница шагов, если все не помещаются

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint small = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF(), r2 = new RectF();

    private float scrollY;
    private final float rowH, headH, gap, minCell, touchSlop;

    RackView(Context c, Studio s, Ui ui, Host host) {
        super(c);
        this.s = s;
        this.ui = ui;
        this.host = host;
        rowH = ui.dp(46);
        headH = ui.dp(26);
        gap = ui.dp(3);
        minCell = ui.dp(16);
        touchSlop = ViewConfiguration.get(c).getScaledTouchSlop();
        text.setColor(Theme.TEXT);
        text.setTextSize(ui.dp(13));
        text.setTypeface(Typeface.DEFAULT_BOLD);
        small.setColor(Theme.MUTED);
        small.setTextSize(ui.dp(10.5f));
        setHapticFeedbackEnabled(true);
    }

    // ================================================================== разметка

    private float nameW() {
        if (getWidth() >= ui.dp(520)) return ui.dp(136);
        // на узком экране — сколько останется после 16 шагов по 17 dp
        return Math.max(ui.dp(72), Math.min(ui.dp(100), getWidth() - ui.dp(16 * 17 + 12)));
    }

    private float stepsX() {
        return nameW() + ui.dp(6);
    }

    /** Сколько шагов видно на странице (кратно 4). */
    int visibleSteps() {
        int total = s.p.current().steps;
        float w = getWidth() - stepsX() - ui.dp(6);
        int fit = (int) (w / minCell);
        fit = Math.max(4, fit - fit % 4);
        if (fit >= total) return total;
        // предпочитаем такт целиком
        if (fit >= 16) fit -= fit % 16;
        return fit;
    }

    int pages() {
        int v = visibleSteps();
        return (s.p.current().steps + v - 1) / v;
    }

    private float cellW() {
        return (getWidth() - stepsX() - ui.dp(6)) / visibleSteps();
    }

    private float contentH() {
        return headH + (s.p.channels.size() + 1) * rowH + ui.dp(8);
    }

    private void clampScroll() {
        scrollY = Math.max(0, Math.min(scrollY, Math.max(0, contentH() - getHeight())));
        page = Math.max(0, Math.min(page, pages() - 1));
    }

    // ================================================================== рисование

    @Override
    protected void onDraw(Canvas c) {
        clampScroll();
        Project p = s.p;
        Project.Pattern pt = p.current();
        int vis = visibleSteps(), first = page * vis;
        float cw = cellW(), sx = stepsX(), nw = nameW();
        // шапка: номера тактов и страницы
        fill.setColor(Theme.BG);
        c.drawRect(0, 0, getWidth(), headH, fill);
        small.setTextAlign(Paint.Align.LEFT);
        int pages = pages();
        if (pages > 1) {
            float pw = Math.min(ui.dp(34), (nw - ui.dp(8)) / pages);
            for (int i = 0; i < pages; i++) {
                r.set(ui.dp(4) + i * pw, ui.dp(4), ui.dp(4) + (i + 1) * pw - ui.dp(3), headH - ui.dp(4));
                fill.setColor(i == page ? Theme.ACCENT : Theme.SURFACE2);
                c.drawRoundRect(r, ui.dp(4), ui.dp(4), fill);
                small.setColor(i == page ? Theme.BG : Theme.MUTED);
                small.setTextAlign(Paint.Align.CENTER);
                c.drawText(String.valueOf(i + 1), r.centerX(), r.centerY() + ui.dp(4), small);
                small.setTextAlign(Paint.Align.LEFT);
            }
        } else {
            small.setColor(Theme.MUTED);
            c.drawText(pt.name, ui.dp(6), headH - ui.dp(9), small);
        }
        for (int i = 0; i < vis && first + i < pt.steps; i++) {
            int step = first + i;
            if (step % 4 == 0) {
                small.setColor(step % 16 == 0 ? Theme.TEXT : Theme.MUTED);
                String lbl = step % 16 == 0 ? String.valueOf(step / 16 + 1) : "·";
                c.drawText(lbl, sx + i * cw + ui.dp(2), headH - ui.dp(9), small);
            }
        }
        // курсор воспроизведения
        int playStep = -1;
        if (s.playing() && !s.engine.songMode) {
            playStep = (int) (s.position() / Project.STEP) % Math.max(1, pt.steps);
        }
        c.save();
        c.clipRect(0, headH, getWidth(), getHeight());
        float y = headH - scrollY;
        List<Project.Channel> chs = p.channels;
        boolean anySolo = false;
        for (Project.Channel ch : chs) anySolo |= ch.solo;
        for (int row = 0; row < chs.size(); row++, y += rowH) {
            if (y + rowH < headH || y > getHeight()) continue;
            Project.Channel ch = chs.get(row);
            boolean selected = ch.id.equals(s.sel);
            boolean audible = !ch.mute && (!anySolo || ch.solo);
            // имя
            r.set(ui.dp(4), y + gap, nw, y + rowH - gap);
            fill.setColor(selected ? Theme.alpha(Theme.ACCENT, 46) : Theme.SURFACE);
            c.drawRoundRect(r, ui.dp(8), ui.dp(8), fill);
            fill.setColor(ch.color);
            r.set(ui.dp(4), y + gap + ui.dp(6), ui.dp(8), y + rowH - gap - ui.dp(6));
            c.drawRoundRect(r, ui.dp(2), ui.dp(2), fill);
            // индикатор «звучит»
            float ledX = nw - ui.dp(12), ledY = y + rowH / 2f;
            fill.setColor(audible ? 0xFF8CFF5A : 0xFF3A3450);
            c.drawCircle(ledX, ledY, ui.dp(5), fill);
            float textMax = ledX - ui.dp(20);
            text.setColor(audible ? Theme.TEXT : Theme.MUTED);
            c.drawText(fit(ch.name, text, textMax), ui.dp(13), y + rowH / 2f - ui.dp(1), text);
            String sub;
            int subColor = Theme.MUTED;
            if (ch.type == Project.SAMPLER) {
                if (s.broken(ch.sample)) {
                    sub = "не открылся";
                    subColor = 0xFFFF5470;
                } else if (s.loading(ch.sample)) {
                    sub = "загрузка…";
                } else {
                    sub = Sounds.title(ch.sample);
                }
            } else {
                sub = ch.type == Project.BASS ? "808" : "синт";
            }
            small.setColor(subColor);
            c.drawText(fit(sub, small, textMax), ui.dp(13), y + rowH / 2f + ui.dp(13), small);
            // шаги
            List<Project.Note> notes = pt.notes.get(ch.id);
            for (int i = 0; i < vis; i++) {
                int step = first + i;
                if (step >= pt.steps) break;
                float x0 = sx + i * cw;
                r.set(x0 + gap / 2, y + gap, x0 + cw - gap / 2, y + rowH - gap);
                boolean dark = (step / 4) % 2 == 1;
                int base = dark ? 0xFF1B1629 : 0xFF241E36;
                if (step == playStep) base = Theme.mix(base, Theme.TEXT, 0.18f);
                fill.setColor(base);
                c.drawRoundRect(r, ui.dp(5), ui.dp(5), fill);
                Project.Note n = noteAt(notes, step);
                if (n == null) continue;
                if (velocityMode) {
                    float h = (r.height() - ui.dp(4)) * n.vel;
                    r2.set(r.left + ui.dp(2), r.bottom - ui.dp(2) - h, r.right - ui.dp(2), r.bottom - ui.dp(2));
                    fill.setColor(audible ? ch.color : Theme.mix(ch.color, Theme.BG, 0.6f));
                    c.drawRoundRect(r2, ui.dp(3), ui.dp(3), fill);
                } else {
                    int col = audible ? ch.color : Theme.mix(ch.color, Theme.BG, 0.6f);
                    fill.setColor(Theme.mix(Theme.mix(col, Theme.BG, 0.55f), col, 0.35f + 0.65f * n.vel));
                    r.inset(ui.dp(1.5f), ui.dp(1.5f));
                    c.drawRoundRect(r, ui.dp(4), ui.dp(4), fill);
                    if (n.key != s.defaultKey(ch) && cw > ui.dp(22)) {
                        small.setColor(Theme.BG);
                        small.setTextAlign(Paint.Align.CENTER);
                        c.drawText(Theory.name(n.key), r.centerX(), r.bottom - ui.dp(4), small);
                        small.setTextAlign(Paint.Align.LEFT);
                    }
                    if (n.start % Project.STEP != 0) {
                        fill.setColor(Theme.BG);
                        c.drawCircle(r.left + ui.dp(4), r.top + ui.dp(4), ui.dp(1.6f), fill);
                    }
                }
            }
        }
        // «добавить канал»
        if (y < getHeight()) {
            r.set(ui.dp(4), y + gap, getWidth() - ui.dp(6), y + rowH - gap);
            fill.setStyle(Paint.Style.STROKE);
            fill.setStrokeWidth(ui.dp(1));
            fill.setColor(Theme.LINE);
            c.drawRoundRect(r, ui.dp(8), ui.dp(8), fill);
            fill.setStyle(Paint.Style.FILL);
            text.setColor(Theme.MUTED);
            text.setTextAlign(Paint.Align.CENTER);
            c.drawText("＋  Добавить канал", r.centerX(), r.centerY() + ui.dp(5), text);
            text.setTextAlign(Paint.Align.LEFT);
        }
        c.restore();
    }

    private static String fit(String s, Paint p, float max) {
        if (s == null) return "";
        if (p.measureText(s) <= max) return s;
        int n = p.breakText(s, true, max - p.measureText("…"), null);
        return s.substring(0, Math.max(0, n)) + "…";
    }

    static Project.Note noteAt(List<Project.Note> notes, int step) {
        if (notes == null) return null;
        int a = step * Project.STEP, b = a + Project.STEP;
        for (Project.Note n : notes) if (n.start >= a && n.start < b) return n;
        return null;
    }

    // ================================================================== касания

    private static final int NONE = 0, SCROLL = 1, PAINT = 2, VEL = 3, NAME = 4, PAGES = 5;
    private int mode;
    private float downX, downY, lastY;
    private int paintRow = -1;
    private boolean paintAdd, changed;
    private int lastStep = -1;
    private final Runnable longPress = this::onLongPress;
    private boolean longFired;

    private int rowAt(float y) {
        if (y < headH) return -2;
        return (int) Math.floor((y - headH + scrollY) / rowH);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                downX = x;
                downY = y;
                lastY = y;
                changed = false;
                longFired = false;
                lastStep = -1;
                int row = rowAt(y);
                if (row == -2) {
                    mode = PAGES;
                    return true;
                }
                if (row >= s.p.channels.size()) {
                    mode = NAME;
                    return true;
                }
                if (x < stepsX()) {
                    mode = NAME;
                    postDelayed(longPress, ViewConfiguration.getLongPressTimeout());
                    return true;
                }
                paintRow = row;
                mode = velocityMode ? VEL : PAINT;
                int step = stepAt(x);
                if (step < 0) return true;
                getParent().requestDisallowInterceptTouchEvent(true);
                Project.Channel ch = s.p.channels.get(row);
                if (mode == PAINT) {
                    paintAdd = noteAt(s.p.current().notes.get(ch.id), step) == null;
                    applyPaint(ch, step);
                } else {
                    applyVel(ch, step, y);
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (mode == NAME) {
                    if (Math.abs(y - downY) > touchSlop || Math.abs(x - downX) > touchSlop) {
                        removeCallbacks(longPress);
                        if (!longFired) mode = SCROLL;
                    }
                }
                if (mode == SCROLL) {
                    scrollY -= y - lastY;
                    clampScroll();
                    invalidate();
                } else if (mode == PAINT || mode == VEL) {
                    int step = stepAt(x);
                    if (step >= 0 && paintRow >= 0 && paintRow < s.p.channels.size()) {
                        Project.Channel ch = s.p.channels.get(paintRow);
                        if (mode == PAINT) {
                            if (step != lastStep) applyPaint(ch, step);
                        } else {
                            applyVel(ch, step, y);
                        }
                    }
                }
                lastY = y;
                return true;
            }
            case MotionEvent.ACTION_UP: {
                removeCallbacks(longPress);
                if (mode == NAME && !longFired && Math.abs(y - downY) < touchSlop) {
                    int row = rowAt(y);
                    if (row >= 0 && row < s.p.channels.size()) {
                        Project.Channel ch = s.p.channels.get(row);
                        if (x > nameW() - ui.dp(26)) {
                            s.checkpoint();
                            ch.mute = !ch.mute;
                            s.tweaked();
                            haptic();
                        } else {
                            s.select(ch);
                            host.openChannel(ch);
                        }
                    } else if (row == s.p.channels.size()) {
                        host.addChannel();
                    }
                } else if (mode == PAGES && Math.abs(x - downX) < touchSlop) {
                    int pages = pages();
                    if (pages > 1) {
                        float pw = Math.min(ui.dp(34), (nameW() - ui.dp(8)) / pages);
                        int pg = (int) ((x - ui.dp(4)) / pw);
                        if (pg >= 0 && pg < pages) page = pg;
                    }
                }
                if (changed) s.edited();
                mode = NONE;
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_CANCEL:
                removeCallbacks(longPress);
                if (changed) s.edited();
                mode = NONE;
                return true;
            default:
                return true;
        }
    }

    private void onLongPress() {
        if (mode != NAME) return;
        longFired = true;
        int row = rowAt(downY);
        if (row >= 0 && row < s.p.channels.size()) {
            haptic();
            Project.Channel ch = s.p.channels.get(row);
            s.select(ch);
            invalidate();
            host.channelMenu(ch);
        }
    }

    private int stepAt(float x) {
        float sx = stepsX();
        if (x < sx) return -1;
        int i = (int) ((x - sx) / cellW());
        int vis = visibleSteps();
        if (i >= vis) return -1;
        int step = page * vis + i;
        return step < s.p.current().steps ? step : -1;
    }

    private void applyPaint(Project.Channel ch, int step) {
        lastStep = step;
        Project.Pattern pt = s.p.current();
        List<Project.Note> notes = pt.notes(ch.id);
        Project.Note n = noteAt(notes, step);
        if (paintAdd && n == null) {
            if (!changed) s.checkpoint();
            changed = true;
            float vel = 0.8f;
            if (!notes.isEmpty()) vel = notes.get(notes.size() - 1).vel; // как у соседей
            notes.add(new Project.Note(step * Project.STEP, s.defaultLen(ch), s.defaultKey(ch), vel));
            audition(ch, s.defaultKey(ch), vel);
            haptic();
        } else if (!paintAdd && n != null) {
            if (!changed) s.checkpoint();
            changed = true;
            notes.remove(n);
            haptic();
        }
        s.rebuild();
        invalidate();
    }

    private void applyVel(Project.Channel ch, int step, float y) {
        Project.Note n = noteAt(s.p.current().notes.get(ch.id), step);
        if (n == null) return;
        float top = headH - scrollY + paintRow * rowH + gap, h = rowH - 2 * gap;
        // зона касания растянута на 2 ряда вверх и вниз — удобнее тянуть
        float v = 1f - (y - (top - h)) / (3 * h);
        v = Math.max(0.05f, Math.min(1f, v));
        if (Math.abs(n.vel - v) > 0.005f) {
            if (!changed) s.checkpoint();
            changed = true;
            n.vel = v;
            invalidate();
        }
    }

    private void audition(Project.Channel ch, int key, float vel) {
        if (s.playing()) return; // во время игры не мешаем
        s.engine.live(ch, key, vel);
        postDelayed(() -> s.engine.live(ch, key, 0f), 180);
    }

    private void haptic() {
        if (s.prefs.vibrate()) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }
}
