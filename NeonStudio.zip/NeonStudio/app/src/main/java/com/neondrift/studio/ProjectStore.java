package com.neondrift.studio;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Проекты на устройстве: по файлу JSON на проект, запись через временный файл (без порчи при сбое). */
final class ProjectStore {
    private ProjectStore() {}

    static final class Info {
        String id, name;
        long edited, created;
        float bpm;
        int key, scale, channels, bars;
    }

    static File dir(Context c) {
        File d = new File(c.getFilesDir(), "projects");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    private static File file(Context c, String id) {
        return new File(dir(c), id.replaceAll("[^A-Za-z0-9_-]", "_") + ".json");
    }

    static void save(Context c, Project p) throws IOException {
        if (p.created == 0) p.created = System.currentTimeMillis();
        p.edited = System.currentTimeMillis();
        saveJson(c, p.id, p.toJson());
    }

    /** JSON снимается в главном потоке, пишется — в любом. */
    static synchronized void saveJson(Context c, String id, String json) throws IOException {
        byte[] data = json.getBytes(StandardCharsets.UTF_8);
        File f = file(c, id), tmp = new File(f.getPath() + ".tmp");
        try (FileOutputStream os = new FileOutputStream(tmp)) {
            os.write(data);
            os.getFD().sync();
        }
        if (!tmp.renameTo(f)) {
            f.delete();
            if (!tmp.renameTo(f)) throw new IOException("не удалось сохранить проект");
        }
    }

    static Project load(Context c, String id) throws IOException {
        File f = file(c, id);
        if (!f.isFile()) throw new IOException("проект не найден");
        try (InputStream in = new FileInputStream(f)) {
            Project p = Project.fromJson(new String(Wav.readAll(in, 64 * 1024 * 1024), StandardCharsets.UTF_8));
            p.id = id;
            return p;
        } catch (IllegalArgumentException e) {
            throw new IOException("файл проекта повреждён");
        }
    }

    static void delete(Context c, String id) {
        file(c, id).delete();
    }

    @SuppressWarnings("unchecked")
    static List<Info> list(Context c) {
        ArrayList<Info> out = new ArrayList<>();
        File[] fs = dir(c).listFiles((d, n) -> n.endsWith(".json"));
        if (fs == null) return out;
        for (File f : fs) {
            try (InputStream in = new FileInputStream(f)) {
                Object o = Json.parse(new String(Wav.readAll(in, 64 * 1024 * 1024), StandardCharsets.UTF_8));
                if (!(o instanceof Map)) continue;
                Map<String, Object> m = (Map<String, Object>) o;
                Info i = new Info();
                i.id = f.getName().substring(0, f.getName().length() - 5);
                i.name = Json.str(m, "name", "Без названия");
                i.edited = (long) Json.num(m, "edited", f.lastModified());
                i.created = (long) Json.num(m, "created", i.edited);
                i.bpm = (float) Json.dbl(m, "bpm", 140);
                i.key = (int) Json.num(m, "key", 0);
                i.scale = (int) Json.num(m, "scale", 1);
                i.channels = Json.list(m, "channels").size();
                long steps = 0;
                for (Object co : Json.list(m, "clips")) {
                    if (co instanceof Map) steps = Math.max(steps, (long) (Json.num((Map<String, Object>) co, "s", 0) + Json.num((Map<String, Object>) co, "l", 0)));
                }
                i.bars = (int) (steps / Project.BAR);
                out.add(i);
            } catch (Exception ignored) {
                // повреждённый файл не мешает остальным
            }
        }
        out.sort((a, b) -> Long.compare(b.edited, a.edited));
        return out;
    }

    /** Свободное имя вида «Название 2». */
    static String uniqueName(Context c, String base) {
        List<Info> all = list(c);
        String name = base;
        for (int i = 2; ; i++) {
            boolean taken = false;
            for (Info x : all) if (x.name.equalsIgnoreCase(name)) taken = true;
            if (!taken) return name;
            name = base + " " + i;
        }
    }

    static void copyStream(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }
}
