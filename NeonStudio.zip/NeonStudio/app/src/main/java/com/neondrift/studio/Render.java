package com.neondrift.studio;

import java.io.IOException;

/** Сведение без проигрывания: свой движок, точная длина песни плюс естественные хвосты. */
final class Render {
    private Render() {}

    interface Sink {
        void write(float[] interleaved, int frames) throws IOException;
    }

    /** f — доля готовности 0…1. Вернуть false — отменить. */
    interface Progress {
        boolean step(float f);
    }

    static final class Spec {
        boolean song = true;     // песня из плейлиста; иначе — текущий паттерн
        int loops = 1;           // повторов паттерна
        int only = -1;           // индекс канала (стем) или −1 — всё
        boolean raw;             // без мастер-лимитера (стемы)
        float tailMax = 6f;      // секунд на затухание реверба и 808
    }

    static final class CancelledException extends IOException {
        CancelledException() {
            super("отменено");
        }
    }

    /** Длина основной части в кадрах (без хвоста). */
    static long length(Project p, Engine.Compiled c, Spec s, int rate) {
        double spt = rate * 60.0 / (p.bpm * Project.PPQ);
        boolean song = s.song && c.sTicks > 0;
        long ticks = song ? c.sTicks : (long) c.pTicks * Math.max(1, s.loops);
        return (long) Math.ceil(ticks * spt);
    }

    /** Возвращает число записанных кадров. */
    static long render(Project p, Engine.Samples src, int rate, Spec s, Sink sink, Progress pr) throws IOException {
        int block = 512;
        Engine e = new Engine(rate, block);
        Engine.Compiled c = e.compile(p, src);
        c.only = s.only;
        e.publish(c);
        e.bpm = p.bpm;
        boolean song = s.song && c.sTicks > 0;
        e.songMode = song;
        e.loop = !song;
        e.rawMaster = s.raw;
        e.metronome = false;
        e.play();
        long main = length(p, c, s, rate);
        long tailMax = (long) (s.tailMax * rate);
        float[] buf = new float[block * 2];
        long done = 0, quiet = 0;
        long minQuiet = rate / 4;
        int reportEvery = rate / 2;
        long nextReport = reportEvery;
        // основная часть
        while (done < main) {
            int n = (int) Math.min(block, main - done);
            e.process(buf, n);
            sink.write(buf, n);
            done += n;
            if (pr != null && done >= nextReport) {
                nextReport += reportEvery;
                if (!pr.step(0.95f * done / (main + rate))) throw new CancelledException();
            }
        }
        // хвост: отпускаем ноты паттерна и ждём тишины
        if (!song) e.stop();
        long tail = 0;
        while (tail < tailMax) {
            e.process(buf, block);
            float peak = e.blockPeak();
            quiet = peak < 2e-4f ? quiet + block : 0;
            if (quiet >= minQuiet && tail > rate / 10) {
                // последний кусок тихий — его не пишем целиком, достаточно короткой паузы
                break;
            }
            sink.write(buf, block);
            tail += block;
            done += block;
        }
        if (pr != null) pr.step(1f);
        return done;
    }
}
