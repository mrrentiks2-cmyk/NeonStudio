package com.neondrift.studio;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

/** Чтение и запись WAV, пересчёт частоты. Без Android. */
final class Wav {
    private Wav() {}

    /** Прочитанный звук: каналы и частота. */
    static final class Audio {
        final float[][] ch;
        final int rate;

        Audio(float[][] ch, int rate) {
            this.ch = ch;
            this.rate = rate;
        }

        int frames() {
            return ch.length == 0 ? 0 : ch[0].length;
        }
    }

    static byte[] readAll(InputStream in, int limit) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) {
            bos.write(buf, 0, n);
            if (bos.size() > limit) throw new IOException("файл слишком большой");
        }
        return bos.toByteArray();
    }

    private static int le16(byte[] b, int o) {
        return (b[o] & 255) | ((b[o + 1] & 255) << 8);
    }

    private static int le32(byte[] b, int o) {
        return (b[o] & 255) | ((b[o + 1] & 255) << 8) | ((b[o + 2] & 255) << 16) | ((b[o + 3] & 255) << 24);
    }

    static boolean isWav(byte[] b) {
        return b.length >= 12 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F' && b[8] == 'W' && b[9] == 'A' && b[10] == 'V' && b[11] == 'E';
    }

    /** Разобрать WAV: PCM 8/16/24/32 бит, float 32/64, WAVE_FORMAT_EXTENSIBLE. */
    static Audio decode(byte[] b) throws IOException {
        if (!isWav(b)) throw new IOException("не WAV");
        int pos = 12, fmt = -1, channels = 0, rate = 0, bits = 0, dataOff = -1, dataLen = 0;
        while (pos + 8 <= b.length) {
            String id = new String(b, pos, 4, java.nio.charset.StandardCharsets.US_ASCII);
            int len = le32(b, pos + 4);
            int body = pos + 8;
            if (len < 0 || body + len > b.length) len = b.length - body; // обрезанный файл
            if (id.equals("fmt ") && len >= 16) {
                fmt = le16(b, body);
                channels = le16(b, body + 2);
                rate = le32(b, body + 4);
                bits = le16(b, body + 14);
                if (fmt == 0xFFFE && len >= 26) fmt = le16(b, body + 24);
            } else if (id.equals("data")) {
                dataOff = body;
                dataLen = len;
                break;
            }
            pos = body + len + (len & 1);
        }
        if (fmt < 0 || dataOff < 0 || channels <= 0 || rate <= 0) throw new IOException("повреждённый WAV");
        if (fmt != 1 && fmt != 3) throw new IOException("сжатый WAV не поддерживается");
        int bps = bits / 8;
        if (bps <= 0) throw new IOException("неизвестная разрядность");
        int frames = dataLen / (bps * channels);
        float[][] out = new float[channels][frames];
        int o = dataOff;
        for (int i = 0; i < frames; i++) {
            for (int c = 0; c < channels; c++) {
                float v;
                if (fmt == 3) {
                    if (bps == 4) v = Float.intBitsToFloat(le32(b, o));
                    else if (bps == 8) {
                        long lo = le32(b, o) & 0xFFFFFFFFL, hi = le32(b, o + 4) & 0xFFFFFFFFL;
                        v = (float) Double.longBitsToDouble(lo | (hi << 32));
                    } else throw new IOException("неизвестный формат float");
                } else {
                    switch (bps) {
                        case 1: v = ((b[o] & 255) - 128) / 128f; break;
                        case 2: v = (short) le16(b, o) / 32768f; break;
                        case 3: v = (((b[o] & 255) | ((b[o + 1] & 255) << 8) | (b[o + 2] << 16))) / 8388608f; break;
                        case 4: v = le32(b, o) / 2147483648f; break;
                        default: throw new IOException("неизвестная разрядность");
                    }
                }
                if (v != v || Float.isInfinite(v)) v = 0;
                out[c][i] = v;
                o += bps;
            }
        }
        return new Audio(out, rate);
    }

    // ================================================================== запись

    /** Запись WAV в файл кусками; заголовок дописывается при закрытии. */
    static final class Writer implements AutoCloseable {
        private final RandomAccessFile f;
        private final int bits, rate;
        private long frames;
        private byte[] tmp = new byte[0];

        Writer(File file, int rate, int bits) throws IOException {
            this.rate = rate;
            this.bits = bits == 24 ? 24 : bits == 32 ? 32 : 16;
            f = new RandomAccessFile(file, "rw");
            f.setLength(0);
            f.write(new byte[44]);
        }

        /** interleaved — стерео L R L R…; n — кадров. */
        void write(float[] interleaved, int n) throws IOException {
            int bps = bits / 8, need = n * 2 * bps;
            if (tmp.length < need) tmp = new byte[need];
            int o = 0;
            for (int i = 0; i < n * 2; i++) {
                float v = Math.max(-1f, Math.min(1f, interleaved[i]));
                if (bits == 32) {
                    int x = Float.floatToIntBits(v);
                    tmp[o++] = (byte) x;
                    tmp[o++] = (byte) (x >> 8);
                    tmp[o++] = (byte) (x >> 16);
                    tmp[o++] = (byte) (x >> 24);
                } else if (bits == 24) {
                    int x = Math.round(v * 8388607f);
                    tmp[o++] = (byte) x;
                    tmp[o++] = (byte) (x >> 8);
                    tmp[o++] = (byte) (x >> 16);
                } else {
                    int x = Math.round(v * 32767f);
                    tmp[o++] = (byte) x;
                    tmp[o++] = (byte) (x >> 8);
                }
            }
            f.write(tmp, 0, need);
            frames += n;
        }

        @Override
        public void close() throws IOException {
            int bps = bits / 8;
            long data = frames * 2 * bps;
            byte[] h = header(rate, bits, 2, data);
            f.seek(0);
            f.write(h);
            f.close();
        }
    }

    static byte[] header(int rate, int bits, int channels, long dataLen) {
        byte[] h = new byte[44];
        int fmt = bits == 32 ? 3 : 1, bps = bits / 8;
        put(h, 0, "RIFF");
        put32(h, 4, (int) (36 + dataLen));
        put(h, 8, "WAVE");
        put(h, 12, "fmt ");
        put32(h, 16, 16);
        h[20] = (byte) fmt;
        h[22] = (byte) channels;
        put32(h, 24, rate);
        put32(h, 28, rate * channels * bps);
        h[32] = (byte) (channels * bps);
        h[34] = (byte) bits;
        put(h, 36, "data");
        put32(h, 40, (int) dataLen);
        return h;
    }

    private static void put(byte[] h, int o, String s) {
        for (int i = 0; i < 4; i++) h[o + i] = (byte) s.charAt(i);
    }

    private static void put32(byte[] h, int o, int v) {
        h[o] = (byte) v;
        h[o + 1] = (byte) (v >> 8);
        h[o + 2] = (byte) (v >> 16);
        h[o + 3] = (byte) (v >> 24);
    }

    // ================================================================== частота

    /** Пересчёт частоты: при понижении — сначала срез высоких (без «звона»), затем кубическая интерполяция. */
    static float[] resample(float[] in, int from, int to) {
        if (from == to || in.length == 0) return in;
        float[] src = in;
        if (to < from) {
            src = in.clone();
            for (int pass = 0; pass < 2; pass++) {
                Dsp.Svf f = new Dsp.Svf();
                f.set(to * 0.45f, 0.0f, from);
                for (int i = 0; i < src.length; i++) src[i] = f.process(src[i]);
                // второй проход назад — без сдвига фазы
                f.reset();
                for (int i = src.length - 1; i >= 0; i--) src[i] = f.process(src[i]);
            }
        }
        double ratio = from / (double) to;
        int n = (int) Math.max(1, Math.floor(src.length / ratio));
        float[] out = new float[n];
        int last = src.length - 1;
        for (int i = 0; i < n; i++) {
            double p = i * ratio;
            int k = (int) p;
            float t = (float) (p - k);
            float y0 = src[Math.max(0, k - 1)], y1 = src[Math.min(last, k)], y2 = src[Math.min(last, k + 1)], y3 = src[Math.min(last, k + 2)];
            float c1 = 0.5f * (y2 - y0), c2 = y0 - 2.5f * y1 + 2f * y2 - 0.5f * y3, c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
            out[i] = ((c3 * t + c2) * t + c1) * t + y1;
        }
        return out;
    }

    /** Звук в образец для движка: моно/стерео, нужная частота, не длиннее maxSec. */
    static Sample toSample(Audio a, String id, String name, int rate, float maxSec) {
        int frames = a.frames();
        int limit = (int) (maxSec * a.rate);
        float[] l = a.ch[0], r = a.ch.length > 1 ? a.ch[1] : null;
        if (frames > limit) {
            l = java.util.Arrays.copyOf(l, limit);
            if (r != null) r = java.util.Arrays.copyOf(r, limit);
        }
        // почти одинаковые каналы — храним как моно (вдвое меньше памяти)
        if (r != null) {
            float diff = 0;
            for (int i = 0; i < l.length; i += 7) diff = Math.max(diff, Math.abs(l[i] - r[i]));
            if (diff < 1e-4f) r = null;
        }
        l = resample(l, a.rate, rate);
        if (r != null) {
            r = resample(r, a.rate, rate);
            int n = Math.min(l.length, r.length);
            if (l.length != n) l = java.util.Arrays.copyOf(l, n);
            if (r.length != n) r = java.util.Arrays.copyOf(r, n);
        }
        return new Sample(id, name, l, r, rate);
    }
}
