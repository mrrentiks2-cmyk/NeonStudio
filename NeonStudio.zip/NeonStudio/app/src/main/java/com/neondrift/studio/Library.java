package com.neondrift.studio;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Библиотека звуков: паки из архивов, отдельные файлы и папки. Файлы лежат как есть,
 * расшифровываются при первом использовании и держатся в памяти, пока хватает места.
 */
final class Library {
    private Library() {}

    static final String PREFIX = "lib:";
    static final String[] AUDIO = {".wav", ".wave", ".mp3", ".ogg", ".flac", ".m4a", ".aac", ".opus", ".aif", ".aiff"};
    static final String[] CATEGORIES = {"Бочки", "808", "Малые", "Клэпы", "Хэты", "Перкуссия", "Ковбелл", "Тарелки", "Вокал",
            "Петли", "Мелодии", "Эффекты", "MIDI", "Другое"};

    static final class Entry {
        final String path;      // относительно папки библиотеки
        final String name, pack, category;
        final boolean midi;
        final float bpm;

        Entry(String path, String name, String pack, String category, boolean midi, float bpm) {
            this.path = path;
            this.name = name;
            this.pack = pack;
            this.category = category;
            this.midi = midi;
            this.bpm = bpm;
        }

        String ref() {
            return PREFIX + path;
        }
    }

    static File root(Context c) {
        File d = new File(c.getFilesDir(), "library");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    // ================================================================== список

    private static List<Entry> index;

    static synchronized List<Entry> entries(Context c) {
        if (index != null) return index;
        ArrayList<Entry> out = new ArrayList<>();
        File r = root(c);
        File[] packs = r.listFiles(File::isDirectory);
        if (packs != null) {
            for (File p : packs) scan(r, p, p.getName(), out);
        }
        out.sort((a, b) -> {
            int x = a.pack.compareToIgnoreCase(b.pack);
            return x != 0 ? x : a.path.compareToIgnoreCase(b.path);
        });
        index = out;
        return out;
    }

    static synchronized void invalidate() {
        index = null;
    }

    private static void scan(File root, File dir, String pack, List<Entry> out) {
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            if (f.isDirectory()) {
                scan(root, f, pack, out);
                continue;
            }
            String n = f.getName(), low = n.toLowerCase(Locale.ROOT);
            boolean midi = low.endsWith(".mid") || low.endsWith(".midi");
            if (!midi && !audio(low)) continue;
            String rel = root.toURI().relativize(f.toURI()).getPath();
            String title = n.contains(".") ? n.substring(0, n.lastIndexOf('.')) : n;
            out.add(new Entry(rel, title, pack, midi ? "MIDI" : category(rel), midi, bpm(n)));
        }
    }

    static boolean audio(String lowName) {
        for (String e : AUDIO) if (lowName.endsWith(e)) return true;
        return false;
    }

    static List<String> packs(Context c) {
        ArrayList<String> out = new ArrayList<>();
        for (Entry e : entries(c)) if (!out.contains(e.pack)) out.add(e.pack);
        return out;
    }

    /** Категория по имени файла и папкам (английские и русские слова). */
    static String category(String path) {
        String s = path.toLowerCase(Locale.ROOT);
        if (s.matches(".*(loop|луп|петл|\\d{2,3}\\s*bpm).*")) return "Петли";
        if (s.matches(".*(808|sub|bass|бас).*")) return "808";
        if (s.matches(".*(kick|kik|бочк|кик|bd[_ -]).*")) return "Бочки";
        if (s.matches(".*(snare|снейр|снэр|малый|sd[_ -]).*")) return "Малые";
        if (s.matches(".*(clap|клэп|клап|хлоп|snap|щелч).*")) return "Клэпы";
        if (s.matches(".*(hat|hh|хэт|хет|хай).*")) return "Хэты";
        if (s.matches(".*(cowbell|ковбел|bell|колокол).*")) return "Ковбелл";
        if (s.matches(".*(crash|ride|cymbal|тарел).*")) return "Тарелки";
        if (s.matches(".*(perc|перк|conga|bongo|shaker|шейкер|tamb|rim|tom|клав|clave|block).*")) return "Перкуссия";
        if (s.matches(".*(vox|vocal|voice|вокал|голос|chant|acapella).*")) return "Вокал";
        if (s.matches(".*(melod|мелод|keys|piano|synth|lead|chord|аккорд).*")) return "Мелодии";
        if (s.matches(".*(fx|riser|impact|sweep|transition|эффект|noise|vinyl).*")) return "Эффекты";
        return "Другое";
    }

    private static final Pattern BPM = Pattern.compile("(\\d{2,3})\\s*bpm", Pattern.CASE_INSENSITIVE);

    static float bpm(String name) {
        Matcher m = BPM.matcher(name);
        if (m.find()) {
            float v = Float.parseFloat(m.group(1));
            if (v >= 50 && v <= 220) return v;
        }
        return 0;
    }

    // ================================================================== импорт

    static final class Report {
        int files, skipped;
        String pack;
        final List<String> problems = new ArrayList<>();
    }

    interface Progress {
        void onFile(String name, int count);
    }

    static String displayName(Context c, Uri uri) {
        try (Cursor cur = c.getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cur != null && cur.moveToFirst()) {
                String n = cur.getString(0);
                if (n != null) return n;
            }
        } catch (Exception ignored) {
        }
        String p = uri.getLastPathSegment();
        return p == null ? "Пак" : p.substring(p.lastIndexOf('/') + 1);
    }

    /** Имя папки пака: без запрещённых символов и не занятое. */
    static File newPack(Context c, String name) {
        String base = name.replaceAll("(?i)\\.(zip|rar|7z)$", "").replaceAll("[\\\\/:*?\"<>|]+", " ").trim();
        if (base.isEmpty()) base = "Пак";
        if (base.length() > 60) base = base.substring(0, 60).trim();
        File d = new File(root(c), base);
        for (int i = 2; d.exists(); i++) d = new File(root(c), base + " " + i);
        d.mkdirs();
        return d;
    }

    /** Распаковать ZIP со звуками и MIDI (в том числе вложенные архивы). */
    static Report importZip(Context c, Uri uri, Progress progress) throws IOException {
        String name = displayName(c, uri);
        byte[] magic = new byte[4];
        try (InputStream in = c.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IOException("файл не открылся");
            if (in.read(magic) < 4) throw new IOException("файл пуст");
        }
        if (magic[0] == 'R' && magic[1] == 'a' && magic[2] == 'r' || magic[0] == '7' && magic[1] == 'z') {
            throw new IOException("RAR и 7z Android не открывает без сторонних программ. Пересохраните архив в ZIP (например, в приложении «Файлы» или на компьютере).");
        }
        if (magic[0] != 'P' || magic[1] != 'K') throw new IOException("это не ZIP-архив");
        // сначала UTF-8; если имена не читаются — архив из русской Windows (CP866)
        java.nio.charset.Charset[] sets = {java.nio.charset.StandardCharsets.UTF_8, cp866()};
        IOException last = null;
        for (java.nio.charset.Charset cs : sets) {
            if (cs == null) continue;
            Report rep = new Report();
            File pack = newPack(c, name);
            rep.pack = pack.getName();
            try (InputStream in = c.getContentResolver().openInputStream(uri)) {
                if (in == null) throw new IOException("файл не открылся");
                unzip(new ZipInputStream(in, cs), cs, pack, "", rep, progress, 0);
            } catch (IllegalArgumentException e) {
                deleteTree(pack);
                last = new IOException("имена файлов в архиве в неизвестной кодировке");
                continue;
            } catch (IOException e) {
                deleteTree(pack);
                throw e;
            }
            if (rep.files == 0) {
                deleteTree(pack);
                throw new IOException("в архиве нет звуков (WAV, MP3, OGG, FLAC, M4A) и MIDI");
            }
            invalidate();
            return rep;
        }
        throw last != null ? last : new IOException("архив не читается");
    }

    private static java.nio.charset.Charset cp866() {
        try {
            return java.nio.charset.Charset.forName("IBM866");
        } catch (Exception e) {
            return null;
        }
    }

    private static void unzip(ZipInputStream zin, java.nio.charset.Charset cs, File pack, String prefix, Report rep, Progress progress, int depth) throws IOException {
        ZipEntry e;
        byte[] buf = new byte[64 * 1024];
        while ((e = zin.getNextEntry()) != null) {
            if (e.isDirectory()) continue;
            String path = prefix + e.getName().replace('\\', '/');
            String file = path.substring(path.lastIndexOf('/') + 1);
            String low = file.toLowerCase(Locale.ROOT);
            if (path.contains("__MACOSX") || file.startsWith(".") || file.isEmpty()) continue;
            if (low.endsWith(".zip") && depth < 2) {
                // вложенный архив — распаковать рядом, в свою папку
                String sub = path.substring(0, path.length() - 4) + "/";
                unzip(new ZipInputStream(new NoClose(zin), cs), cs, pack, sub, rep, progress, depth + 1);
                continue;
            }
            boolean midi = low.endsWith(".mid") || low.endsWith(".midi");
            if (!midi && !audio(low)) {
                rep.skipped++;
                continue;
            }
            File out = safe(pack, path);
            if (out == null) {
                rep.skipped++;
                continue;
            }
            out.getParentFile().mkdirs();
            long total = 0;
            try (OutputStream os = new FileOutputStream(out)) {
                int n;
                while ((n = zin.read(buf)) > 0) {
                    total += n;
                    if (total > 300L * 1024 * 1024) throw new IOException("файл " + file + " больше 300 МБ");
                    os.write(buf, 0, n);
                }
            }
            rep.files++;
            if (progress != null) progress.onFile(file, rep.files);
        }
    }

    /** Путь внутри пака без выхода наружу («../»). */
    static File safe(File pack, String rel) {
        StringBuilder sb = new StringBuilder();
        for (String part : rel.split("/")) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) continue;
            String clean = part.replaceAll("[\\\\:*?\"<>|]+", "_");
            if (clean.length() > 100) clean = clean.substring(0, 100);
            if (sb.length() > 0) sb.append('/');
            sb.append(clean);
        }
        if (sb.length() == 0) return null;
        File f = new File(pack, sb.toString());
        try {
            if (!f.getCanonicalPath().startsWith(pack.getCanonicalPath() + File.separator)) return null;
        } catch (IOException ex) {
            return null;
        }
        return f;
    }

    /** Отдельные файлы — в пак «Мои звуки». */
    static Report importFiles(Context c, List<Uri> uris, Progress progress) throws IOException {
        Report rep = new Report();
        File pack = new File(root(c), "Мои звуки");
        pack.mkdirs();
        rep.pack = pack.getName();
        for (Uri u : uris) {
            String name = displayName(c, u);
            String low = name.toLowerCase(Locale.ROOT);
            if (low.endsWith(".zip")) {
                Report r = importZip(c, u, progress);
                rep.files += r.files;
                rep.pack = r.pack;
                continue;
            }
            if (!low.contains(".") || !(audio(low) || low.endsWith(".mid") || low.endsWith(".midi"))) {
                // у файлов из мессенджеров часто нет расширения — смотрим на содержимое
                String ext = sniff(c, u);
                if (ext != null && !low.endsWith(ext)) {
                    if (ext.equals(".zip")) {
                        Report r = importZip(c, u, progress);
                        rep.files += r.files;
                        rep.pack = r.pack;
                        continue;
                    }
                    name = name + ext;
                    low = name.toLowerCase(Locale.ROOT);
                }
            }
            boolean midi = low.endsWith(".mid") || low.endsWith(".midi");
            if (!midi && !audio(low)) {
                rep.skipped++;
                continue;
            }
            File out = safe(pack, name);
            if (out == null) continue;
            for (int i = 2; out.exists(); i++) {
                String b = name.contains(".") ? name.substring(0, name.lastIndexOf('.')) : name, ext = name.contains(".") ? name.substring(name.lastIndexOf('.')) : "";
                out = safe(pack, b + " " + i + ext);
            }
            copy(c.getContentResolver(), u, out);
            rep.files++;
            if (progress != null) progress.onFile(name, rep.files);
        }
        invalidate();
        return rep;
    }

    /** Тип по первым байтам: .wav, .mp3, .ogg, .flac, .m4a, .mid, .zip или null. */
    static String sniff(Context c, Uri u) {
        byte[] b = new byte[12];
        int n;
        try (InputStream in = c.getContentResolver().openInputStream(u)) {
            if (in == null) return null;
            n = in.read(b);
        } catch (IOException e) {
            return null;
        }
        if (n < 4) return null;
        if (b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F') return ".wav";
        if (b[0] == 'I' && b[1] == 'D' && b[2] == '3' || (b[0] & 0xFF) == 0xFF && (b[1] & 0xE0) == 0xE0) return ".mp3";
        if (b[0] == 'O' && b[1] == 'g' && b[2] == 'g' && b[3] == 'S') return ".ogg";
        if (b[0] == 'f' && b[1] == 'L' && b[2] == 'a' && b[3] == 'C') return ".flac";
        if (b[0] == 'M' && b[1] == 'T' && b[2] == 'h' && b[3] == 'd') return ".mid";
        if (b[0] == 'P' && b[1] == 'K') return ".zip";
        if (n >= 8 && b[4] == 'f' && b[5] == 't' && b[6] == 'y' && b[7] == 'p') return ".m4a";
        return null;
    }

    /** Папка целиком (через выбор папки в системе). */
    static Report importTree(Context c, Uri tree, Progress progress) throws IOException {
        Report rep = new Report();
        String docId = DocumentsContract.getTreeDocumentId(tree);
        String name = docId.contains(":") ? docId.substring(docId.lastIndexOf(':') + 1) : docId;
        name = name.substring(name.lastIndexOf('/') + 1);
        File pack = newPack(c, name.isEmpty() ? "Папка" : name);
        rep.pack = pack.getName();
        walk(c, tree, docId, pack, "", rep, progress, 0);
        if (rep.files == 0) {
            deleteTree(pack);
            throw new IOException("в папке нет звуков и MIDI");
        }
        invalidate();
        return rep;
    }

    private static void walk(Context c, Uri tree, String docId, File pack, String prefix, Report rep, Progress progress, int depth) throws IOException {
        if (depth > 6) return;
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId);
        ArrayList<String[]> items = new ArrayList<>();
        try (Cursor cur = c.getContentResolver().query(children, new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME, DocumentsContract.Document.COLUMN_MIME_TYPE}, null, null, null)) {
            while (cur != null && cur.moveToNext()) items.add(new String[]{cur.getString(0), cur.getString(1), cur.getString(2)});
        }
        for (String[] it : items) {
            String nm = it[1] == null ? "" : it[1];
            if (DocumentsContract.Document.MIME_TYPE_DIR.equals(it[2])) {
                walk(c, tree, it[0], pack, prefix + nm + "/", rep, progress, depth + 1);
                continue;
            }
            String low = nm.toLowerCase(Locale.ROOT);
            if (!(audio(low) || low.endsWith(".mid") || low.endsWith(".midi"))) continue;
            File out = safe(pack, prefix + nm);
            if (out == null) continue;
            out.getParentFile().mkdirs();
            copy(c.getContentResolver(), DocumentsContract.buildDocumentUriUsingTree(tree, it[0]), out);
            rep.files++;
            if (progress != null) progress.onFile(nm, rep.files);
        }
    }

    private static void copy(ContentResolver cr, Uri u, File out) throws IOException {
        try (InputStream in = cr.openInputStream(u); OutputStream os = new FileOutputStream(out)) {
            if (in == null) throw new IOException("файл не открылся");
            byte[] buf = new byte[64 * 1024];
            int n;
            long total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 300L * 1024 * 1024) throw new IOException("файл больше 300 МБ");
                os.write(buf, 0, n);
            }
        }
    }

    static void deletePack(Context c, String pack) {
        File d = new File(root(c), pack);
        if (d.getParentFile() != null && d.getParentFile().equals(root(c))) deleteTree(d);
        synchronized (Library.class) {
            cache.clear();
            bytes = 0;
        }
        invalidate();
    }

    static void deleteTree(File f) {
        File[] ch = f.listFiles();
        if (ch != null) for (File x : ch) deleteTree(x);
        f.delete();
    }

    // ================================================================== загрузка звука

    /** Дольше — обрезается: 4 минуты стерео уже ~90 МБ памяти. */
    static final float MAX_SEC = 240;
    private static final LinkedHashMap<String, Sample> cache = new LinkedHashMap<>(32, 0.75f, true);
    private static long bytes;
    private static final long BUDGET = Math.min(Runtime.getRuntime().maxMemory() / 3, 180L * 1024 * 1024);

    static File file(Context c, String ref) {
        String rel = ref.startsWith(PREFIX) ? ref.substring(PREFIX.length()) : ref;
        File f = new File(root(c), rel);
        try {
            if (!f.getCanonicalPath().startsWith(root(c).getCanonicalPath())) return null;
        } catch (IOException e) {
            return null;
        }
        return f;
    }

    /** Только из памяти — без чтения файла. */
    static synchronized Sample cachedOnly(String ref, int rate) {
        return cache.get(ref + "@" + rate);
    }

    /** Звук по ссылке (lib:…), в частоте rate. Долго — вызывать не из главного потока. */
    static Sample load(Context c, String ref, int rate) {
        synchronized (Library.class) {
            Sample s = cache.get(ref + "@" + rate);
            if (s != null) return s;
        }
        File f = file(c, ref);
        if (f == null || !f.isFile()) return null;
        try {
            String low = f.getName().toLowerCase(Locale.ROOT);
            Wav.Audio a;
            byte[] head = new byte[12];
            try (InputStream in = new FileInputStream(f)) {
                int n = in.read(head);
                if (n < 12) head = new byte[0];
            }
            if (Wav.isWav(head) || low.endsWith(".wav") && Wav.isWav(head)) {
                try (InputStream in = new FileInputStream(f)) {
                    a = Wav.decode(Wav.readAll(in, 400 * 1024 * 1024));
                } catch (IOException e) {
                    a = Decoder.decode(f.getPath(), MAX_SEC);
                }
            } else {
                a = Decoder.decode(f.getPath(), MAX_SEC);
            }
            String title = f.getName().contains(".") ? f.getName().substring(0, f.getName().lastIndexOf('.')) : f.getName();
            Sample s = Wav.toSample(a, ref, title, rate, MAX_SEC);
            s.category = category(ref);
            synchronized (Library.class) {
                cache.put(ref + "@" + rate, s);
                bytes += size(s);
                // освобождаем самые старые, если не помещаемся
                java.util.Iterator<Map.Entry<String, Sample>> it = cache.entrySet().iterator();
                while (bytes > BUDGET && it.hasNext()) {
                    Map.Entry<String, Sample> e = it.next();
                    if (e.getValue() == s) continue;
                    bytes -= size(e.getValue());
                    it.remove();
                }
            }
            return s;
        } catch (IOException | OutOfMemoryError e) {
            return null;
        }
    }

    private static long size(Sample s) {
        return (long) s.frames() * 4 * (s.stereo() ? 2 : 1);
    }

    static Midi.Result midi(Context c, String ref) throws IOException {
        File f = file(c, ref);
        if (f == null) throw new IOException("нет файла");
        try (InputStream in = new FileInputStream(f)) {
            return Midi.read(Wav.readAll(in, 8 * 1024 * 1024));
        }
    }

    static List<Entry> filter(List<Entry> all, String pack, String category, String query) {
        if (pack == null && category == null && (query == null || query.isEmpty())) return all;
        ArrayList<Entry> out = new ArrayList<>();
        String q = query == null ? "" : query.toLowerCase(Locale.ROOT).trim();
        for (Entry e : all) {
            if (pack != null && !pack.equals(e.pack)) continue;
            if (category != null && !category.equals(e.category)) continue;
            if (!q.isEmpty() && !e.path.toLowerCase(Locale.ROOT).contains(q)) continue;
            out.add(e);
        }
        return out;
    }

    static List<Entry> none() {
        return Collections.emptyList();
    }

    /** ZipInputStream закрывает внешний поток при закрытии — вложенному архиву этого нельзя. */
    private static final class NoClose extends java.io.FilterInputStream {
        NoClose(InputStream in) {
            super(in);
        }

        @Override
        public void close() {
        }
    }
}
