package com.neondrift.studio;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Process;

/** Вывод звука: AudioTrack в режиме низкой задержки и отдельный поток с высоким приоритетом. */
final class AudioOut {
    final Engine engine;
    final int rate, block;
    private AudioTrack track;
    private Thread thread;
    private volatile boolean running;
    int bufferFrames;

    AudioOut(Engine engine, int rate, int block) {
        this.engine = engine;
        this.rate = rate;
        this.block = block;
    }

    static int nativeRate(Context c) {
        try {
            String s = c.getSystemService(AudioManager.class).getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE);
            int r = s == null ? 48000 : Integer.parseInt(s);
            return r >= 22050 && r <= 96000 ? r : 48000;
        } catch (Exception e) {
            return 48000;
        }
    }

    static int nativeBlock(Context c) {
        try {
            String s = c.getSystemService(AudioManager.class).getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER);
            int b = s == null ? 256 : Integer.parseInt(s);
            return b >= 64 && b <= 2048 ? b : 256;
        } catch (Exception e) {
            return 256;
        }
    }

    synchronized void start() {
        if (running) return;
        int min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT);
        // 4 блока запаса: без заиканий при нагрузке, задержка ~20–40 мс
        int bytes = Math.max(min, block * 2 * 4 * 4);
        track = new AudioTrack.Builder()
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                        .setSampleRate(rate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(bytes)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build();
        bufferFrames = bytes / 8;
        running = true;
        track.play();
        AudioTrack t = track;
        thread = new Thread(() -> {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO);
            float[] buf = new float[block * 2];
            while (running) {
                try {
                    engine.process(buf, block);
                } catch (RuntimeException e) {
                    // ошибка в одном блоке не должна оборвать звук насовсем
                    java.util.Arrays.fill(buf, 0f);
                }
                int w = t.write(buf, 0, block * 2, AudioTrack.WRITE_BLOCKING);
                if (w < 0) break;
            }
        }, "neon-audio");
        thread.start();
    }

    synchronized void stop() {
        if (!running) return;
        running = false;
        try {
            thread.join(500);
        } catch (InterruptedException ignored) {
        }
        try {
            track.pause();
            track.flush();
            track.release();
        } catch (Exception ignored) {
        }
        track = null;
    }

    boolean running() {
        return running;
    }

    /** Примерная задержка звука в миллисекундах. */
    int latencyMs() {
        return Math.round((bufferFrames + block) * 1000f / rate);
    }
}
