package com.neondrift.studio;

import java.util.Random;

/** Стартовые проекты: готовая песня по стилю или пустой набор каналов. */
final class Templates {
    private Templates() {}

    static final String[] NAMES = {"Drift Phonk", "Memphis Phonk", "Бразильский фонк", "Funk", "Пустой проект"};
    static final String[] SUBS = {"150 BPM · ковбелл, злой 808, дроби хэтов", "132 BPM · тёмный колокол, свинг, винил",
            "130 BPM · тамборзан, перкуссия, ковбелл", "108 BPM · слэп-бас, электропиано, призрачные ноты", "Барабаны, ковбелл и 808 — без нот"};
    private static final int[] KEYS = {1, 6, 8, 3, 10, 5}; // C#, F#, G#, D#, A#, F — любимые тональности фонка

    static Project make(int i, long seed) {
        Project p = new Project();
        p.created = p.edited = System.currentTimeMillis();
        if (i >= Generator.STYLES.length) {
            p.name = "Новый бит";
            for (String role : new String[]{"kick", "snare", "clap", "hat", "ohat", "cowbell", "808"}) p.channels.add(Presets.make(role));
            Project.Pattern pt = p.current();
            pt.name = "Паттерн 1";
            pt.steps = 32;
            return p;
        }
        Random r = new Random(seed);
        p.name = NAMES[i];
        p.key = i == Generator.FUNK ? new int[]{2, 4, 9}[r.nextInt(3)] : KEYS[r.nextInt(KEYS.length)];
        Generator.Options o = new Generator.Options();
        o.seed = seed;
        o.applyStyle = true;
        o.chords = i == Generator.MEMPHIS;
        Project.Pattern main = p.current();
        main.name = "Бит";
        main.color = 0xFFFF2D95;
        Generator.generate(p, main, i, o);
        // вариант: другие барабаны, та же мелодия
        Project.Pattern alt = main.copy();
        alt.name = "Бит 2";
        alt.color = 0xFF00E5FF;
        p.patterns.add(alt);
        Generator.Options d = new Generator.Options();
        d.seed = seed + 17;
        d.melody = false;
        d.bass = false;
        Generator.generate(p, alt, i, d);
        // вступление: только мелодия, аккорды и винил
        Project.Pattern intro = main.copy();
        intro.name = "Вступление";
        intro.color = 0xFF9D6BFF;
        for (Project.Channel c : p.channels) {
            boolean keep = c.role.equals("cowbell") || c.role.equals("bell") || c.role.equals("chords") || c.role.equals("vinyl")
                    || c.role.equals("keys") || c.role.equals("lead");
            if (!keep) intro.notes.remove(c.id);
        }
        p.patterns.add(0, intro);
        int bar = Project.BAR, len = main.steps;
        p.clips.add(new Project.Clip(intro.id, 0, 0, 4 * bar));
        p.clips.add(new Project.Clip(main.id, 0, 4 * bar, 8 * bar));
        p.clips.add(new Project.Clip(alt.id, 0, 12 * bar, 4 * bar));
        p.clips.add(new Project.Clip(main.id, 0, 16 * bar, 8 * bar));
        if (len <= 0) len = 32;
        p.current = main.id;
        return p;
    }
}
