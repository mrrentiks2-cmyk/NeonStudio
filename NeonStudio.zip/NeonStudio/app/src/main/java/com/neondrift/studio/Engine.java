package com.neondrift.studio;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Звуковой движок. Поток звука вызывает process(); интерфейс публикует «скомпилированную» песню
 * (массивы событий) и меняет параметры каналов — без блокировок в звуковом потоке.
 */
final class Engine {
    interface Samples {
        Sample get(String ref);
    }

    /** Состояние канала в движке: буферы и эффекты. */
    static final class Strip {
        final Project.Channel ch;
        final float[] l, r;
        final Fx.Crusher crush = new Fx.Crusher();
        final Dsp.Svf fl = new Dsp.Svf(), fr = new Dsp.Svf();
        final Fx.Eq3 eq = new Fx.Eq3();
        final Fx.Comp comp = new Fx.Comp();
        float duckEnv;
        int duckAt = -1;
        volatile float peak;
        float volSm = -1, panSm;

        Strip(Project.Channel ch, int block) {
            this.ch = ch;
            l = new float[block];
            r = new float[block];
        }
    }

    /** Песня, готовая для звукового потока: только массивы. */
    static final class Compiled {
        Project project;
        Project.Channel[] ch = new Project.Channel[0];
        Strip[] strips = new Strip[0];
        Sample[] samples = new Sample[0];
        float[][] marks = new float[0][];
        int[] pTick = new int[0], pCh = new int[0], pKey = new int[0], pLen = new int[0];
        float[] pVel = new float[0];
        boolean[] pSlide = new boolean[0];
        int pN, pTicks = Project.BAR * Project.STEP;
        int[] sTick = new int[0], sCh = new int[0], sKey = new int[0], sLen = new int[0];
        float[] sVel = new float[0];
        boolean[] sSlide = new boolean[0];
        int sN, sTicks;
        int only = -1;           // играть только этот канал (стемы)
    }

    final float sr;
    final int block;
    private final Map<String, Strip> stripMap = new HashMap<>();
    volatile Compiled song;
    volatile boolean playing, songMode, metronome, loop = true;
    volatile float bpm = 140f;
    volatile double position;            // тики, для интерфейса
    private double tick;
    private volatile double seekTo = -1;
    private volatile boolean stopRequest;

    private final Voice[] voices = new Voice[96];
    private long stamp;
    private final float[] busRevL, busRevR, busDelL, busDelR, mL, mR;
    private final Fx.Reverb reverb;
    private final Fx.Delay delay;
    private final Fx.Comp glue = new Fx.Comp();
    private final Fx.Limiter limiter;
    volatile float peakL, peakR;
    private float lastPeakL, lastPeakR;
    volatile boolean clipped;
    volatile boolean finished;           // песня доиграла до конца (без повтора)
    volatile boolean rawMaster;          // без склейки и лимитера (стемы)
    private volatile boolean panicRequest;

    // метроном
    private double clickPh;
    private float clickEnv, clickHz;

    // предпрослушивание звуков из библиотеки
    private final Project.Channel previewCh = new Project.Channel();
    private Strip previewStrip;
    private volatile Sample previewReq;
    private volatile boolean previewStop;

    // живые ноты от пэдов и клавиатуры: однонаправленная очередь без блокировок
    private static final int Q = 512;
    private final Project.Channel[] qCh = new Project.Channel[Q];
    private final int[] qKey = new int[Q];
    private final float[] qVel = new float[Q];
    private volatile int qHead, qTail;

    Engine(float sampleRate, int maxBlock) {
        sr = sampleRate;
        block = maxBlock;
        for (int i = 0; i < voices.length; i++) voices[i] = new Voice();
        busRevL = new float[maxBlock];
        busRevR = new float[maxBlock];
        busDelL = new float[maxBlock];
        busDelR = new float[maxBlock];
        mL = new float[maxBlock];
        mR = new float[maxBlock];
        previewCh.vol = 0.85f;
        previewCh.mode = Project.ONESHOT;
        previewStrip = new Strip(previewCh, maxBlock);
        reverb = new Fx.Reverb(sampleRate);
        delay = new Fx.Delay(sampleRate);
        limiter = new Fx.Limiter(sampleRate);
    }

    // ================================================================== компиляция (поток интерфейса)

    /** Собрать песню в массивы. Вызывать из одного потока (интерфейса). */
    Compiled compile(Project p, Samples src) {
        Compiled c = new Compiled();
        c.project = p;
        int n = p.channels.size();
        c.ch = p.channels.toArray(new Project.Channel[0]);
        c.strips = new Strip[n];
        c.samples = new Sample[n];
        c.marks = new float[n][];
        HashMap<String, Integer> index = new HashMap<>();
        for (int i = 0; i < n; i++) {
            Project.Channel ch = c.ch[i];
            index.put(ch.id, i);
            Strip st = stripMap.get(ch.id);
            if (st == null || st.ch != ch) {
                st = new Strip(ch, block);
                stripMap.put(ch.id, st);
            }
            c.strips[i] = st;
            if (ch.type == Project.SAMPLER && src != null) c.samples[i] = src.get(ch.sample);
            c.marks[i] = marks(ch);
        }
        // текущий паттерн
        Project.Pattern cur = p.current();
        ArrayList<int[]> ev = new ArrayList<>();
        ArrayList<Project.Note> evn = new ArrayList<>();
        collect(p, cur, index, 0, cur.ticks(), 0, ev, evn);
        c.pTicks = Math.max(Project.STEP, cur.ticks());
        pack(ev, evn, c, false);
        // песня из плейлиста
        ev.clear();
        evn.clear();
        for (Project.Clip cl : p.clips) {
            if (cl.mute) continue;
            Project.Pattern pt = p.pattern(cl.pattern);
            if (pt == null) continue;
            int start = cl.start * Project.STEP, len = cl.len * Project.STEP, plen = Math.max(Project.STEP, pt.ticks());
            for (int off = 0; off < len; off += plen) collect(p, pt, index, start + off, Math.min(plen, len - off), 0, ev, evn);
        }
        c.sTicks = p.songSteps() * Project.STEP;
        pack(ev, evn, c, true);
        return c;
    }

    private static float[] marks(Project.Channel ch) {
        if (ch.type != Project.SAMPLER) return null;
        if (ch.sliceMarks != null && !ch.sliceMarks.isEmpty()) {
            String[] parts = ch.sliceMarks.split(",");
            float[] m = new float[parts.length];
            try {
                for (int i = 0; i < parts.length; i++) m[i] = Float.parseFloat(parts[i].trim());
                return m;
            } catch (NumberFormatException e) {
                return null;
            }
        }
        if (ch.slices > 1) {
            float[] m = new float[ch.slices];
            for (int i = 0; i < ch.slices; i++) m[i] = i / (float) ch.slices;
            return m;
        }
        return null;
    }

    /** Ноты паттерна в окне [0, limit) со сдвигом base; свинг сдвигает чётные шестнадцатые. */
    private static void collect(Project p, Project.Pattern pt, Map<String, Integer> index, int base, int limit, int unused,
                                List<int[]> ev, List<Project.Note> evn) {
        int sw = Math.round(p.swing * Project.STEP);
        for (Map.Entry<String, List<Project.Note>> e : pt.notes.entrySet()) {
            Integer ci = index.get(e.getKey());
            if (ci == null) continue;
            for (Project.Note nt : e.getValue()) {
                if (nt.start < 0 || nt.start >= limit) continue;
                int t = nt.start;
                if (sw > 0 && t % (2 * Project.STEP) == Project.STEP) t += sw;
                ev.add(new int[]{base + t, ci, nt.key, nt.len});
                evn.add(nt);
            }
        }
    }

    private static void pack(ArrayList<int[]> ev, ArrayList<Project.Note> evn, Compiled c, boolean song) {
        Integer[] order = new Integer[ev.size()];
        for (int i = 0; i < order.length; i++) order[i] = i;
        java.util.Arrays.sort(order, (a, b) -> ev.get(a)[0] != ev.get(b)[0] ? Integer.compare(ev.get(a)[0], ev.get(b)[0]) : Integer.compare(a, b));
        int n = order.length;
        int[] t = new int[n], ch = new int[n], k = new int[n], l = new int[n];
        float[] v = new float[n];
        boolean[] s = new boolean[n];
        for (int i = 0; i < n; i++) {
            int[] e = ev.get(order[i]);
            Project.Note nt = evn.get(order[i]);
            t[i] = e[0];
            ch[i] = e[1];
            k[i] = e[2];
            l[i] = e[3];
            v[i] = nt.vel;
            s[i] = nt.slide;
        }
        if (song) {
            c.sTick = t; c.sCh = ch; c.sKey = k; c.sLen = l; c.sVel = v; c.sSlide = s; c.sN = n;
        } else {
            c.pTick = t; c.pCh = ch; c.pKey = k; c.pLen = l; c.pVel = v; c.pSlide = s; c.pN = n;
        }
    }

    void publish(Compiled c) {
        song = c;
    }

    // ================================================================== управление (любой поток)

    void play() {
        finished = false;
        playing = true;
    }

    void stop() {
        playing = false;
        stopRequest = true;
    }

    void seek(double t) {
        seekTo = Math.max(0, t);
    }

    double spt() {
        return sr * 60.0 / (bpm * Project.PPQ);
    }

    /** Прослушать звук (из библиотеки или канала). null — остановить. */
    void preview(Sample s) {
        if (s == null) previewStop = true;
        else previewReq = s;
    }

    /** Нота с пэда/клавиатуры (поток интерфейса). vel ≤ 0 — отпустить. */
    void live(Project.Channel ch, int key, float vel) {
        int h = qHead, next = (h + 1) % Q;
        if (next == qTail) return; // очередь полна — пропускаем
        qCh[h] = ch;
        qKey[h] = key;
        qVel[h] = vel;
        qHead = next;
    }

    // ================================================================== звук (звуковой поток)

    /** Заполнить out (стерео, чередование L R) на frames кадров. */
    void process(float[] out, int frames) {
        int done = 0;
        while (done < frames) {
            int n = Math.min(block, frames - done);
            processBlock(out, done, n);
            done += n;
        }
    }

    private void processBlock(float[] out, int offset, int n) {
        Compiled c = song;
        if (c == null) {
            java.util.Arrays.fill(out, offset * 2, (offset + n) * 2, 0f);
            return;
        }
        double spt = spt();
        if (seekTo >= 0) {
            tick = seekTo;
            seekTo = -1;
        }
        if (stopRequest) {
            stopRequest = false;
            for (Voice v : voices) if (v.active) v.release();
        }
        if (panicRequest) {
            panicRequest = false;
            for (Voice v : voices) if (v.active) v.kill();
        }
        drainLive(c);
        if (previewStop || previewReq != null) {
            for (Voice v : voices) if (v.active && v.ch == previewCh) v.kill();
            previewStop = false;
        }
        Sample want = previewReq;
        if (want != null) {
            previewReq = null;
            previewCh.sample = want.id;
            alloc().start(previewCh, previewStrip, want, null, previewCh.root, 0.9f, 0, -1, sr, bpm, ++stamp);
        }
        if (playing) schedule(c, n, spt);

        for (Strip st : c.strips) {
            java.util.Arrays.fill(st.l, 0, n, 0f);
            java.util.Arrays.fill(st.r, 0, n, 0f);
        }
        java.util.Arrays.fill(busRevL, 0, n, 0f);
        java.util.Arrays.fill(busRevR, 0, n, 0f);
        java.util.Arrays.fill(busDelL, 0, n, 0f);
        java.util.Arrays.fill(busDelR, 0, n, 0f);
        java.util.Arrays.fill(mL, 0, n, 0f);
        java.util.Arrays.fill(mR, 0, n, 0f);

        float bpmNow = bpm;
        for (Voice v : voices) if (v.active && v.strip != previewStrip) v.render(v.strip.l, v.strip.r, n, bpmNow);

        java.util.Arrays.fill(previewStrip.l, 0, n, 0f);
        java.util.Arrays.fill(previewStrip.r, 0, n, 0f);
        for (Voice v : voices) if (v.active && v.strip == previewStrip) v.render(previewStrip.l, previewStrip.r, n, bpmNow);
        for (int i = 0; i < n; i++) {
            mL[i] += previewStrip.l[i] * 0.8f;
            mR[i] += previewStrip.r[i] * 0.8f;
        }
        boolean anySolo = false;
        for (Project.Channel ch : c.ch) if (ch.solo) anySolo = true;
        Project p = c.project;
        for (int s = 0; s < c.strips.length; s++) {
            Strip st = c.strips[s];
            Project.Channel ch = st.ch;
            boolean audible = !ch.mute && (!anySolo || ch.solo) && (c.only < 0 || c.only == s);
            mixStrip(st, ch, n, audible);
        }
        // шины посылов
        delay.process(busDelL, busDelR, mL, mR, n, (int) (p.delSteps * Project.STEP * spt), p.delFeedback, p.delDamp, p.delLevel);
        reverb.process(busRevL, busRevR, mL, mR, n, p.revSize, p.revDamp, p.revLevel);
        // мастер
        if (!rawMaster) glue.process(mL, mR, n, p.masterComp, sr, 10f, 120f);
        metronome(n, spt);
        float mv = p.masterVol;
        for (int i = 0; i < n; i++) {
            mL[i] *= mv;
            mR[i] *= mv;
        }
        float pl = 0, pr = 0;
        for (int i = 0; i < n; i++) {
            pl = Math.max(pl, Math.abs(mL[i]));
            pr = Math.max(pr, Math.abs(mR[i]));
        }
        if (pl > 1f || pr > 1f) clipped = true;
        lastPeakL = pl;
        lastPeakR = pr;
        if (!rawMaster) limiter.process(mL, mR, n, 0.97f);
        peakL = Math.max(peakL * 0.9f, pl);
        peakR = Math.max(peakR * 0.9f, pr);
        int o = offset * 2;
        for (int i = 0; i < n; i++) {
            float a = mL[i], b = mR[i];
            out[o++] = a != a ? 0 : a; // NaN не пускаем в выход
            out[o++] = b != b ? 0 : b;
        }
        position = tick;
    }

    private void mixStrip(Strip st, Project.Channel ch, int n, boolean audible) {
        float[] l = st.l, r = st.r;
        if (ch.fxDrive > 0.001f) {
            for (int i = 0; i < n; i++) {
                l[i] = Fx.drive(l[i], ch.fxDrive, ch.driveType);
                r[i] = Fx.drive(r[i], ch.fxDrive, ch.driveType);
            }
        }
        st.crush.process(l, r, n, ch.bits, ch.downsample);
        boolean filt = ch.fType == Dsp.LP ? ch.fCut < 19000f : ch.fType != Dsp.HP || ch.fCut > 25f;
        if (filt) {
            st.fl.set(ch.fCut, ch.fRes, sr);
            st.fr.set(ch.fCut, ch.fRes, sr);
            for (int i = 0; i < n; i++) {
                st.fl.process(l[i]);
                l[i] = st.fl.out(ch.fType);
                st.fr.process(r[i]);
                r[i] = st.fr.out(ch.fType);
            }
        }
        st.eq.process(l, r, n, ch.eqLow, ch.eqMid, ch.eqHigh, sr);
        st.comp.process(l, r, n, ch.comp, sr, 5f, 90f);
        float vol = audible ? ch.vol : 0f;
        if (st.volSm < 0) st.volSm = vol;
        float duckCoef = Dsp.Adsr.coef(Math.max(0.02f, ch.duckRelease), sr);
        float peak = 0;
        float sendR = ch.sendRev, sendD = ch.sendDelay;
        for (int i = 0; i < n; i++) {
            st.volSm += (vol - st.volSm) * 0.002f;
            st.panSm += (ch.pan - st.panSm) * 0.002f;
            float g = st.volSm * st.volSm * 1.2f; // кривая громкости ближе к слуху
            if (ch.duck > 0.001f) {
                if (i == st.duckAt) st.duckEnv = 1f;
                g *= 1f - ch.duck * st.duckEnv;
                st.duckEnv *= duckCoef;
            }
            float gl = g * Math.min(1f, 1f - st.panSm), gr = g * Math.min(1f, 1f + st.panSm);
            float a = l[i] * gl, b = r[i] * gr;
            mL[i] += a;
            mR[i] += b;
            if (sendR > 0.001f) {
                busRevL[i] += a * sendR;
                busRevR[i] += b * sendR;
            }
            if (sendD > 0.001f) {
                busDelL[i] += a * sendD;
                busDelR[i] += b * sendD;
            }
            float m = Math.max(Math.abs(a), Math.abs(b));
            if (m > peak) peak = m;
        }
        st.duckAt = -1;
        st.peak = Math.max(st.peak * 0.85f, peak);
    }

    // ================================================================== события

    private void schedule(Compiled c, int n, double spt) {
        boolean song = songMode && c.sTicks > 0;
        int len = song ? c.sTicks : c.pTicks;
        if (len <= 0) return;
        if (tick >= len) tick = song && !loop ? len : tick % len;
        double start = tick, end = tick + n / spt;
        emit(c, song, start, Math.min(end, len), 0, spt);
        if (end >= len) {
            if (song && !loop) {
                playing = false;
                finished = true;
                tick = 0;
                return;
            }
            double rest = end - len;
            int base = (int) ((len - start) * spt);
            emit(c, song, 0, rest, base, spt);
            tick = rest;
        } else {
            tick = end;
        }
    }

    private void emit(Compiled c, boolean song, double a, double b, int frameBase, double spt) {
        int[] T = song ? c.sTick : c.pTick;
        int N = song ? c.sN : c.pN;
        int lo = 0, hi = N;
        int from = (int) Math.ceil(a);
        while (lo < hi) {
            int mid = (lo + hi) >>> 1;
            if (T[mid] < from) lo = mid + 1;
            else hi = mid;
        }
        for (int i = lo; i < N && T[i] < b; i++) {
            int off = frameBase + (int) ((T[i] - a) * spt);
            if (song) trigger(c, c.sCh[i], c.sKey[i], c.sVel[i], c.sLen[i], c.sSlide[i], off, spt);
            else trigger(c, c.pCh[i], c.pKey[i], c.pVel[i], c.pLen[i], c.pSlide[i], off, spt);
        }
    }

    private void trigger(Compiled c, int ci, int key, float vel, int lenTicks, boolean slide, int offset, double spt) {
        if (ci < 0 || ci >= c.ch.length) return;
        Project.Channel ch = c.ch[ci];
        offset = Math.max(0, Math.min(block - 1, offset));
        if (ch.sideSource) {
            for (Strip st : c.strips) if (st.ch.duck > 0.001f && (st.duckAt < 0 || offset < st.duckAt)) st.duckAt = offset;
        }
        if (ch.mute) return;
        noteOn(c, ci, key, vel, (long) (lenTicks * spt), slide, offset);
    }

    private void noteOn(Compiled c, int ci, int key, float vel, long lenFrames, boolean slide, int offset) {
        Project.Channel ch = c.ch[ci];
        if (ch.choke > 0) {
            for (Voice v : voices) if (v.active && v.ch.choke == ch.choke && !v.fading()) v.kill();
        }
        if (ch.monophonic()) {
            Voice cur = null;
            for (Voice v : voices) if (v.active && v.ch == ch && !v.fading() && (cur == null || v.stamp > cur.stamp)) cur = v;
            if (cur != null && slide) {
                cur.glideTo(key, vel, lenFrames, ch.glide > 0.001f ? ch.glide : 0.07f);
                return;
            }
            if (cur != null) cur.kill();
        }
        Voice v = alloc();
        v.start(ch, c.strips[ci], c.samples[ci], c.marks[ci], key, vel, offset, lenFrames, sr, bpm, ++stamp);
    }

    private Voice alloc() {
        Voice best = null;
        for (Voice v : voices) {
            if (!v.active) return v;
            if (best == null || v.stamp < best.stamp) best = v;
        }
        return best;
    }

    private void drainLive(Compiled c) {
        while (qTail != qHead) {
            int t = qTail;
            Project.Channel ch = qCh[t];
            int key = qKey[t];
            float vel = qVel[t];
            qCh[t] = null;
            qTail = (t + 1) % Q;
            int ci = -1;
            for (int i = 0; i < c.ch.length; i++) if (c.ch[i] == ch) ci = i;
            if (ci < 0) continue;
            if (vel > 0) {
                if (ch.sideSource) for (Strip st : c.strips) if (st.ch.duck > 0.001f) st.duckAt = 0;
                noteOn(c, ci, key, vel, -1, false, 0);
            } else if (!(ch.type == Project.SAMPLER && ch.mode == Project.ONESHOT)) {
                // барабаны-однократники звучат до конца, даже если палец убран
                for (Voice v : voices) if (v.active && v.ch == ch && v.key == key && v.held) v.release();
            }
        }
    }

    private void metronome(int n, double spt) {
        if (playing && metronome) {
            double start = tick - n / spt; // tick уже сдвинут вперёд
            for (int i = 0; i < n; i++) {
                double t = start + i / spt;
                if (t < 0) continue;
                long beat = (long) Math.floor(t / Project.PPQ), prev = (long) Math.floor((t - 1 / spt) / Project.PPQ);
                if (beat != prev || (i == 0 && Math.abs(t - beat * Project.PPQ) < 1 / spt)) {
                    clickEnv = 0.5f;
                    clickHz = beat % 4 == 0 ? 1760f : 1180f;
                    clickPh = 0;
                }
                if (clickEnv > 0.001f) {
                    float s = Dsp.sin01(clickPh) * clickEnv;
                    clickPh += clickHz / sr;
                    clickEnv *= 0.9985f;
                    mL[i] += s;
                    mR[i] += s;
                }
            }
        }
    }

    /** Сколько голосов звучит (для индикатора нагрузки). */
    int activeVoices() {
        int n = 0;
        for (Voice v : voices) if (v.active) n++;
        return n;
    }

    /** Заглушить всё сразу (паника). Выполнит звуковой поток. */
    void panic() {
        panicRequest = true;
    }

    /** Пик последнего блока (для экспорта: ждать затухания хвостов). */
    float blockPeak() {
        return Math.max(lastPeakL, lastPeakR);
    }
}
