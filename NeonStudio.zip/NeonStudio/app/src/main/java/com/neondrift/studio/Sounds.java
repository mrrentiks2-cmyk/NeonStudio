package com.neondrift.studio;

import android.content.Context;

import java.util.HashSet;
import java.util.Set;

/**
 * Единая точка для звуков по ссылкам: «builtin:…» — встроенные (синтезируются),
 * «lib:…» — из библиотеки пользователя (файлы, расшифровка в фоне).
 */
final class Sounds {
    private Sounds() {}

    static boolean builtin(String ref) {
        return ref != null && ref.startsWith(Kits.PREFIX);
    }

    static boolean library(String ref) {
        return ref != null && ref.startsWith(Library.PREFIX);
    }

    /** Загрузить сразу (может занять время для файлов — не из главного потока). */
    static Sample load(Context c, String ref, int rate) {
        if (ref == null || ref.isEmpty()) return null;
        if (builtin(ref)) return Kits.get(ref, rate);
        if (library(ref)) return Library.load(c, ref, rate);
        return null;
    }

    /** Источник для движка, который не ждёт: только то, что уже в памяти; остальное — в missing. */
    static Engine.Samples cached(int rate, Set<String> missing) {
        return ref -> {
            if (ref == null || ref.isEmpty()) return null;
            Sample s = peek(ref, rate);
            if (s == null && missing != null && (library(ref) || builtin(ref))) missing.add(ref);
            return s;
        };
    }

    static Sample peek(String ref, int rate) {
        if (builtin(ref)) return Kits.peek(ref, rate);
        if (library(ref)) return Library.cachedOnly(ref, rate);
        return null;
    }

    /** Источник, который ждёт загрузки (экспорт в фоне). */
    static Engine.Samples blocking(Context c, int rate) {
        return ref -> load(c, ref, rate);
    }

    /** Все звуки проекта (для сборки пакета «проект + звуки»). */
    static Set<String> used(Project p) {
        HashSet<String> out = new HashSet<>();
        for (Project.Channel ch : p.channels) if (ch.type == Project.SAMPLER && ch.sample != null && !ch.sample.isEmpty()) out.add(ch.sample);
        return out;
    }

    static String title(String ref) {
        if (ref == null || ref.isEmpty()) return "нет звука";
        if (builtin(ref)) return Kits.name(ref.substring(Kits.PREFIX.length()));
        String s = ref.substring(ref.lastIndexOf('/') + 1);
        if (s.startsWith(Library.PREFIX)) s = s.substring(Library.PREFIX.length());
        return s.contains(".") ? s.substring(0, s.lastIndexOf('.')) : s;
    }
}
