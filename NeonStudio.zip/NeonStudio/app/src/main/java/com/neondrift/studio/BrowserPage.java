package com.neondrift.studio;

import android.content.Context;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;

/**
 * Звуки: встроенный набор (синтезируется), библиотека из ваших архивов и файлов, запись с микрофона.
 * ▶ — послушать, «＋» — новый канал с этим звуком, «⇄» — заменить звук выбранного канала.
 */
final class BrowserPage extends LinearLayout {
    interface Host {
        void addChannelWithSound(String ref, String name, String category);

        void replaceSound(String ref);

        void insertMidi(String ref, String name);

        void importZip();

        void importFiles();

        void importFolder();

        void deletePack(String pack);

        void requestMic(Runnable granted);

        void toast(String s);
    }

    static final int BUILTIN = 0, LIBRARY = 1, RECORD = 2;
    private final Studio s;
    private final Ui ui;
    private final Host host;
    private int source = BUILTIN;
    private String pack, category, query = "";
    private final LinearLayout tabs, filters, packsRow, catsRow, importRow, recordBox;
    private final EditText search;
    private final ListView list;
    private final TextView empty;
    private final Adapter adapter = new Adapter();
    private List<Library.Entry> all = new ArrayList<>();
    private String playing;
    private final Recorder recorder = new Recorder();
    private TextView recTime;
    private View recLevel;
    private ImageView recButton;

    BrowserPage(Context c, Studio s, Ui ui, Host host) {
        super(c);
        this.s = s;
        this.ui = ui;
        this.host = host;
        setOrientation(VERTICAL);

        tabs = ui.row();
        tabs.setPadding(ui.dp(10), ui.dp(8), ui.dp(10), ui.dp(4));
        addView(tabs);

        filters = ui.col();
        addView(filters);
        packsRow = chipRow(filters);
        catsRow = chipRow(filters);

        search = new EditText(c);
        search.setHint("Поиск по названию");
        search.setHintTextColor(Theme.MUTED);
        search.setTextColor(Theme.TEXT);
        search.setTextSize(14);
        search.setSingleLine(true);
        search.setInputType(InputType.TYPE_CLASS_TEXT);
        search.setBackground(Ui.stroke(Theme.SURFACE, Theme.LINE, ui.dp(1), ui.dp(12)));
        search.setPadding(ui.dp(14), ui.dp(9), ui.dp(14), ui.dp(9));
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence a, int b, int c2, int d) {
            }

            @Override
            public void onTextChanged(CharSequence a, int b, int c2, int d) {
            }

            @Override
            public void afterTextChanged(Editable e) {
                query = e.toString();
                refreshList();
            }
        });
        filters.addView(search, Ui.margins(Ui.MATCH, Ui.WRAP, ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(4)));

        importRow = ui.row();
        importRow.setPadding(ui.dp(10), ui.dp(4), ui.dp(10), ui.dp(6));
        importRow.addView(smallButton("archive", "Архив ZIP", v -> host.importZip()), Ui.lp(0, Ui.WRAP, 1f));
        importRow.addView(space());
        importRow.addView(smallButton("file", "Файлы", v -> host.importFiles()), Ui.lp(0, Ui.WRAP, 1f));
        importRow.addView(space());
        importRow.addView(smallButton("folder", "Папка", v -> host.importFolder()), Ui.lp(0, Ui.WRAP, 1f));
        filters.addView(importRow);

        FrameLayout body = new FrameLayout(c);
        list = new ListView(c);
        list.setDivider(null);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0));
        list.setAdapter(adapter);
        list.setPadding(0, 0, 0, ui.dp(10));
        list.setClipToPadding(false);
        body.addView(list, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        empty = ui.text("", 14, Theme.MUTED, false);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(ui.dp(28), ui.dp(20), ui.dp(28), ui.dp(20));
        empty.setLineSpacing(0, 1.3f);
        body.addView(empty, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        recordBox = buildRecorder();
        body.addView(recordBox, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        addView(body, Ui.lp(Ui.MATCH, 0, 1f));
        setSource(BUILTIN);
    }

    private View space() {
        return new View(getContext()) {
            {
                setLayoutParams(Ui.lp(ui.dp(8), 1));
            }
        };
    }

    private LinearLayout chipRow(LinearLayout parent) {
        HorizontalScrollView hs = new HorizontalScrollView(getContext());
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(10), ui.dp(3), ui.dp(10), ui.dp(3));
        hs.addView(row);
        parent.addView(hs);
        return row;
    }

    private TextView smallButton(String icon, String label, OnClickListener l) {
        TextView b = ui.text(label, 13, Theme.TEXT, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(ui.dp(8), ui.dp(9), ui.dp(8), ui.dp(9));
        Glyph g = new Glyph(icon, Theme.ACCENT);
        g.setBounds(0, 0, ui.dp(18), ui.dp(18));
        b.setCompoundDrawables(g, null, null, null);
        b.setCompoundDrawablePadding(ui.dp(6));
        b.setBackground(Ui.ripple(Ui.stroke(Theme.SURFACE, Theme.LINE, ui.dp(1), ui.dp(12)), null));
        b.setOnClickListener(l);
        return b;
    }

    // ================================================================== источники

    void setSource(int src) {
        source = src;
        pack = null;
        category = null;
        tabs.removeAllViews();
        String[] names = {"Встроенные", "Библиотека", "Запись"};
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            TextView t = ui.chip(names[i], i == source, v -> setSource(k));
            tabs.addView(t, Ui.margins(Ui.WRAP, Ui.WRAP, 0, 0, ui.dp(8), 0));
        }
        boolean lib = source == LIBRARY;
        search.setVisibility(lib ? VISIBLE : GONE);
        importRow.setVisibility(lib ? VISIBLE : GONE);
        ((View) packsRow.getParent()).setVisibility(lib ? VISIBLE : GONE);
        ((View) catsRow.getParent()).setVisibility(source == RECORD ? GONE : VISIBLE);
        recordBox.setVisibility(source == RECORD ? VISIBLE : GONE);
        list.setVisibility(source == RECORD ? GONE : VISIBLE);
        if (lib) reloadLibrary();
        else {
            buildFilters();
            refreshList();
        }
    }

    /** Перечитать библиотеку (после импорта). */
    void reloadLibrary() {
        empty.setText("Загрузка библиотеки…");
        empty.setVisibility(VISIBLE);
        Context app = getContext().getApplicationContext();
        new Thread(() -> {
            List<Library.Entry> e = Library.entries(app);
            post(() -> {
                all = e;
                if (pack != null && !Library.packs(app).contains(pack)) pack = null;
                buildFilters();
                refreshList();
            });
        }, "neon-lib").start();
    }

    void showLibrary() {
        if (source != LIBRARY) setSource(LIBRARY);
        else reloadLibrary();
    }

    private void buildFilters() {
        packsRow.removeAllViews();
        catsRow.removeAllViews();
        if (source == BUILTIN) {
            addChip(catsRow, "Все", category == null, () -> {
                category = null;
                buildFilters();
                refreshList();
            }, null);
            LinkedHashSet<String> cats = new LinkedHashSet<>();
            for (String[] snd : Kits.SOUNDS) cats.add(snd[2]);
            for (String cat : cats) addChip(catsRow, cat, cat.equals(category), () -> {
                category = cat;
                buildFilters();
                refreshList();
            }, null);
        } else if (source == LIBRARY) {
            addChip(packsRow, "Все паки", pack == null, () -> {
                pack = null;
                buildFilters();
                refreshList();
            }, null);
            LinkedHashSet<String> packs = new LinkedHashSet<>();
            for (Library.Entry e : all) packs.add(e.pack);
            for (String pk : packs) addChip(packsRow, pk, pk.equals(pack), () -> {
                pack = pk;
                buildFilters();
                refreshList();
            }, () -> host.deletePack(pk));
            LinkedHashSet<String> cats = new LinkedHashSet<>();
            for (String cat : Library.CATEGORIES) {
                for (Library.Entry e : all) {
                    if (e.category.equals(cat) && (pack == null || pack.equals(e.pack))) {
                        cats.add(cat);
                        break;
                    }
                }
            }
            if (category != null && !cats.contains(category)) category = null;
            addChip(catsRow, "Все", category == null, () -> {
                category = null;
                buildFilters();
                refreshList();
            }, null);
            for (String cat : cats) addChip(catsRow, cat, cat.equals(category), () -> {
                category = cat;
                buildFilters();
                refreshList();
            }, null);
        }
    }

    private void addChip(LinearLayout row, String label, boolean on, Runnable click, Runnable longClick) {
        TextView t = ui.chip(label, on, v -> click.run());
        t.setTextSize(13);
        t.setPadding(ui.dp(12), ui.dp(6), ui.dp(12), ui.dp(6));
        if (longClick != null) t.setOnLongClickListener(v -> {
            longClick.run();
            return true;
        });
        row.addView(t, Ui.margins(Ui.WRAP, Ui.WRAP, 0, 0, ui.dp(6), 0));
    }

    // ================================================================== список

    private final List<Object> rows = new ArrayList<>();

    private void refreshList() {
        rows.clear();
        if (source == BUILTIN) {
            for (String[] snd : Kits.SOUNDS) if (category == null || category.equals(snd[2])) rows.add(snd);
            empty.setVisibility(GONE);
        } else if (source == LIBRARY) {
            rows.addAll(Library.filter(all, pack, category, query));
            if (all.isEmpty()) {
                empty.setText("Здесь будут ваши звуки.\n\n«Архив ZIP» — драм-кит или сэмпл-пак целиком (вложенные архивы тоже). "
                        + "«Файлы» — WAV, MP3, OGG, FLAC, M4A, MIDI. «Папка» — папка с телефона.\n\nЗвуки сами разложатся по категориям: бочки, 808, хэты, петли…");
                empty.setVisibility(VISIBLE);
            } else if (rows.isEmpty()) {
                empty.setText("Ничего не найдено");
                empty.setVisibility(VISIBLE);
            } else {
                empty.setVisibility(GONE);
            }
        } else {
            empty.setVisibility(GONE);
        }
        adapter.notifyDataSetChanged();
    }

    private final class Adapter extends BaseAdapter {
        @Override
        public int getCount() {
            return rows.size();
        }

        @Override
        public Object getItem(int i) {
            return rows.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View convert, ViewGroup parent) {
            Object o = rows.get(i);
            String ref, name, sub, cat;
            boolean midi = false;
            if (o instanceof String[]) {
                String[] snd = (String[]) o;
                ref = Kits.PREFIX + snd[0];
                name = snd[1];
                cat = snd[2];
                sub = snd[2];
            } else {
                Library.Entry e = (Library.Entry) o;
                ref = e.ref();
                name = e.name;
                cat = e.category;
                midi = e.midi;
                StringBuilder sb = new StringBuilder(e.category);
                if (pack == null) sb.append(" · ").append(e.pack);
                if (e.bpm > 0) sb.append(" · ").append(Math.round(e.bpm)).append(" BPM");
                sub = sb.toString();
            }
            return row(ref, name, sub, cat, midi);
        }
    }

    private View row(String ref, String name, String sub, String cat, boolean midi) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(6), ui.dp(4), ui.dp(8), ui.dp(4));
        boolean isPlaying = ref.equals(playing);
        ImageView play = ui.iconButton(midi ? "piano" : isPlaying ? "stop" : "play", isPlaying ? Theme.ACCENT : Theme.TEXT, 44, 11, v -> {
            if (midi) return;
            if (ref.equals(playing)) {
                s.engine.preview(null);
                playing = null;
            } else {
                playing = ref;
                s.preview(ref);
            }
            adapter.notifyDataSetChanged();
        });
        row.addView(play);
        LinearLayout texts = ui.col();
        texts.addView(ui.oneLine(name, 15, Theme.TEXT, false));
        texts.addView(ui.oneLine(sub, 11.5f, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
        row.addView(texts, Ui.lp(0, Ui.WRAP, 1f));
        if (midi) {
            row.addView(action("В паттерн", () -> host.insertMidi(ref, name)));
        } else {
            row.addView(action("⇄", () -> host.replaceSound(ref)));
            row.addView(action("＋", () -> host.addChannelWithSound(ref, name, cat)));
        }
        row.setBackground(Ui.ripple(Ui.round(isPlaying ? Theme.alpha(Theme.ACCENT, 26) : 0, ui.dp(10)), Ui.round(0xFFFFFFFF, ui.dp(10))));
        row.setOnClickListener(v -> play.performClick());
        ListView.LayoutParams lp = new ListView.LayoutParams(Ui.MATCH, Ui.WRAP);
        row.setLayoutParams(lp);
        FrameLayout wrap = new FrameLayout(getContext());
        wrap.setPadding(ui.dp(6), 0, ui.dp(6), 0);
        wrap.addView(row);
        return wrap;
    }

    private TextView action(String label, Runnable r) {
        TextView t = ui.text(label, label.length() > 2 ? 13 : 17, Theme.TEXT, true);
        t.setGravity(Gravity.CENTER);
        t.setMinWidth(ui.dp(42));
        t.setPadding(ui.dp(10), ui.dp(7), ui.dp(10), ui.dp(7));
        t.setBackground(Ui.ripple(Ui.stroke(Theme.SURFACE2, Theme.LINE, ui.dp(1), ui.dp(10)), null));
        t.setOnClickListener(v -> r.run());
        LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
        lp.leftMargin = ui.dp(6);
        t.setLayoutParams(lp);
        return t;
    }

    // ================================================================== запись с микрофона

    private LinearLayout buildRecorder() {
        LinearLayout box = ui.col();
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setPadding(ui.dp(24), ui.dp(24), ui.dp(24), ui.dp(24));
        TextView hint = ui.text("Голосовой тег, вокал или звук с улицы — запись сразу появится в библиотеке (пак «Записи»).",
                13, Theme.MUTED, false);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(0, 1.3f);
        box.addView(hint, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(24)));
        recButton = new ImageView(getContext());
        recButton.setImageDrawable(new Glyph("mic", Theme.BG));
        recButton.setPadding(ui.dp(26), ui.dp(26), ui.dp(26), ui.dp(26));
        recButton.setBackground(Ui.ripple(Ui.oval(0xFFFF2D6E), Ui.oval(0xFFFFFFFF)));
        recButton.setOnClickListener(v -> toggleRecord());
        box.addView(recButton, Ui.lp(ui.dp(104), ui.dp(104)));
        recTime = ui.text("0:00.0", 26, Theme.TEXT, true);
        recTime.setGravity(Gravity.CENTER);
        box.addView(recTime, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(18), 0, ui.dp(10)));
        FrameLayout bar = new FrameLayout(getContext());
        bar.setBackground(Ui.round(Theme.SURFACE2, ui.dp(4)));
        recLevel = new View(getContext());
        recLevel.setBackground(Ui.round(0xFF8CFF5A, ui.dp(4)));
        bar.addView(recLevel, new FrameLayout.LayoutParams(0, Ui.MATCH));
        box.addView(bar, Ui.lp(ui.dp(220), ui.dp(8)));
        TextView play = ui.chip("Играть бит во время записи", s.prefs.recPlay(), null);
        play.setOnClickListener(v -> {
            boolean on = !s.prefs.recPlay();
            s.prefs.put("recPlay", on);
            ui.styleChip(play, on);
        });
        box.addView(play, Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(22), 0, 0));
        return box;
    }

    private final Runnable recTick = new Runnable() {
        @Override
        public void run() {
            if (!recorder.running()) return;
            float sec = recorder.seconds();
            recTime.setText(String.format(Locale.ROOT, "%d:%04.1f", (int) (sec / 60), sec % 60));
            ViewGroup.LayoutParams lp = recLevel.getLayoutParams();
            lp.width = Math.round(ui.dp(220) * Math.min(1f, recorder.level * 1.4f));
            recLevel.setLayoutParams(lp);
            postDelayed(this, 50);
        }
    };

    private void toggleRecord() {
        if (recorder.running()) {
            stopRecord();
            return;
        }
        host.requestMic(() -> {
            try {
                recorder.start(getContext());
                if (s.prefs.recPlay() && !s.playing()) s.play();
                recButton.setImageDrawable(new Glyph("stop", Theme.BG));
                post(recTick);
            } catch (java.io.IOException e) {
                host.toast("Не удалось начать запись: " + e.getMessage());
            }
        });
    }

    void stopRecord() {
        if (!recorder.running()) return;
        try {
            File f = recorder.stop();
            if (s.prefs.recPlay() && s.playing()) s.stop();
            recButton.setImageDrawable(new Glyph("mic", Theme.BG));
            recTime.setText("0:00.0");
            if (f != null) {
                host.toast("Сохранено: " + f.getName().replace(".wav", "") + " — в «Библиотеке», пак «Записи»");
                all = new ArrayList<>();
            }
        } catch (java.io.IOException e) {
            host.toast("Запись не сохранилась: " + e.getMessage());
        }
    }

    void stopPreview() {
        if (playing != null) {
            s.engine.preview(null);
            playing = null;
            adapter.notifyDataSetChanged();
        }
    }
}
