package com.neondrift.studio;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;

import java.io.File;
import java.io.IOException;

/** Запись с микрофона в WAV (папка «Записи» библиотеки): голосовые теги, сэмплы, вокал. */
final class Recorder {
    private AudioRecord rec;
    private Thread thread;
    private volatile boolean running;
    volatile float level;
    volatile long frames;
    final int rate = 44100;
    File file;
    private volatile IOException error;

    static File dir(Context c) {
        File d = new File(Library.root(c), "Записи");
        if (!d.isDirectory()) d.mkdirs();
        return d;
    }

    static File next(Context c) {
        File d = dir(c);
        for (int i = 1; ; i++) {
            File f = new File(d, "Запись " + i + ".wav");
            if (!f.exists()) return f;
        }
    }

    boolean running() {
        return running;
    }

    @SuppressLint("MissingPermission") // разрешение спрашивается перед вызовом
    void start(Context c) throws IOException {
        if (running) return;
        int min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        if (min <= 0) throw new IOException("микрофон недоступен");
        rec = new AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, rate / 5 * 2));
        if (rec.getState() != AudioRecord.STATE_INITIALIZED) {
            rec.release();
            rec = null;
            throw new IOException("микрофон занят другим приложением");
        }
        file = next(c);
        Wav.Writer w = new Wav.Writer(file, rate, 16);
        frames = 0;
        error = null;
        running = true;
        rec.startRecording();
        AudioRecord r = rec;
        thread = new Thread(() -> {
            short[] buf = new short[1024];
            float[] st = new float[2048];
            try {
                while (running) {
                    int n = r.read(buf, 0, buf.length);
                    if (n <= 0) continue;
                    float pk = 0;
                    for (int i = 0; i < n; i++) {
                        float v = buf[i] / 32768f;
                        st[2 * i] = v;
                        st[2 * i + 1] = v;
                        pk = Math.max(pk, Math.abs(v));
                    }
                    level = Math.max(pk, level * 0.85f);
                    w.write(st, n);
                    frames += n;
                }
            } catch (IOException e) {
                error = e;
            } finally {
                try {
                    w.close();
                } catch (IOException e) {
                    error = e;
                }
            }
        }, "neon-rec");
        thread.start();
    }

    /** Остановить и вернуть файл (или null, если запись пустая). */
    File stop() throws IOException {
        if (!running) return null;
        running = false;
        try {
            thread.join(1000);
        } catch (InterruptedException ignored) {
        }
        try {
            rec.stop();
        } catch (IllegalStateException ignored) {
        }
        rec.release();
        rec = null;
        level = 0;
        if (error != null) throw error;
        if (frames < rate / 10) {
            file.delete();
            return null;
        }
        Library.invalidate();
        return file;
    }

    float seconds() {
        return frames / (float) rate;
    }
}
