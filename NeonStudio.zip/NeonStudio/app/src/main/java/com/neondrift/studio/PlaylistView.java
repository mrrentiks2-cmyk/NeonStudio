package com.neondrift.studio;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.List;
import java.util.Map;

/**
 * Плейлист: паттерны на дорожках во времени. Касание пустого места — поставить выбранный
 * паттерн, перетаскивание клипа — сдвиг, правый край — длина (паттерн повторяется),
 * касание клипа — выбрать. Один палец по пустому — прокрутка, два — масштаб.
 */
final class PlaylistView extends View {
    interface Host {
        void onClipSelected(Project.Clip c);

        Project.Pattern brush();
    }

    private final Studio s;
    private final Ui ui;
    private final Host host;
    Project.Clip selected;

    private float pxPerStep, scrollX, scrollY;
    private boolean fitted;
    private final float trackH, headW, rulerH, slop;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG), line = new Paint(), text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path path = new Path();

    PlaylistView(Context c, Studio s, Ui ui, Host host) {
        super(c);
        this.s = s;
        this.ui = ui;
        this.host = host;
        trackH = ui.dp(48);
        headW = ui.dp(34);
        rulerH = ui.dp(26);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        text.setTextSize(ui.dp(11));
    }

    void fit() {
        fitted = false;
        invalidate();
    }

    private void doFit() {
        if (getWidth() == 0) return;
        fitted = true;
        int steps = Math.max(8 * Project.BAR, s.p.songSteps() + 2 * Project.BAR);
        pxPerStep = (getWidth() - headW) / (float) steps;
        scrollX = 0;
        clamp();
    }

    private void clamp() {
        pxPerStep = Math.max((getWidth() - headW) / (float) (512 * Project.BAR), Math.min(ui.dp(24), pxPerStep));
        float vis = (getWidth() - headW) / pxPerStep;
        scrollX = Math.max(0, Math.min(scrollX, Math.max(0, s.p.songSteps() + 16 * Project.BAR - vis)));
        float content = rulerH + (s.p.tracks + 1) * trackH;
        scrollY = Math.max(0, Math.min(scrollY, Math.max(0, content - getHeight())));
    }

    float x(double step) {
        return (float) (headW + (step - scrollX) * pxPerStep);
    }

    double step(float x) {
        return scrollX + (x - headW) / pxPerStep;
    }

    int track(float y) {
        return (int) Math.floor((y - rulerH + scrollY) / trackH);
    }

    float trackTop(int t) {
        return rulerH + t * trackH - scrollY;
    }

    /** Сетка привязки: такт или доля при крупном масштабе. */
    int grid() {
        return pxPerStep * 4 >= ui.dp(22) ? 4 : Project.BAR;
    }

    // ================================================================== рисование

    @Override
    protected void onDraw(Canvas c) {
        if (!fitted) doFit();
        if (getWidth() == 0) return;
        clamp();
        Project p = s.p;
        int W = getWidth(), H = getHeight();
        // дорожки
        for (int t = 0; t <= p.tracks; t++) {
            float y0 = trackTop(t);
            if (y0 > H || y0 + trackH < rulerH) continue;
            fill.setColor(t == p.tracks ? Theme.BG : t % 2 == 0 ? 0xFF15111F : 0xFF19142A);
            c.drawRect(headW, Math.max(rulerH, y0), W, Math.min(H, y0 + trackH), fill);
        }
        // сетка
        double s0 = Math.max(0, step(headW)), s1 = step(W);
        int every = pxPerStep * 4 >= ui.dp(8) ? 4 : pxPerStep * Project.BAR >= ui.dp(8) ? Project.BAR : 4 * Project.BAR;
        for (long st = (long) (Math.floor(s0 / every) * every); st <= s1; st += every) {
            float xx = x(st);
            if (xx < headW) continue;
            line.setColor(st % (4 * Project.BAR) == 0 ? 0xFF4A4068 : st % Project.BAR == 0 ? 0xFF2E2742 : 0xFF211B31);
            c.drawLine(xx, rulerH, xx, Math.min(H, trackTop(p.tracks)), line);
        }
        // клипы
        c.save();
        c.clipRect(headW, rulerH, W, H);
        text.setTypeface(Typeface.DEFAULT_BOLD);
        for (Project.Clip cl : p.clips) {
            Project.Pattern pt = p.pattern(cl.pattern);
            if (pt == null) continue;
            float x0 = x(cl.start), x1 = x(cl.end()), y0 = trackTop(cl.track);
            if (x1 < headW || x0 > W || y0 > H || y0 + trackH < rulerH) continue;
            r.set(x0 + 1, y0 + ui.dp(3), x1 - 1, y0 + trackH - ui.dp(3));
            int col = cl.mute ? 0xFF4A4458 : pt.color;
            fill.setColor(Theme.mix(col, Theme.BG, 0.55f));
            c.drawRoundRect(r, ui.dp(6), ui.dp(6), fill);
            // мини-карта нот
            drawMini(c, pt, r, col, cl);
            // повторы паттерна
            line.setColor(Theme.alpha(col, 140));
            for (int k = cl.start + pt.steps; k < cl.end(); k += pt.steps) {
                float xx = x(k);
                c.drawLine(xx, r.top + ui.dp(4), xx, r.bottom - ui.dp(4), line);
            }
            fill.setStyle(Paint.Style.STROKE);
            fill.setStrokeWidth(ui.dp(cl == selected ? 2f : 1f));
            fill.setColor(cl == selected ? 0xFFFFFFFF : col);
            c.drawRoundRect(r, ui.dp(6), ui.dp(6), fill);
            fill.setStyle(Paint.Style.FILL);
            if (r.width() > ui.dp(30)) {
                text.setColor(cl.mute ? Theme.MUTED : Theme.TEXT);
                text.setTextAlign(Paint.Align.LEFT);
                c.save();
                c.clipRect(r);
                c.drawText(pt.name, Math.max(r.left, headW) + ui.dp(6), r.top + ui.dp(14), text);
                c.restore();
            }
            if (cl == selected) {
                fill.setColor(0xFFFFFFFF);
                c.drawRoundRect(r.right - ui.dp(6), r.centerY() - ui.dp(9), r.right - ui.dp(2), r.centerY() + ui.dp(9), ui.dp(2), ui.dp(2), fill);
            }
        }
        // курсор песни
        if (s.playing() && s.engine.songMode) {
            float px = x(s.position() / Project.STEP);
            fill.setColor(Theme.ACCENT2);
            c.drawRect(px - ui.dp(1), rulerH, px + ui.dp(1), H, fill);
        }
        c.restore();
        // заголовки дорожек
        fill.setColor(0xFF0D0B14);
        c.drawRect(0, rulerH, headW, H, fill);
        text.setTypeface(Typeface.DEFAULT);
        text.setTextAlign(Paint.Align.CENTER);
        for (int t = 0; t <= p.tracks; t++) {
            float y0 = trackTop(t);
            if (y0 > H || y0 + trackH < rulerH) continue;
            text.setColor(t == p.tracks ? Theme.ACCENT : Theme.MUTED);
            c.drawText(t == p.tracks ? "＋" : String.valueOf(t + 1), headW / 2, y0 + trackH / 2 + ui.dp(4), text);
        }
        drawRuler(c, W, p);
    }

    private void drawMini(Canvas c, Project.Pattern pt, RectF box, int col, Project.Clip cl) {
        List<Project.Channel> chs = s.p.channels;
        int n = chs.size();
        if (n == 0 || pt.steps <= 0) return;
        float top = box.top + ui.dp(19), bottom = box.bottom - ui.dp(4);
        if (bottom - top < ui.dp(8)) return;
        float rowH = (bottom - top) / n;
        fill.setColor(Theme.alpha(col == 0xFF4A4458 ? 0xFF9A91B8 : 0xFFFFFFFF, 150));
        float stepPx = pxPerStep;
        for (int ci = 0; ci < n; ci++) {
            List<Project.Note> notes = pt.notes.get(chs.get(ci).id);
            if (notes == null) continue;
            float y = top + ci * rowH;
            for (int rep = 0; rep * pt.steps < cl.len; rep++) {
                float base = cl.start + rep * pt.steps;
                for (Project.Note nt : notes) {
                    float st = nt.start / (float) Project.STEP;
                    if (st >= pt.steps || rep * pt.steps + st >= cl.len) continue;
                    float xx = x(base + st);
                    if (xx > box.right || xx < headW - 4) continue;
                    float w = Math.max(ui.dp(1.5f), Math.min(nt.len / (float) Project.STEP, pt.steps - st) * stepPx - 1);
                    c.drawRect(xx, y, Math.min(box.right - 1, xx + w), y + Math.max(1, rowH - 1), fill);
                }
            }
        }
    }

    private void drawRuler(Canvas c, int W, Project p) {
        fill.setColor(Theme.SURFACE);
        c.drawRect(0, 0, W, rulerH, fill);
        text.setTextAlign(Paint.Align.LEFT);
        float barPx = Project.BAR * pxPerStep;
        int every = barPx < ui.dp(22) ? 8 : barPx < ui.dp(44) ? 4 : barPx < ui.dp(80) ? 2 : 1;
        int songEnd = p.songSteps();
        for (int b = (int) Math.max(0, Math.floor(step(headW) / Project.BAR)); b * Project.BAR <= step(W); b++) {
            float xx = x((double) b * Project.BAR);
            if (xx < headW - 1) continue;
            if (b % every == 0) {
                line.setColor(0xFF4A4068);
                c.drawLine(xx, rulerH * 0.4f, xx, rulerH, line);
                text.setColor(b * Project.BAR < songEnd ? Theme.TEXT : Theme.MUTED);
                c.drawText(String.valueOf(b + 1), xx + ui.dp(3), rulerH - ui.dp(8), text);
            }
        }
        // конец песни
        float ex = x(songEnd);
        if (songEnd > 0 && ex > headW) {
            fill.setColor(Theme.ACCENT);
            c.drawRect(ex - ui.dp(1), 0, ex + ui.dp(1), rulerH, fill);
        }
        fill.setColor(Theme.SURFACE);
        c.drawRect(0, 0, headW, rulerH, fill);
        if (s.playing() && s.engine.songMode) {
            float px = x(s.position() / Project.STEP);
            if (px >= headW) {
                path.reset();
                path.moveTo(px - ui.dp(5), 0);
                path.lineTo(px + ui.dp(5), 0);
                path.lineTo(px, ui.dp(7));
                path.close();
                fill.setColor(Theme.ACCENT2);
                c.drawPath(path, fill);
            }
        }
    }

    // ================================================================== касания

    private static final int NONE = 0, PINCH = 1, RULER = 2, PAN = 3, CLIP_PENDING = 4, MOVE = 5, RESIZE = 6, EMPTY_PENDING = 7, ADD_TRACK = 8;
    private int mode;
    private float downX, downY, lastX, lastY, pSpan, pFoc;
    private Project.Clip grabbed;
    private int oStart, oTrack, oLen;
    private boolean changed;

    private Project.Clip hit(float x, float y) {
        if (y < rulerH || x < headW) return null;
        int t = track(y);
        double st = step(x);
        for (int i = s.p.clips.size() - 1; i >= 0; i--) {
            Project.Clip cl = s.p.clips.get(i);
            if (cl.track == t && st >= cl.start && st <= cl.end() + ui.dp(6) / pxPerStep) return cl;
        }
        return null;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        float x = e.getX(), y = e.getY();
        if (act == MotionEvent.ACTION_POINTER_DOWN && e.getPointerCount() == 2) {
            if (mode != MOVE && mode != RESIZE) {
                mode = PINCH;
                pSpan = Math.abs(e.getX(0) - e.getX(1));
                pFoc = (e.getX(0) + e.getX(1)) / 2;
            }
            return true;
        }
        if (mode == PINCH) {
            if (act == MotionEvent.ACTION_MOVE && e.getPointerCount() >= 2) {
                float sp = Math.abs(e.getX(0) - e.getX(1)), f = (e.getX(0) + e.getX(1)) / 2;
                double at = step(pFoc);
                if (pSpan > ui.dp(40) && sp > ui.dp(40)) pxPerStep *= sp / pSpan;
                clamp();
                scrollX = (float) (at - (f - headW) / pxPerStep);
                clamp();
                pSpan = sp;
                pFoc = f;
                invalidate();
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                mode = NONE;
            }
            return true;
        }
        switch (act) {
            case MotionEvent.ACTION_DOWN:
                getParent().requestDisallowInterceptTouchEvent(true);
                downX = lastX = x;
                downY = lastY = y;
                changed = false;
                grabbed = null;
                if (y < rulerH) {
                    mode = RULER;
                } else if (x < headW) {
                    mode = track(y) == s.p.tracks ? ADD_TRACK : PAN;
                } else {
                    Project.Clip cl = hit(x, y);
                    if (cl != null) {
                        grabbed = cl;
                        oStart = cl.start;
                        oTrack = cl.track;
                        oLen = cl.len;
                        float edge = x(cl.end());
                        mode = cl == selected && x > edge - ui.dp(22) ? RESIZE : CLIP_PENDING;
                    } else {
                        mode = EMPTY_PENDING;
                    }
                }
                return true;
            case MotionEvent.ACTION_MOVE: {
                boolean far = Math.abs(x - downX) > slop || Math.abs(y - downY) > slop;
                if ((mode == RULER || mode == EMPTY_PENDING) && far) mode = PAN;
                if (mode == CLIP_PENDING && far) {
                    s.checkpoint();
                    changed = true;
                    selected = grabbed;
                    host.onClipSelected(grabbed);
                    mode = MOVE;
                }
                if (mode == PAN) {
                    scrollX -= (x - lastX) / pxPerStep;
                    scrollY -= y - lastY;
                    clamp();
                } else if (mode == MOVE && grabbed != null) {
                    int g = grid();
                    int ns = (int) Math.max(0, Math.round((oStart + (x - downX) / pxPerStep) / g) * g);
                    int nt = Math.max(0, Math.min(s.p.tracks - 1, oTrack + Math.round((y - downY) / trackH)));
                    if (ns != grabbed.start || nt != grabbed.track) {
                        grabbed.start = ns;
                        grabbed.track = nt;
                        s.rebuild();
                    }
                } else if (mode == RESIZE && grabbed != null) {
                    if (!changed) {
                        s.checkpoint();
                        changed = true;
                    }
                    int g = Math.min(grid(), Math.max(1, patternSteps(grabbed)));
                    int end = (int) Math.round(step(x) / g) * g;
                    int len = Math.max(g, end - grabbed.start);
                    if (len != grabbed.len) {
                        grabbed.len = len;
                        s.rebuild();
                    }
                }
                lastX = x;
                lastY = y;
                invalidate();
                return true;
            }
            case MotionEvent.ACTION_UP:
                if (mode == RULER) {
                    double st = Math.max(0, step(x));
                    s.engine.seek(Math.floor(st / Project.BAR) * Project.BAR * Project.STEP);
                    if (!s.p.songMode) s.setSongMode(true);
                } else if (mode == CLIP_PENDING && grabbed != null) {
                    selected = grabbed == selected ? null : grabbed;
                    host.onClipSelected(selected);
                } else if (mode == EMPTY_PENDING) {
                    if (selected != null) {
                        selected = null;
                        host.onClipSelected(null);
                    } else {
                        place(x, y);
                    }
                } else if (mode == ADD_TRACK) {
                    s.checkpoint();
                    s.p.tracks = Math.min(64, s.p.tracks + 1);
                    s.tweaked();
                }
                if (changed) s.edited();
                mode = NONE;
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
                if (changed) s.edited();
                mode = NONE;
                return true;
            default:
                return true;
        }
    }

    private int patternSteps(Project.Clip cl) {
        Project.Pattern pt = s.p.pattern(cl.pattern);
        return pt == null ? Project.BAR : pt.steps;
    }

    private void place(float x, float y) {
        Project.Pattern pt = host.brush();
        int t = track(y);
        if (pt == null || t < 0 || t >= s.p.tracks) return;
        int g = grid();
        int st = (int) Math.max(0, Math.floor(step(x) / g) * g);
        s.checkpoint();
        Project.Clip cl = new Project.Clip(pt.id, t, st, Math.max(1, pt.steps));
        s.p.clips.add(cl);
        if (!s.p.songMode) s.setSongMode(true);
        s.edited();
        if (s.prefs.vibrate()) performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
    }

    // ================================================================== действия

    void deleteSelected() {
        if (selected == null) return;
        s.checkpoint();
        s.p.clips.remove(selected);
        selected = null;
        s.edited();
        host.onClipSelected(null);
        invalidate();
    }

    void muteSelected() {
        if (selected == null) return;
        s.checkpoint();
        selected.mute = !selected.mute;
        s.edited();
        invalidate();
    }

    void duplicateSelected() {
        if (selected == null) return;
        s.checkpoint();
        Project.Clip c = new Project.Clip(selected.pattern, selected.track, selected.end(), selected.len);
        s.p.clips.add(c);
        selected = c;
        s.edited();
        host.onClipSelected(c);
        invalidate();
    }

    /** Сделать копию паттерна только для этого клипа. */
    Project.Pattern makeUnique() {
        if (selected == null) return null;
        Project.Pattern pt = s.p.pattern(selected.pattern);
        if (pt == null) return null;
        s.checkpoint();
        Project.Pattern copy = pt.copy();
        copy.name = pt.name + " (копия)";
        s.p.patterns.add(copy);
        selected.pattern = copy.id;
        s.edited();
        invalidate();
        return copy;
    }

    /** Сколько раз каждый паттерн стоит в плейлисте. */
    static int uses(Project p, String patternId) {
        int n = 0;
        for (Project.Clip c : p.clips) if (c.pattern.equals(patternId)) n++;
        return n;
    }

    static int countNotes(Project.Pattern pt) {
        int n = 0;
        for (Map.Entry<String, List<Project.Note>> e : pt.notes.entrySet()) n += e.getValue().size();
        return n;
    }
}
