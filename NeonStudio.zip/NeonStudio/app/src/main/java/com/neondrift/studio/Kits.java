package com.neondrift.studio;

import java.util.HashMap;
import java.util.Map;

/**
 * Встроенные звуки — синтезируются при первом обращении, без чужих записей.
 * Каждый звук: id, название, категория и функция-генератор.
 */
final class Kits {
    private Kits() {}

    static final String PREFIX = "builtin:";

    static final String[][] SOUNDS = {
            // id, название, категория
            {"kick_memphis", "Бочка Memphis", "Бочки"},
            {"kick_drift", "Бочка Drift (грязная)", "Бочки"},
            {"kick_boom", "Бочка Boom", "Бочки"},
            {"kick_funk", "Бочка Funk", "Бочки"},
            {"kick_tight", "Бочка плотная", "Бочки"},
            {"b808_clean", "808 чистый", "808"},
            {"b808_dist", "808 перегруз", "808"},
            {"snare_memphis", "Малый Memphis", "Малые"},
            {"snare_crunch", "Малый хрустящий", "Малые"},
            {"snare_funk", "Малый Funk", "Малые"},
            {"clap_phonk", "Клэп Phonk", "Клэпы"},
            {"clap_tight", "Клэп короткий", "Клэпы"},
            {"snap", "Щелчок", "Клэпы"},
            {"hat_closed", "Хэт закрытый", "Хэты"},
            {"hat_open", "Хэт открытый", "Хэты"},
            {"hat_trap", "Хэт короткий", "Хэты"},
            {"shaker", "Шейкер", "Хэты"},
            {"cowbell_808", "Ковбелл 808", "Ковбелл"},
            {"cowbell_drift", "Ковбелл Drift", "Ковбелл"},
            {"bell_memphis", "Колокол Memphis", "Ковбелл"},
            {"rim", "Римшот", "Перкуссия"},
            {"tom_low", "Том низкий", "Перкуссия"},
            {"tom_high", "Том высокий", "Перкуссия"},
            {"conga", "Конга", "Перкуссия"},
            {"bongo", "Бонго", "Перкуссия"},
            {"tambourine", "Бубен", "Перкуссия"},
            {"crash", "Крэш", "Тарелки"},
            {"ride", "Райд", "Тарелки"},
            {"vinyl", "Треск винила (петля)", "Эффекты"},
            {"riser", "Подъём", "Эффекты"},
            {"impact", "Удар-падение", "Эффекты"},
            {"rev_crash", "Обратная тарелка", "Эффекты"},
    };

    private static final Map<String, Sample> cache = new java.util.concurrent.ConcurrentHashMap<>();

    static String name(String id) {
        for (String[] s : SOUNDS) if (s[0].equals(id)) return s[1];
        return id;
    }

    static String category(String id) {
        for (String[] s : SOUNDS) if (s[0].equals(id)) return s[2];
        return "";
    }

    /** Только уже готовый звук, без синтеза. */
    static Sample peek(String ref, int sr) {
        String id = ref.startsWith(PREFIX) ? ref.substring(PREFIX.length()) : ref;
        return cache.get(id + "@" + sr);
    }

    /** Звук по ссылке «builtin:id» или просто id. */
    static synchronized Sample get(String ref, int sr) {
        String id = ref.startsWith(PREFIX) ? ref.substring(PREFIX.length()) : ref;
        String key = id + "@" + sr;
        Sample s = cache.get(key);
        if (s != null) return s;
        float[] d = make(id, sr);
        if (d == null) return null;
        normalize(d, id.startsWith("vinyl") ? 0.45f : 0.9f);
        s = new Sample(PREFIX + id, name(id), d, null, sr);
        s.category = category(id);
        s.root = id.startsWith("b808") ? 36 : id.startsWith("cowbell") || id.startsWith("bell") ? 72 : 60;
        cache.put(key, s);
        return s;
    }

    static void normalize(float[] d, float peak) {
        float m = 0;
        for (float v : d) m = Math.max(m, Math.abs(v));
        if (m < 1e-6f) return;
        float g = peak / m;
        for (int i = 0; i < d.length; i++) d[i] *= g;
    }

    // ================================================================== генераторы

    private static float[] make(String id, int sr) {
        switch (id) {
            case "kick_memphis": return kick(sr, 0.6f, 160, 48, 0.035f, 0.18f, 1.6f, 0.35f);
            case "kick_drift": return crunch(kick(sr, 0.7f, 170, 45, 0.04f, 0.2f, 3.6f, 0.3f), 10, 1);
            case "kick_boom": return kick(sr, 1.0f, 140, 42, 0.06f, 0.45f, 2.2f, 0.2f);
            case "kick_funk": return kick(sr, 0.4f, 185, 55, 0.02f, 0.12f, 1.25f, 0.55f);
            case "kick_tight": return kick(sr, 0.3f, 260, 60, 0.012f, 0.08f, 1.5f, 0.5f);
            case "b808_clean": return bass808(sr, 2.6f, 0.9f, 1.4f);
            case "b808_dist": return crunch(bass808(sr, 2.2f, 0.65f, 4f), 12, 1);
            case "snare_memphis": return crunch(snare(sr, 0.45f, 185, 0.05f, 0.13f, 3000, 2.2f), 16, 2);
            case "snare_crunch": return crunch(snare(sr, 0.55f, 175, 0.06f, 0.18f, 2600, 4f), 8, 2);
            case "snare_funk": return snare(sr, 0.3f, 205, 0.04f, 0.085f, 3800, 1.4f);
            case "clap_phonk": return clap(sr, 4, 0.16f, 1300);
            case "clap_tight": return clap(sr, 3, 0.07f, 1600);
            case "snap": return clap(sr, 2, 0.03f, 2200);
            case "hat_closed": return hat(sr, 0.15f, 0.032f, 7200);
            case "hat_open": return hat(sr, 0.7f, 0.26f, 6800);
            case "hat_trap": return hat(sr, 0.08f, 0.012f, 8000);
            case "shaker": return shaker(sr);
            case "cowbell_808": return cowbell(sr, 0.7f, 0.22f, 1f, 0f);
            case "cowbell_drift": return cowbell(sr, 0.9f, 0.34f, 3.2f, 7f);
            case "bell_memphis": return fmBell(sr);
            case "rim": return rim(sr);
            case "tom_low": return tom(sr, 0.55f, 92, 40, 0.25f);
            case "tom_high": return tom(sr, 0.45f, 165, 60, 0.18f);
            case "conga": return tom(sr, 0.35f, 330, 60, 0.12f);
            case "bongo": return tom(sr, 0.25f, 480, 80, 0.08f);
            case "tambourine": return tambourine(sr);
            case "crash": return cymbal(sr, 2.2f, 1.0f, 4200, 0.5f);
            case "ride": return cymbal(sr, 2.0f, 0.9f, 6500, 0.2f);
            case "vinyl": return vinyl(sr);
            case "riser": return riser(sr);
            case "impact": return impact(sr);
            case "rev_crash": return reverse(cymbal(sr, 1.6f, 0.7f, 4200, 0.5f));
            default: return null;
        }
    }

    private static float[] buf(int sr, float sec) {
        return new float[(int) (sr * sec)];
    }

    private static float exp(float t, float tau) {
        return (float) Math.exp(-t / tau);
    }

    /** Бочка: синус с падением высоты, щелчок атаки и насыщение. */
    private static float[] kick(int sr, float len, float f0, float f1, float pitchTau, float ampTau, float sat, float click) {
        float[] d = buf(sr, len);
        double ph = 0;
        Dsp.Svf hp = new Dsp.Svf();
        hp.set(2500, 0.1f, sr);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            double f = f1 + (f0 - f1) * exp(t, pitchTau);
            ph += f / sr;
            float a = Math.min(1f, t / 0.001f) * exp(t, ampTau);
            float s = Dsp.sin01(ph) * a;
            hp.process(Dsp.noise());
            s += hp.high * click * exp(t, 0.0025f);
            d[i] = Dsp.soft(s * sat);
        }
        return fadeOut(d, sr, 0.02f);
    }

    /** 808: синус с подъёмом высоты в атаке, длинный спад, насыщение. Нота C2. */
    private static float[] bass808(int sr, float len, float tau, float sat) {
        float[] d = buf(sr, len);
        double ph = 0, base = Dsp.midiToHz(36);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            double f = base * Dsp.semis(12 * exp(t, 0.03f));
            ph += f / sr;
            float a = Math.min(1f, t / 0.0015f) * exp(t, tau);
            d[i] = Dsp.soft(Dsp.sin01(ph) * a * sat) / Math.min(1f, Dsp.soft(sat));
        }
        return fadeOut(d, sr, 0.05f);
    }

    private static float[] snare(int sr, float len, float tone, float toneTau, float noiseTau, float bp, float sat) {
        float[] d = buf(sr, len);
        double p1 = 0, p2 = 0;
        Dsp.Svf f = new Dsp.Svf(), hp = new Dsp.Svf();
        f.set(bp, 0.3f, sr);
        hp.set(900, 0.1f, sr);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            p1 += tone * (1 + 0.5f * exp(t, 0.01f)) / sr;
            p2 += tone * 1.78 / sr;
            float body = (Dsp.sin01(p1) * 0.65f + Dsp.sin01(p2) * 0.3f) * exp(t, toneTau);
            float n = Dsp.noise();
            f.process(n);
            hp.process(n);
            float nz = (f.band * 1.4f + hp.high * 0.5f) * exp(t, noiseTau);
            d[i] = Dsp.soft((body * 0.6f + nz * 0.8f) * sat);
        }
        return fadeOut(d, sr, 0.02f);
    }

    private static float[] clap(int sr, int bursts, float tail, float bp) {
        float[] d = buf(sr, 0.12f + tail * 3f);
        Dsp.Svf f = new Dsp.Svf(), hp = new Dsp.Svf();
        f.set(bp, 0.25f, sr);
        hp.set(500, 0.1f, sr);
        float gap = 0.0095f, last = gap * (bursts - 1);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            float e = 0;
            for (int b = 0; b < bursts; b++) {
                float tb = t - b * gap;
                if (tb >= 0) e = Math.max(e, exp(tb, 0.0055f) * (b == bursts - 1 ? 1f : 0.85f));
            }
            float tt = t - last;
            if (tt >= 0) e = Math.max(e, 0.55f * exp(tt, tail));
            float n = Dsp.noise();
            f.process(n);
            hp.process(f.band);
            d[i] = Dsp.soft(hp.high * e * 2.2f);
        }
        return fadeOut(d, sr, 0.03f);
    }

    private static final float[] METAL = {205.3f, 304.4f, 369.6f, 522.7f, 540f, 800f};

    /** Хэт как в TR-808: шесть «металлических» меандров через фильтры. */
    private static float[] hat(int sr, float len, float tau, float hpf) {
        float[] d = buf(sr, len);
        double[] ph = new double[6];
        Dsp.Svf hp = new Dsp.Svf(), bp = new Dsp.Svf(), nz = new Dsp.Svf();
        hp.set(hpf, 0.2f, sr);
        bp.set(10000, 0.15f, sr);
        nz.set(9000, 0.1f, sr);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            float s = 0;
            for (int k = 0; k < 6; k++) {
                double dt = METAL[k] * 1.7 / sr;
                s += Dsp.wave(Dsp.SQUARE, ph[k], dt);
                ph[k] += dt;
                if (ph[k] >= 1) ph[k] -= 1;
            }
            hp.process(s / 6f);
            bp.process(hp.high);
            nz.process(Dsp.noise());
            float e = Math.min(1f, t / 0.0008f) * exp(t, tau);
            d[i] = (bp.band * 1.6f + hp.high * 0.4f + nz.high * 0.35f) * e;
        }
        return fadeOut(d, sr, 0.01f);
    }

    private static float[] shaker(int sr) {
        float[] d = buf(sr, 0.2f);
        Dsp.Svf f = new Dsp.Svf();
        f.set(6500, 0.3f, sr);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            float e = t < 0.012f ? t / 0.012f : exp(t - 0.012f, 0.045f);
            f.process(Dsp.noise());
            d[i] = f.band * e;
        }
        return fadeOut(d, sr, 0.01f);
    }

    /** Ковбелл 808: два меандра (соотношение 1 : 1,44) через полосовой фильтр, двухступенчатый спад. Нота C5. */
    private static float[] cowbell(int sr, float len, float tail, float sat, float detuneCents) {
        float[] d = buf(sr, len);
        double f1 = Dsp.midiToHz(72), f2 = f1 * 1.4395 * Dsp.semis(detuneCents / 100.0);
        double p1 = 0, p2 = 0;
        Dsp.Svf bp = new Dsp.Svf(), lp = new Dsp.Svf();
        bp.set(1700, 0.3f, sr);
        lp.set(5000, 0.05f, sr);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            double dt1 = f1 / sr, dt2 = f2 / sr;
            float s = Dsp.wave(Dsp.SQUARE, p1, dt1) + Dsp.wave(Dsp.SQUARE, p2, dt2);
            p1 += dt1;
            if (p1 >= 1) p1 -= 1;
            p2 += dt2;
            if (p2 >= 1) p2 -= 1;
            bp.process(s);
            lp.process(bp.band * 1.3f + s * 0.25f);
            float e = Math.min(1f, t / 0.0007f) * (0.6f * exp(t, 0.014f) + 0.4f * exp(t, tail));
            d[i] = Dsp.soft(lp.low * e * sat) / Math.min(1f, Dsp.soft(sat));
        }
        return fadeOut(d, sr, 0.03f);
    }

    /** Тёмный колокол: частотная модуляция с затухающим индексом. Нота C5. */
    private static float[] fmBell(int sr) {
        float[] d = buf(sr, 2.2f);
        double f = Dsp.midiToHz(72), pc = 0, pm = 0;
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            float idx = 3.5f * exp(t, 0.5f) + 0.4f;
            float m = Dsp.sin01(pm) * idx;
            float s = Dsp.sin01(pc + m * 0.16f);
            pc += f / sr;
            pm += f * 3.5 / sr;
            d[i] = s * Math.min(1f, t / 0.002f) * exp(t, 0.9f);
        }
        return fadeOut(d, sr, 0.05f);
    }

    private static float[] rim(int sr) {
        float[] d = buf(sr, 0.12f);
        double p1 = 0, p2 = 0;
        Dsp.Svf bp = new Dsp.Svf();
        bp.set(3200, 0.3f, sr);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            p1 += 1700.0 / sr;
            p2 += 480.0 / sr;
            bp.process(Dsp.noise());
            d[i] = Dsp.sin01(p1) * exp(t, 0.008f) * 0.7f + Dsp.sin01(p2) * exp(t, 0.02f) * 0.5f + bp.band * exp(t, 0.004f);
        }
        return fadeOut(d, sr, 0.01f);
    }

    private static float[] tom(int sr, float len, float f0, float drop, float tau) {
        float[] d = buf(sr, len);
        double ph = 0;
        Dsp.Svf lp = new Dsp.Svf();
        lp.set(2000, 0.1f, sr);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            ph += (f0 + drop * exp(t, 0.03f)) / sr;
            lp.process(Dsp.noise());
            float s = Dsp.sin01(ph) + Dsp.sin01(ph * 2.02) * 0.15f;
            d[i] = Dsp.soft((s * exp(t, tau) + lp.low * 0.2f * exp(t, 0.01f)) * 1.3f);
        }
        return fadeOut(d, sr, 0.02f);
    }

    private static float[] tambourine(int sr) {
        float[] d = buf(sr, 0.4f);
        double[] ph = new double[3];
        float[] fr = {4200, 5650, 7300};
        Dsp.Svf bp = new Dsp.Svf(), hp = new Dsp.Svf();
        bp.set(7000, 0.4f, sr);
        hp.set(5000, 0.1f, sr);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            float s = 0;
            for (int k = 0; k < 3; k++) {
                s += Dsp.sin01(ph[k]);
                ph[k] += fr[k] / sr;
            }
            bp.process(Dsp.noise());
            hp.process(s / 3f);
            float e = (t < 0.004f ? t / 0.004f : 1f) * exp(t, 0.11f);
            d[i] = (bp.band * 0.9f + hp.high * 0.5f) * e;
        }
        return fadeOut(d, sr, 0.02f);
    }

    private static float[] cymbal(int sr, float len, float tau, float hpf, float noiseMix) {
        float[] d = buf(sr, len);
        double[] ph = new double[6];
        Dsp.Svf hp = new Dsp.Svf(), nz = new Dsp.Svf();
        hp.set(hpf, 0.15f, sr);
        nz.set(hpf + 1500, 0.1f, sr);
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            float s = 0;
            for (int k = 0; k < 6; k++) {
                double dt = METAL[k] * 3.1 / sr;
                s += Dsp.wave(Dsp.SQUARE, ph[k], dt);
                ph[k] += dt;
                if (ph[k] >= 1) ph[k] -= 1;
            }
            hp.process(s / 6f);
            nz.process(Dsp.noise());
            float e = Math.min(1f, t / 0.004f) * exp(t, tau);
            d[i] = (hp.high * (1 - noiseMix) + nz.high * noiseMix * 1.2f) * e;
        }
        return fadeOut(d, sr, 0.1f);
    }

    /** Треск пластинки: редкие щелчки и тихое шипение. Петля 4 секунды. */
    private static float[] vinyl(int sr) {
        float[] d = buf(sr, 4f);
        java.util.Random r = new java.util.Random(77);
        Dsp.Svf lp = new Dsp.Svf(), hp = new Dsp.Svf();
        lp.set(3800, 0.05f, sr);
        hp.set(1200, 0.1f, sr);
        float pop = 0;
        for (int i = 0; i < d.length; i++) {
            if (r.nextFloat() < 0.0007f) pop = (r.nextFloat() * 0.8f + 0.2f) * (r.nextBoolean() ? 1 : -1);
            pop *= 0.82f;
            lp.process(Dsp.noise());
            hp.process(pop);
            d[i] = lp.low * 0.03f + hp.high;
        }
        return d;
    }

    private static float[] riser(int sr) {
        float[] d = buf(sr, 2f);
        Dsp.Svf bp = new Dsp.Svf();
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr, k = t / 2f;
            if ((i & 31) == 0) bp.set((float) (300 * Math.pow(8000 / 300.0, k)), 0.55f, sr);
            bp.process(Dsp.noise());
            d[i] = bp.band * k * k;
        }
        return fadeOut(d, sr, 0.03f);
    }

    private static float[] impact(int sr) {
        float[] d = buf(sr, 1.6f);
        double ph = 0;
        Dsp.Svf lp = new Dsp.Svf();
        for (int i = 0; i < d.length; i++) {
            float t = i / (float) sr;
            ph += (32 + 40 * exp(t, 0.15f)) / sr;
            if ((i & 31) == 0) lp.set(200 + 6000 * exp(t, 0.12f), 0.2f, sr);
            lp.process(Dsp.noise());
            d[i] = Dsp.soft((Dsp.sin01(ph) * exp(t, 0.55f) + lp.low * 0.6f * exp(t, 0.25f)) * 1.8f);
        }
        return fadeOut(d, sr, 0.1f);
    }

    private static float[] reverse(float[] d) {
        float[] r = new float[d.length];
        for (int i = 0; i < d.length; i++) r[i] = d[d.length - 1 - i];
        return r;
    }

    /** Огрубление: биты и прореживание — «плёночный» Memphis-звук. */
    private static float[] crunch(float[] d, int bits, int hold) {
        float q = (float) Math.pow(2, bits - 1);
        float h = 0;
        for (int i = 0; i < d.length; i++) {
            if (i % hold == 0) h = Math.round(d[i] * q) / q;
            d[i] = h;
        }
        return d;
    }

    private static float[] fadeOut(float[] d, int sr, float sec) {
        int n = Math.min(d.length, (int) (sr * sec));
        for (int i = 0; i < n; i++) d[d.length - 1 - i] *= i / (float) n;
        return d;
    }
}
