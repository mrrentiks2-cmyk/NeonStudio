package com.neondrift.studio;

/** Лады, аккорды и названия нот. */
final class Theory {
    private Theory() {}

    static final String[] KEYS = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    static final String[] SCALE_NAMES = {"Мажор", "Минор", "Фригийский (фонк)", "Гармонический минор", "Дорийский (фанк)",
            "Миксолидийский", "Минорная пентатоника", "Блюз", "Все ноты"};
    static final int[][] SCALES = {
            {0, 2, 4, 5, 7, 9, 11},
            {0, 2, 3, 5, 7, 8, 10},
            {0, 1, 3, 5, 7, 8, 10},
            {0, 2, 3, 5, 7, 8, 11},
            {0, 2, 3, 5, 7, 9, 10},
            {0, 2, 4, 5, 7, 9, 10},
            {0, 3, 5, 7, 10},
            {0, 3, 5, 6, 7, 10},
            {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11},
    };

    static int[] scale(int idx) {
        return SCALES[idx >= 0 && idx < SCALES.length ? idx : 1];
    }

    static boolean inScale(int key, int root, int scaleIdx) {
        int pc = Math.floorMod(key - root, 12);
        for (int s : scale(scaleIdx)) if (s == pc) return true;
        return false;
    }

    /** Нота ступени лада (ступень может уходить за октаву в обе стороны). */
    static int degree(int root, int scaleIdx, int deg, int octave) {
        int[] sc = scale(scaleIdx);
        int n = sc.length;
        int oct = Math.floorDiv(deg, n), d = Math.floorMod(deg, n);
        return 12 * (octave + 1) + root + sc[d] + 12 * oct;
    }

    /** Ближайшая нота лада. */
    static int snap(int key, int root, int scaleIdx) {
        for (int d = 0; d < 12; d++) {
            if (inScale(key - d, root, scaleIdx)) return key - d;
            if (inScale(key + d, root, scaleIdx)) return key + d;
        }
        return key;
    }

    /** Аккорд терциями по ладу: size звуков от ступени deg. */
    static int[] chord(int root, int scaleIdx, int deg, int size, int octave) {
        int[] out = new int[size];
        for (int i = 0; i < size; i++) out[i] = degree(root, scaleIdx, deg + 2 * i, octave);
        return out;
    }

    /** Аккорд лада от ноты key (нота сначала притягивается к ладу). */
    static int[] diatonic(int key, int root, int scaleIdx, int size) {
        int k = snap(key, root, scaleIdx);
        int pc = Math.floorMod(k - root, 12);
        int[] sc = scale(scaleIdx);
        int deg = 0;
        for (int i = 0; i < sc.length; i++) if (sc[i] == pc) deg = i;
        return chord(root, scaleIdx, deg, size, Math.floorDiv(k - root, 12) - 1);
    }

    static String name(int key) {
        return KEYS[Math.floorMod(key, 12)] + (Math.floorDiv(key, 12) - 1);
    }

    static boolean black(int key) {
        int pc = Math.floorMod(key, 12);
        return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10;
    }

    /** Типы аккордов для «штампа» в пианоролле: интервалы от основного тона. */
    static final String[] CHORD_NAMES = {"Нота", "Минор", "Мажор", "Мин7", "Мин9", "Маж7", "Дом7", "Sus2", "Sus4", "Квинта", "Октава"};
    static final int[][] CHORDS = {{0}, {0, 3, 7}, {0, 4, 7}, {0, 3, 7, 10}, {0, 3, 7, 10, 14}, {0, 4, 7, 11}, {0, 4, 7, 10},
            {0, 2, 7}, {0, 5, 7}, {0, 7}, {0, 12}};
}
