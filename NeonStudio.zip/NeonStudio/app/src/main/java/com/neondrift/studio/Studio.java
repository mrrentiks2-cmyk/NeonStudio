package com.neondrift.studio;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Сердце студии без интерфейса: проект, движок, вывод звука, история правок,
 * фоновая загрузка звуков, автосохранение и запись с пэдов.
 */
final class Studio {
    interface Listener {
        /** Проект заменён целиком (отмена, повтор) — перестроить всё. */
        void onProjectReplaced();

        /** Ноты, паттерны или каналы изменились. */
        void onContentChanged();

        /** Догрузились звуки — обновить подписи и формы волн. */
        void onSoundsLoaded();
    }

    final Context ctx;
    final Handler main = new Handler(Looper.getMainLooper());
    final int rate, block;
    final Engine engine;
    final AudioOut out;
    final Prefs prefs;
    Project p;
    String sel = "";                    // выбранный канал
    Listener listener;

    private final ArrayDeque<String> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
    private static final int HISTORY = 80;
    private final ExecutorService loader = Executors.newSingleThreadExecutor();
    private final ExecutorService saver = Executors.newSingleThreadExecutor();
    private final Set<String> pending = new HashSet<>(), failed = new HashSet<>();
    private final Runnable autosave = this::saveNow;
    private boolean dirty;

    Studio(Context c, Project p) {
        ctx = c.getApplicationContext();
        prefs = new Prefs(c);
        rate = AudioOut.nativeRate(c);
        block = AudioOut.nativeBlock(c);
        engine = new Engine(rate, Math.max(512, block));
        out = new AudioOut(engine, rate, block);
        setProject(p);
    }

    private void setProject(Project np) {
        p = np;
        np.current();
        if (p.channel(sel) == null) sel = p.channels.isEmpty() ? "" : p.channels.get(0).id;
        syncTransport();
        rebuild();
    }

    void syncTransport() {
        engine.bpm = p.bpm;
        engine.metronome = p.metronome || recording;
        engine.songMode = p.songMode && !recording;
        engine.loop = p.loop;
    }

    // ================================================================== выбор

    Project.Channel selected() {
        Project.Channel c = p.channel(sel);
        if (c == null && !p.channels.isEmpty()) {
            c = p.channels.get(0);
            sel = c.id;
        }
        return c;
    }

    void select(Project.Channel c) {
        if (c != null) sel = c.id;
    }

    // ================================================================== правки и история

    /** Запомнить состояние перед правкой (для «Отменить»). */
    void checkpoint() {
        undo.push(p.toJson());
        while (undo.size() > HISTORY) undo.removeLast();
        redo.clear();
    }

    boolean canUndo() {
        return !undo.isEmpty();
    }

    boolean canRedo() {
        return !redo.isEmpty();
    }

    boolean undo() {
        if (undo.isEmpty()) return false;
        redo.push(p.toJson());
        restore(undo.pop());
        return true;
    }

    boolean redo() {
        if (redo.isEmpty()) return false;
        undo.push(p.toJson());
        restore(redo.pop());
        return true;
    }

    private void restore(String json) {
        String id = p.id;
        Project np = Project.fromJson(json);
        np.id = id;
        setProject(np);
        scheduleSave();
        if (listener != null) listener.onProjectReplaced();
    }

    /** Ноты/каналы/паттерны изменились: пересобрать песню для движка и сохранить. */
    void edited() {
        rebuild();
        scheduleSave();
    }

    /** Ручка или ползунок: движок читает значение сам, пересборка не нужна. */
    void tweaked() {
        scheduleSave();
    }

    void rebuild() {
        HashSet<String> miss = new HashSet<>();
        Engine.Compiled c = engine.compile(p, Sounds.cached(rate, miss));
        engine.publish(c);
        for (String ref : miss) {
            if (failed.contains(ref) || !pending.add(ref)) continue;
            loader.execute(() -> {
                Sample s = Sounds.load(ctx, ref, rate);
                main.post(() -> {
                    pending.remove(ref);
                    if (s == null) failed.add(ref);
                    rebuild();
                    if (listener != null) listener.onSoundsLoaded();
                });
            });
        }
    }

    /** Звук ещё грузится? */
    boolean loading(String ref) {
        return pending.contains(ref);
    }

    /** Звук не найден или не читается? */
    boolean broken(String ref) {
        return failed.contains(ref);
    }

    void forgetFailures() {
        failed.clear();
    }

    /** Загрузить звук в фоне и отдать в главный поток. */
    void loadSound(String ref, java.util.function.Consumer<Sample> done) {
        Sample s = Sounds.peek(ref, rate);
        if (s != null) {
            done.accept(s);
            return;
        }
        loader.execute(() -> {
            Sample x = Sounds.load(ctx, ref, rate);
            main.post(() -> done.accept(x));
        });
    }

    void preview(String ref) {
        loadSound(ref, s -> {
            if (s != null) engine.preview(s);
        });
    }

    // ================================================================== сохранение

    void scheduleSave() {
        dirty = true;
        main.removeCallbacks(autosave);
        main.postDelayed(autosave, 1500);
    }

    void saveNow() {
        main.removeCallbacks(autosave);
        if (!dirty) return;
        dirty = false;
        if (p.created == 0) p.created = System.currentTimeMillis();
        p.edited = System.currentTimeMillis();
        String json = p.toJson(), id = p.id;
        saver.execute(() -> {
            try {
                ProjectStore.saveJson(ctx, id, json);
            } catch (java.io.IOException ignored) {
                main.post(() -> dirty = true);
            }
        });
        prefs.put("lastProject", id);
    }

    /** Сохранить сразу в этом потоке (при уходе с экрана, чтобы список проектов был свежим). */
    void saveSync() {
        main.removeCallbacks(autosave);
        if (!dirty) return;
        dirty = false;
        if (p.created == 0) p.created = System.currentTimeMillis();
        p.edited = System.currentTimeMillis();
        try {
            ProjectStore.saveJson(ctx, p.id, p.toJson());
        } catch (java.io.IOException e) {
            dirty = true;
        }
        prefs.put("lastProject", p.id);
    }

    void markDirty() {
        dirty = true;
    }

    // ================================================================== транспорт

    boolean playing() {
        return engine.playing;
    }

    void play() {
        engine.play();
    }

    void stop() {
        if (recording) stopRecording();
        engine.stop();
        engine.seek(0);
    }

    void togglePlay() {
        if (engine.playing) stop();
        else play();
    }

    void setSongMode(boolean song) {
        if (p.songMode == song) return;
        p.songMode = song;
        boolean was = engine.playing;
        engine.songMode = song && !recording;
        engine.seek(0);
        if (was) engine.play();
        tweaked();
    }

    /** Позиция воспроизведения в тиках. */
    double position() {
        return engine.position;
    }

    float latencyTicks() {
        return out.latencyMs() / 1000f * p.bpm / 60f * Project.PPQ;
    }

    // ================================================================== запись с пэдов

    boolean recording;
    private final HashMap<String, Project.Note> held = new HashMap<>();
    private final HashMap<String, Long> heldAt = new HashMap<>();

    void startRecording() {
        if (recording) return;
        checkpoint();
        recording = true;
        syncTransport();
        if (!engine.playing) {
            engine.seek(0);
            engine.play();
        }
    }

    void stopRecording() {
        if (!recording) return;
        recording = false;
        held.clear();
        heldAt.clear();
        syncTransport();
        edited();
        if (listener != null) listener.onContentChanged();
    }

    /** Нота с пэда или клавиш: звучит сразу, при записи — попадает в паттерн. */
    void live(Project.Channel ch, int key, float vel) {
        if (ch == null) return;
        engine.live(ch, key, vel);
        if (!recording || !engine.playing) return;
        Project.Pattern pt = p.current();
        int plen = pt.ticks();
        double now = engine.position - latencyTicks();
        int tick = (int) Math.floorMod((long) Math.round(now), (long) plen);
        String id = ch.id + ":" + key;
        if (vel > 0) {
            int start = tick;
            if (prefs.quantizeRec()) start = Math.floorMod(Math.round(tick / (float) Project.STEP) * Project.STEP, plen);
            List<Project.Note> list = pt.notes(ch.id);
            for (int i = list.size() - 1; i >= 0; i--) {
                Project.Note n = list.get(i);
                if (n.start == start && n.key == key) list.remove(i);
            }
            Project.Note n = new Project.Note(start, Project.STEP, key, Math.max(0.05f, Math.min(1f, vel)));
            list.add(n);
            held.put(id, n);
            heldAt.put(id, SystemClock.uptimeMillis());
            // если нота встала чуть впереди курсора — опубликовать после него, иначе прозвучит дважды
            double ahead = start - (engine.position % plen);
            if (ahead > 0 && ahead < Project.STEP * 2) {
                long ms = (long) (ahead / Project.PPQ * 60000f / p.bpm) + 15;
                main.postDelayed(this::rebuild, ms);
            } else {
                rebuild();
            }
            markDirty();
        } else {
            Project.Note n = held.remove(id);
            Long t0 = heldAt.remove(id);
            if (n == null || t0 == null) return;
            float ticks = (SystemClock.uptimeMillis() - t0) / 60000f * p.bpm * Project.PPQ;
            int len = Math.max(6, Math.round(ticks));
            if (prefs.quantizeRec()) len = Math.max(Project.STEP, Math.round(len / (float) Project.STEP) * Project.STEP);
            n.len = Math.min(len, plen);
        }
    }

    // ================================================================== ноты по умолчанию

    /** Высота новой ноты в шаговом секвенсоре. */
    int defaultKey(Project.Channel ch) {
        if (ch.type == Project.SAMPLER) return ch.root;
        if (ch.type == Project.BASS || "bass".equals(ch.role)) return p.key <= 4 ? 36 + p.key : 24 + p.key;
        return 60 + p.key;
    }

    /** Длина новой ноты в шагах. */
    int defaultLen(Project.Channel ch) {
        if (ch.type == Project.BASS) return Project.STEP * 4;
        if (ch.type == Project.SYNTH) return Project.STEP * 2;
        return Project.STEP;
    }

    void release() {
        saveSync();
        loader.shutdownNow();
        saver.shutdown();
        out.stop();
    }
}
