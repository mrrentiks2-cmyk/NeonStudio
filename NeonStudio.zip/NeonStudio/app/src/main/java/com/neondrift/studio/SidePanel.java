package com.neondrift.studio;

import android.content.res.ColorStateList;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/**
 * Выезжающая панель: справа в горизонтальной ориентации, снизу — в вертикальной.
 * Тап мимо панели закрывает её.
 */
final class SidePanel extends FrameLayout {
    interface Listener { void onPanelClosed(); }

    private final Ui ui;
    private final FrameLayout sheet;
    private final LinearLayout content;
    private final ScrollView scroll;
    private Listener listener;
    private boolean open;

    SidePanel(android.content.Context c, Ui ui) {
        super(c);
        this.ui = ui;
        setBackgroundColor(Theme.SCRIM);
        setClickable(true);
        setOnClickListener(v -> close());
        setVisibility(GONE);

        sheet = new FrameLayout(c);
        sheet.setClickable(true);
        scroll = new ScrollView(c);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setFillViewport(true);
        content = ui.col();
        content.setPadding(ui.dp(20), ui.dp(14), ui.dp(20), ui.dp(24));
        scroll.addView(content, new FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP));
        sheet.addView(scroll, new FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH));
        addView(sheet);
    }

    void setListener(Listener l) {
        listener = l;
    }

    boolean isOpen() {
        return open;
    }

    /** Открыть панель с заголовком и вернуть контейнер для содержимого. */
    LinearLayout open(String title) {
        content.removeAllViews();
        LinearLayout head = ui.row();
        TextView t = ui.text(title, 18, Theme.TEXT, true);
        head.addView(t, Ui.lp(0, Ui.WRAP, 1f));
        head.addView(ui.iconButton("close", Theme.MUTED, 40, 10, v -> close()));
        content.addView(head, Ui.margins(Ui.MATCH, Ui.WRAP, 0, 0, 0, ui.dp(6)));

        View parent = (View) getParent();
        int pw = parent != null ? parent.getWidth() : 0, ph = parent != null ? parent.getHeight() : 0;
        boolean side = pw > ph;
        FrameLayout.LayoutParams lp;
        if (side) {
            int w = Math.min(ui.dp(380), Math.max(ui.dp(300), Math.round(pw * 0.42f)));
            lp = new FrameLayout.LayoutParams(w, Ui.MATCH, Gravity.END);
            sheet.setBackground(Ui.round(Theme.PANEL, 0));
        } else {
            lp = new FrameLayout.LayoutParams(Ui.MATCH, Math.round(ph * 0.62f), Gravity.BOTTOM);
            sheet.setBackground(Ui.round(Theme.PANEL, ui.dp(22)));
        }
        sheet.setLayoutParams(lp);
        scroll.scrollTo(0, 0);
        setVisibility(VISIBLE);
        setAlpha(0f);
        animate().alpha(1f).setDuration(160).start();
        open = true;
        return content;
    }

    void close() {
        if (!open) return;
        open = false;
        animate().alpha(0f).setDuration(140).withEndAction(() -> setVisibility(GONE)).start();
        if (listener != null) listener.onPanelClosed();
    }

    // ------------------------------------------------------------------ строительные блоки

    void section(LinearLayout parent, String label) {
        parent.addView(ui.label(label), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(18), 0, ui.dp(8)));
    }

    TextView note(LinearLayout parent, String text) {
        TextView t = ui.text(text, 12, Theme.MUTED, false);
        t.setLineSpacing(0, 1.25f);
        parent.addView(t, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(8), 0, 0));
        return t;
    }

    /** Строка-вариант с галочкой у выбранного. */
    View option(LinearLayout parent, String text, String sub, boolean selected, Runnable onClick) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(12), ui.dp(11), ui.dp(8), ui.dp(11));
        row.setBackground(Ui.ripple(Ui.round(selected ? Theme.alpha(Theme.ACCENT, 38) : 0, ui.dp(12)),
                Ui.round(0xFFFFFFFF, ui.dp(12))));
        LinearLayout texts = ui.col();
        TextView t = ui.text(text, 15, selected ? Theme.TEXT : 0xFFD8D2EE, selected);
        t.setMaxLines(2);
        texts.addView(t);
        if (sub != null && !sub.isEmpty()) {
            texts.addView(ui.oneLine(sub, 12, Theme.MUTED, false), Ui.margins(Ui.WRAP, Ui.WRAP, 0, ui.dp(3), 0, 0));
        }
        row.addView(texts, Ui.lp(0, Ui.WRAP, 1f));
        if (selected) {
            ImageView ic = new ImageView(getContext());
            ic.setImageDrawable(new Glyph("check", Theme.ACCENT));
            row.addView(ic, Ui.lp(ui.dp(22), ui.dp(22)));
        }
        row.setOnClickListener(v -> onClick.run());
        parent.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(2), 0, 0));
        return row;
    }

    /** Горизонтальный ряд чипов. */
    LinearLayout chipRow(LinearLayout parent) {
        HorizontalScrollView hs = new HorizontalScrollView(getContext());
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = ui.row();
        hs.addView(row);
        parent.addView(hs, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(2), 0, ui.dp(4)));
        return row;
    }

    TextView chip(LinearLayout row, String text, boolean on, Runnable onClick) {
        TextView c = ui.chip(text, on, v -> onClick.run());
        LinearLayout.LayoutParams lp = Ui.lp(Ui.WRAP, Ui.WRAP);
        lp.rightMargin = ui.dp(8);
        row.addView(c, lp);
        return c;
    }

    /** «−  значение  +» — для задержек. Возвращает поле значения. */
    TextView stepper(LinearLayout parent, String label, String value, Runnable minus, Runnable plus, Runnable reset) {
        LinearLayout row = ui.row();
        row.setPadding(ui.dp(4), ui.dp(4), 0, ui.dp(4));
        row.addView(ui.text(label, 15, Theme.TEXT, false), Ui.lp(0, Ui.WRAP, 1f));
        row.addView(roundButton("minus", minus));
        TextView v = ui.text(value, 15, Theme.TEXT, true);
        v.setGravity(Gravity.CENTER);
        v.setOnClickListener(x -> reset.run());
        row.addView(v, Ui.lp(ui.dp(84), Ui.WRAP));
        row.addView(roundButton("plus", plus));
        parent.addView(row, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(4), 0, 0));
        return v;
    }

    private View roundButton(String icon, Runnable r) {
        ImageView b = ui.iconButton(icon, Theme.TEXT, 40, 11, v -> r.run());
        b.setBackground(Ui.ripple(Ui.oval(Theme.SURFACE2), Ui.oval(0xFFFFFFFF)));
        return b;
    }

    SeekBar slider(LinearLayout parent, int max, int progress, int color) {
        SeekBar s = new SeekBar(getContext());
        s.setMax(max);
        s.setProgress(progress);
        s.setProgressTintList(ColorStateList.valueOf(color));
        s.setThumbTintList(ColorStateList.valueOf(color));
        s.setProgressBackgroundTintList(ColorStateList.valueOf(0x55FFFFFF));
        s.setPadding(ui.dp(10), ui.dp(10), ui.dp(10), ui.dp(10));
        parent.addView(s, Ui.margins(Ui.MATCH, Ui.WRAP, 0, ui.dp(2), 0, 0));
        return s;
    }
}
