package com.neondrift.studio;

/**
 * Один голос: сэмплер, синтезатор или 808. Голоса заранее созданы и переиспользуются —
 * во время игры память не выделяется.
 */
final class Voice {
    Project.Channel ch;
    Engine.Strip strip;
    Sample smp;
    boolean active, held;
    long stamp;
    int key;
    float vel;

    private float sr;
    private int delay;
    private long remain;            // сэмплов до отпускания ноты (−1 — до конца звука)
    private double pitch, target, glideStep;
    private final Dsp.Adsr amp = new Dsp.Adsr();
    private float fadeGain = 1f, fadeStep;

    // сэмплер
    private double pos, inc, rateMul = 1;
    private int s0, s1;
    private boolean rev, pitched;
    private int mode;

    // синтезатор
    private double ph1, ph2, ph3;
    private final Dsp.Svf svf = new Dsp.Svf();
    private final Dsp.Adsr fenv = new Dsp.Adsr();
    private float fmEnv, fmCoef;
    private int ctr;
    private double dt1, dt2, dt3;

    // 808
    private float pEnv, pCoef, clickEnv, clickCoef;
    private double ph;

    /** Запустить ноту. delay — сдвиг начала внутри блока, len — длина ноты в сэмплах (≤0 — бесконечно). */
    void start(Project.Channel c, Engine.Strip st, Sample s, float[] marks, int k, float v, int delayFrames, long len, float rate, float bpm, long now) {
        ch = c;
        strip = st;
        smp = s;
        key = k;
        vel = v;
        sr = rate;
        delay = Math.max(0, delayFrames);
        remain = len > 0 ? len : -1;
        held = true;
        active = true;
        stamp = now;
        fadeGain = 1f;
        fadeStep = 0f;
        ctr = 0;
        switch (c.type) {
            case Project.SYNTH:
                startSynth(c);
                break;
            case Project.BASS:
                start808(c);
                break;
            default:
                if (!startSampler(c, s, marks, bpm)) active = false;
        }
    }

    // ================================================================== сэмплер

    private boolean startSampler(Project.Channel c, Sample s, float[] marks, float bpm) {
        if (s == null || s.frames() < 2) return false;
        int n = s.frames();
        int a = (int) (Dsp.clamp(c.start, 0f, 1f) * n), b = (int) (Dsp.clamp(c.end, 0f, 1f) * n);
        if (b <= a + 1) { a = 0; b = n; }
        pitched = true;
        if (marks != null && marks.length > 0) {
            int idx = Math.floorMod(key - c.root, marks.length);
            int len = b - a;
            s0 = a + (int) (marks[idx] * len);
            s1 = idx + 1 < marks.length ? a + (int) (marks[idx + 1] * len) : b;
            if (s1 <= s0 + 1) s1 = Math.min(b, s0 + 64);
            pitched = false;
        } else {
            s0 = a;
            s1 = b;
        }
        rev = c.reverse;
        mode = c.mode;
        pitch = pitched ? key - c.root + c.tune : c.tune;
        target = pitch;
        glideStep = 0;
        rateMul = s.rate / sr;
        if (c.fitBeats > 0.01f && bpm > 0) {
            // подгонка всей петли (не одного среза) под число долей
            double want = c.fitBeats * 60.0 / bpm, have = (b - a) / (double) s.rate;
            if (want > 0.01) rateMul *= have / want;
        }
        inc = Dsp.semis(pitch) * rateMul;
        pos = rev ? s1 - 1 : s0;
        amp.set(c.attack, c.decay, c.sustain, Math.max(0.005f, c.release), sr);
        amp.gate(true);
        return true;
    }

    // ================================================================== синтезатор

    private void startSynth(Project.Channel c) {
        pitch = key;
        target = key;
        glideStep = 0;
        if (Math.abs(ph1) > 1e6) ph1 = 0;
        ph1 = Math.random();
        ph2 = Math.random();
        ph3 = 0;
        svf.reset();
        amp.set(c.attack, c.decay, c.sustain, Math.max(0.005f, c.release), sr);
        amp.gate(true);
        fenv.set(c.fAttack, c.fDecay, c.fSustain, Math.max(0.005f, c.fRelease), sr);
        fenv.gate(true);
        fmEnv = 1f;
        fmCoef = Dsp.Adsr.coef(Math.max(0.01f, c.fmDecay), sr);
        updateFreqs(c);
    }

    private void updateFreqs(Project.Channel c) {
        double f = Dsp.midiToHz(pitch);
        dt1 = f / sr;
        dt2 = (c.fm > 0.001f ? f * c.fmRatio : f * Dsp.semis(c.osc2Semi + c.detune / 100.0)) / sr;
        dt3 = f * 0.5 / sr;
    }

    // ================================================================== 808

    private void start808(Project.Channel c) {
        pitch = key;
        target = key;
        glideStep = 0;
        ph = 0;
        pEnv = c.punch;
        pCoef = Dsp.Adsr.coef(Math.max(0.005f, c.punchTime), sr);
        clickEnv = c.click;
        clickCoef = Dsp.Adsr.coef(0.004f, sr);
        amp.set(0.0015f, Math.max(0.05f, c.decay808), 0f, 0.06f, sr);
        amp.gate(true);
    }

    // ================================================================== управление

    /** Плавный переход к новой ноте (слайд 808 и моно-синтов). */
    void glideTo(int k, float v, long len, float time) {
        key = k;
        vel = Math.max(vel, v * 0.9f);
        double t = ch.type == Project.SAMPLER ? (pitched ? k - ch.root + ch.tune : pitch) : k;
        target = t;
        glideStep = Math.abs(t - pitch) / Math.max(1, time * sr);
        if (len > 0) remain = len;
        else remain = -1;
        held = true;
        if (amp.stage == Dsp.Adsr.RELEASE) amp.gate(true);
    }

    void release() {
        held = false;
        amp.gate(false);
        fenv.gate(false);
    }

    /** Быстро заглушить (вытеснение, заглушение хэтов, моно-канал). */
    void kill() {
        if (!active) return;
        if (delay > 0) {
            active = false;
            return;
        }
        fadeStep = 1f / (0.004f * sr);
    }

    boolean fading() {
        return fadeStep > 0;
    }

    // ================================================================== звук

    /** Добавить n сэмплов в шину канала. */
    void render(float[] L, float[] R, int n, float bpm) {
        if (!active) return;
        Project.Channel c = ch;
        int i = 0;
        if (delay > 0) {
            int d = Math.min(delay, n);
            delay -= d;
            i = d;
            if (i >= n) return;
        }
        float g0 = vel * (0.35f + 0.65f * vel);
        for (; i < n; i++) {
            if (remain > 0 && --remain == 0) {
                boolean oneShot = c.type == Project.SAMPLER && mode == Project.ONESHOT;
                if (!oneShot) release();
                else held = false;
            }
            if (glideStep > 0) {
                if (pitch < target) pitch = Math.min(target, pitch + glideStep);
                else pitch = Math.max(target, pitch - glideStep);
                if (pitch == target) glideStep = 0;
                if ((ctr & 15) == 0 || glideStep == 0) {
                    if (c.type == Project.SAMPLER) inc = Dsp.semis(pitch) * rateMul;
                    else if (c.type == Project.SYNTH) updateFreqs(c);
                }
            }
            float s;
            switch (c.type) {
                case Project.SYNTH: s = synthSample(c); break;
                case Project.BASS: s = bassSample(c); break;
                default: {
                    if (!samplerStep(L, R, i, g0)) {
                        active = false;
                        return;
                    }
                    if (!active) return;
                    continue;
                }
            }
            if (!amp.active()) {
                active = false;
                return;
            }
            s *= g0;
            if (fadeStep > 0) {
                fadeGain -= fadeStep;
                if (fadeGain <= 0) {
                    active = false;
                    return;
                }
                s *= fadeGain;
            }
            L[i] += s;
            R[i] += s;
            ctr++;
        }
    }

    private boolean samplerStep(float[] L, float[] R, int i, float g0) {
        Sample sm = smp;
        if (rev ? pos < s0 : pos >= s1 - 1) {
            if (mode == Project.LOOP && held) pos = rev ? s1 - 1 : s0;
            else return false;
        }
        int ip = (int) pos;
        float f = (float) (pos - ip);
        float l = interp(sm.l, ip, f, s0, s1), r = sm.r == sm.l ? l : interp(sm.r, ip, f, s0, s1);
        pos += rev ? -inc : inc;
        float e = amp.next();
        if (!amp.active()) return false;
        float g = e * g0;
        if (fadeStep > 0) {
            fadeGain -= fadeStep;
            if (fadeGain <= 0) return false;
            g *= fadeGain;
        }
        L[i] += l * g;
        R[i] += r * g;
        ctr++;
        return true;
    }

    /** Кубическая интерполяция Эрмита внутри [a, b). */
    private static float interp(float[] d, int i, float t, int a, int b) {
        int i0 = Math.max(a, i - 1), i2 = Math.min(b - 1, i + 1), i3 = Math.min(b - 1, i + 2);
        int i1 = Math.max(a, Math.min(b - 1, i));
        float y0 = d[i0], y1 = d[i1], y2 = d[i2], y3 = d[i3];
        float c1 = 0.5f * (y2 - y0), c2 = y0 - 2.5f * y1 + 2f * y2 - 0.5f * y3, c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2);
        return ((c3 * t + c2) * t + c1) * t + y1;
    }

    private float synthSample(Project.Channel c) {
        float o2 = Dsp.wave(c.osc2, ph2, dt2);
        float s;
        if (c.fm > 0.001f) {
            // FM: второй генератор модулирует фазу синуса — колокола, электропиано
            fmEnv *= fmCoef;
            s = Dsp.sin01(ph1 + o2 * c.fm * 2.5f * (0.15f + 0.85f * fmEnv));
            if (c.mix > 0.001f) s = s * (1 - c.mix) + Dsp.wave(c.osc1, ph1, dt1) * c.mix;
        } else {
            float o1 = Dsp.wave(c.osc1, ph1, dt1);
            s = o1 * (1 - c.mix) + o2 * c.mix;
        }
        if (c.sub > 0.001f) s += Dsp.sin01(ph3) * c.sub;
        if (c.noise > 0.001f) s += Dsp.noise() * c.noise * 0.5f;
        ph1 += dt1;
        if (ph1 >= 1) ph1 -= 1;
        ph2 += dt2;
        if (ph2 >= 1) ph2 -= Math.floor(ph2);
        ph3 += dt3;
        if (ph3 >= 1) ph3 -= 1;
        float fe = fenv.next();
        if ((ctr & 15) == 0) {
            float cut = (float) (c.cutoff * Math.pow(2, c.envAmt * fe));
            svf.set(cut, c.res, sr);
        }
        svf.process(s);
        float y = svf.out(c.ftype);
        if (c.vdrive > 0.001f) y = Fx.drive(y, c.vdrive, 0);
        return y * amp.next() * 0.5f;
    }

    private float bassSample(Project.Channel c) {
        pEnv *= pCoef;
        double f = Dsp.midiToHz(pitch + pEnv);
        float s = Dsp.sin01(ph);
        ph += f / sr;
        if (ph >= 1) ph -= 1;
        if (clickEnv > 0.0005f) {
            clickEnv *= clickCoef;
            s += Dsp.sin01(ph * 3) * clickEnv;
        }
        if (c.drive808 > 0.001f) s = Fx.drive(s, c.drive808, 0);
        return s * amp.next() * 0.85f;
    }
}
