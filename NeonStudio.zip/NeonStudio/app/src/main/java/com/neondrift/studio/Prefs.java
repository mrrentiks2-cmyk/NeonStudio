package com.neondrift.studio;

import android.content.Context;
import android.content.SharedPreferences;

/** Настройки приложения. */
final class Prefs {
    private final SharedPreferences sp;

    Prefs(Context c) {
        sp = c.getSharedPreferences("settings", Context.MODE_PRIVATE);
    }

    int accent() { return sp.getInt("accent", 0); }
    String lastProject() { return sp.getString("lastProject", ""); }
    /** Разрядность WAV при экспорте: 16 или 24. */
    int exportBits() { return sp.getInt("exportBits", 24); }
    int exportRate() { return sp.getInt("exportRate", 44100); }
    /** 0 — WAV, 1 — M4A. */
    int exportFormat() { return sp.getInt("exportFormat", 0); }
    /** Привязка в пиано-ролле, тиков (24 — шестнадцатая, 1 — без сетки). */
    int snap() { return sp.getInt("snapTicks", Project.STEP); }
    boolean scaleHighlight() { return sp.getBoolean("scaleHighlight", true); }
    /** Играть бит, пока идёт запись с микрофона. */
    boolean recPlay() { return sp.getBoolean("recPlay", true); }
    boolean quantizeRec() { return sp.getBoolean("quantizeRec", true); }
    boolean velocityPads() { return sp.getBoolean("velocityPads", true); }
    boolean vibrate() { return sp.getBoolean("vibrate", true); }
    int generatorStyle() { return sp.getInt("genStyle", 0); }

    void put(String k, boolean v) { sp.edit().putBoolean(k, v).apply(); }
    void put(String k, int v) { sp.edit().putInt(k, v).apply(); }
    void put(String k, long v) { sp.edit().putLong(k, v).apply(); }
    void put(String k, String v) { sp.edit().putString(k, v).apply(); }
    void remove(String k) { sp.edit().remove(k).apply(); }
}
